// Nova VPS agent - sing-box config generator (Hysteria2 gaming path).
//
// xray-core can't do QUIC protocols, so the agent runs sing-box ALONGSIDE xray
// to serve Hysteria2 on UDP :443 (QUIC). This is the low-latency path for
// gaming and voice: UDP-native, no TCP head-of-line blocking. TCP :443 stays
// with xray (VLESS/VMess/Trojan + the panel); UDP :443 is Hysteria2. Same users
// (password = the user's uuid), same self-signed / origin certificate.

/**
 * @param {Array<object>} users  Nova user objects (uuid|id, email|id, enabled).
 * @param {object} opts
 *   port            UDP listen port (default 443)
 *   certificateFile / keyFile   TLS cert the QUIC handshake uses
 *   logLevel        sing-box log level
 */
export function generateSingboxConfig(users, opts = {}) {
  const {
    port = 443,
    certificateFile = "/etc/nova/origin.pem",
    keyFile = "/etc/nova/origin.key",
    logLevel = "warn",
    // Loopback v2ray stats API (custom sing-box build, -tags with_v2ray_api).
    // It reports PER-USER traffic in the same `user>>><name>>>>traffic>>>...`
    // form xray uses, so the agent reuses the xray stats bridge to accrue
    // Hysteria2 usage into the per-user quota counters. (The stock binary's
    // Clash API only exposes aggregate + the inbound tag, not the user.)
    v2rayApi = "127.0.0.1:10087",
  } = opts;

  // De-dupe by name (password auth keys on the name); Hysteria2 rejects two
  // users with the same name, mirroring xray's email rule.
  const seen = new Set();
  const hUsers = users
    .filter((u) => u.enabled !== false)
    .map((u) => ({ name: String(u.email || u.id), password: u.uuid || u.id }))
    .filter((u) => {
      if (seen.has(u.name)) return false;
      seen.add(u.name);
      return true;
    });

  return {
    log: { level: logLevel, timestamp: true },
    inbounds: [
      {
        type: "hysteria2",
        tag: "hy2-in",
        listen: "::",
        listen_port: port,
        users: hUsers,
        tls: {
          enabled: true,
          alpn: ["h3"],
          certificate_path: certificateFile,
          key_path: keyFile,
        },
      },
    ],
    outbounds: [{ type: "direct", tag: "direct" }],
    experimental: {
      v2ray_api: {
        listen: v2rayApi,
        stats: {
          enabled: true,
          inbounds: ["hy2-in"],
          users: hUsers.map((u) => u.name),
        },
      },
    },
  };
}
