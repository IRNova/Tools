// Nova VPS agent - sing-box config generator (Hysteria2 gaming path).
//
// xray-core can't do QUIC protocols, so the agent runs sing-box ALONGSIDE xray
// to serve Hysteria2 on UDP :443 (QUIC). This is the low-latency path for
// gaming and voice: UDP-native, no TCP head-of-line blocking. TCP :443 stays
// with xray (VLESS/VMess/Trojan + the panel); UDP :443 is Hysteria2. Same users
// (password = the user's uuid), same self-signed / origin certificate.

/**
 * @param {Array<object>} users  Nova user objects (uuid|id, email|id, enabled).
 * @param {object} opts
 *   port            UDP listen port (default 443)
 *   certificateFile / keyFile   TLS cert the QUIC handshake uses
 *   logLevel        sing-box log level
 */
// Map Nova users to Hysteria2 auth entries, de-duped by name (password auth keys
// on the name; Hysteria2 rejects two users with the same name, like xray's email
// rule). `filterFn` picks which users this inbound serves.
function hy2Users(users, filterFn) {
  const seen = new Set();
  return users
    .filter((u) => u.enabled !== false && (filterFn ? filterFn(u) : true))
    .map((u) => ({ name: String(u.email || u.id), password: u.uuid || u.id }))
    .filter((u) => (seen.has(u.name) ? false : (seen.add(u.name), true)));
}

function hy2Inbound(tag, listenPort, hUsers, { certificateFile, keyFile, obfsPassword } = {}) {
  const inb = {
    type: "hysteria2",
    tag,
    listen: "::",
    listen_port: listenPort,
    users: hUsers,
    tls: { enabled: true, alpn: ["h3"], certificate_path: certificateFile, key_path: keyFile },
  };
  // Salamander obfuscation, when the inbound sets a password.
  if (obfsPassword) inb.obfs = { type: "salamander", password: String(obfsPassword) };
  return inb;
}

export function generateSingboxConfig(users, opts = {}) {
  const {
    port = 443,
    certificateFile = "/etc/nova/origin.pem",
    keyFile = "/etc/nova/origin.key",
    logLevel = "warn",
    v2rayApi = "127.0.0.1:10087",
    // Emit the default Hysteria2 inbound on `port` (the Protocols toggle). When a
    // node only uses editor-defined Hysteria2 inbounds this can be turned off.
    enableDefault = true,
    // Extra Hysteria2 inbounds from the panel's inbound editor. Each:
    // { tag, port, obfsPassword?, serves(u) } - one inbound per UDP port so an
    // admin can run several (port-hopping). Port collisions are skipped.
    extraInbounds = [],
  } = opts;

  const inbounds = [];
  const usedPorts = new Set();
  if (enableDefault) {
    inbounds.push(hy2Inbound("hy2-in", port, hy2Users(users), { certificateFile, keyFile }));
    usedPorts.add(port);
  }
  for (const rec of extraInbounds) {
    const p = Number(rec.port);
    if (!(p >= 1 && p <= 65535) || usedPorts.has(p)) continue;
    usedPorts.add(p);
    const tag = rec.tag || `hy2-${p}`;
    inbounds.push(hy2Inbound(tag, p, hy2Users(users, rec.serves), {
      certificateFile, keyFile, obfsPassword: rec.obfsPassword,
    }));
  }
  // sing-box needs at least one inbound to start; if nothing is enabled, fall
  // back to the default so a bare config still validates.
  if (!inbounds.length) {
    inbounds.push(hy2Inbound("hy2-in", port, hy2Users(users), { certificateFile, keyFile }));
  }

  const statUsers = new Set();
  for (const inb of inbounds) for (const u of inb.users) statUsers.add(u.name);

  return {
    log: { level: logLevel, timestamp: true },
    inbounds,
    outbounds: [{ type: "direct", tag: "direct" }],
    experimental: {
      v2ray_api: {
        listen: v2rayApi,
        stats: { enabled: true, inbounds: inbounds.map((i) => i.tag), users: [...statUsers] },
      },
    },
  };
}
