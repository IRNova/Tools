// Nova VPS agent - sing-box config generator (Hysteria2 gaming path).
//
// xray-core can't do QUIC protocols, so the agent runs sing-box ALONGSIDE xray
// to serve Hysteria2 on UDP :443 (QUIC). This is the low-latency path for
// gaming and voice: UDP-native, no TCP head-of-line blocking. TCP :443 stays
// with xray (VLESS/VMess/Trojan + the panel); UDP :443 is Hysteria2. Same users
// (password = the user's uuid), same self-signed / origin certificate.

/**
 * @param {Array<object>} users  Nova user objects (uuid|id, email|id, enabled).
 * @param {object} opts
 *   port            UDP listen port (default 443)
 *   certificateFile / keyFile   TLS cert the QUIC handshake uses
 *   logLevel        sing-box log level
 */
export function generateSingboxConfig(users, opts = {}) {
  const {
    port = 443,
    certificateFile = "/etc/nova/origin.pem",
    keyFile = "/etc/nova/origin.key",
    logLevel = "warn",
  } = opts;

  // De-dupe by name (password auth keys on the name); Hysteria2 rejects two
  // users with the same name, mirroring xray's email rule.
  const seen = new Set();
  const hUsers = users
    .filter((u) => u.enabled !== false)
    .map((u) => ({ name: String(u.email || u.id), password: u.uuid || u.id }))
    .filter((u) => {
      if (seen.has(u.name)) return false;
      seen.add(u.name);
      return true;
    });

  return {
    log: { level: logLevel, timestamp: true },
    inbounds: [
      {
        type: "hysteria2",
        tag: "hy2-in",
        listen: "::",
        listen_port: port,
        users: hUsers,
        tls: {
          enabled: true,
          alpn: ["h3"],
          certificate_path: certificateFile,
          key_path: keyFile,
        },
      },
    ],
    outbounds: [{ type: "direct", tag: "direct" }],
  };
}
