// Nova VPS agent: Hysteria2 (sing-box) per-user traffic -> panel accounting.
//
// The custom sing-box build (with_v2ray_api) reports per-user traffic in the
// SAME form xray does: user>>><name>>>traffic>>>uplink|downlink. But sing-box
// serves it under the v2ray gRPC service name (v2ray.core.app.stats.command),
// which xray's own client can't call, so we query it with grpcurl + a tiny
// bundled proto and parse the JSON. `reset: true` makes each poll return the
// delta since the last poll, exactly like xray's statsquery -reset.

import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const pExecFile = promisify(execFile);
const HERE = dirname(fileURLToPath(import.meta.url));
const PROTO = join(HERE, "stats.proto");

const NAME_RE = /^user>>>(.+)>>>traffic>>>(uplink|downlink)$/;

/** Parse a grpcurl QueryStats JSON blob into { name: {up, down} } bytes. */
export function parseSingboxStats(json) {
  const out = {};
  const stats = (json && json.stat) || [];
  for (const s of stats) {
    const m = NAME_RE.exec(s.name || "");
    if (!m) continue;
    const [, user, dir] = m;
    (out[user] ||= { up: 0, down: 0 });
    const v = Number(s.value || 0);
    if (dir === "uplink") out[user].up += v;
    else out[user].down += v;
  }
  return out;
}

/**
 * Read-and-reset sing-box per-user traffic via grpcurl. Returns
 * { user: {up, down} } deltas. Throws if grpcurl or the API is unavailable
 * (the caller treats that as "no Hysteria2 usage this tick").
 */
export async function pollSingboxTraffic({
  apiAddr = "127.0.0.1:10087",
  grpcurlBin = "grpcurl",
  protoPath = PROTO,
  importPath = HERE,
} = {}) {
  const { stdout } = await pExecFile(
    grpcurlBin,
    [
      "-plaintext",
      "-import-path",
      importPath,
      "-proto",
      protoPath,
      "-d",
      '{"pattern":"user>>>","reset":true}',
      apiAddr,
      "v2ray.core.app.stats.command.StatsService/QueryStats",
    ],
    { timeout: 10_000 },
  );
  // grpcurl prints "{}" (no stat field) when there is nothing to report.
  return parseSingboxStats(JSON.parse(stdout || "{}"));
}
