// Nova VPS agent - AmneziaWG server.
//
// Turns the node into an AmneziaWG (obfuscated WireGuard) server: real DPI
// resistance, because the junk packets (Jc/Jmin/Jmax), handshake junk (S1/S2)
// and magic headers (H1-H4) make the WireGuard handshake unfingerprintable. The
// same junk params live on the server and on every client config, so they must
// match exactly - that is why we generate them once and hand them out verbatim.
//
// The interface (awg0) runs on its own UDP port, independent of xray/sing-box on
// :443. The agent runs as root, so it drives `awg-quick`/`awg` and iptables NAT
// directly. Keys are X25519 (generated with Node crypto, same as WARP) so we do
// not depend on `awg genkey` stdin plumbing.

import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { generateKeyPairSync } from "node:crypto";
import { writeFile, mkdir, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

const pExecFile = promisify(execFile);

const CONF_DIR = "/etc/amnezia/amneziawg";
const IFACE = "awg0";
const CONF_PATH = `${CONF_DIR}/${IFACE}.conf`;
const SUBNET_BASE = "10.13.13"; // server .1, peers .2+
const DEFAULT_PORT = 51820;

// Junk-packet strength presets. Jc/Jmin/Jmax = standalone junk packets before
// the handshake; S1/S2 = random bytes prepended to the init/response handshake.
// Constraint respected on every preset: S1 + 56 != S2. H1-H4 are random per
// server (added in makeJunk). Heavier = harder to fingerprint, more overhead.
export const AWG_PRESETS = {
  light: { Jc: 3, Jmin: 20, Jmax: 50, S1: 15, S2: 64 },
  medium: { Jc: 4, Jmin: 40, Jmax: 70, S1: 86, S2: 574 },
  heavy: { Jc: 8, Jmin: 80, Jmax: 120, S1: 120, S2: 824 },
};

const run = (cmd, args, opts = {}) => pExecFile(cmd, args, { timeout: 15000, ...opts });
const runOk = async (cmd, args, opts) => { try { await run(cmd, args, opts); return true; } catch { return false; } };

/** True if the AmneziaWG userland tools are installed on this node. */
export async function awgAvailable() {
  return (await runOk("sh", ["-c", "command -v awg && command -v awg-quick"]));
}

/** An X25519 keypair as base64 (WireGuard wire format), via Node crypto. */
export function genKeypair() {
  const { privateKey, publicKey } = generateKeyPairSync("x25519");
  const b64 = (k, type, fmt) => Buffer.from(k.export({ type, format: "der" }).subarray(-32)).toString("base64");
  return {
    privateKey: b64(privateKey, "pkcs8", "der"),
    publicKey: b64(publicKey, "spki", "der"),
  };
}

// Four distinct magic-header values in [5, 2^31): 1-4 are reserved WireGuard
// message types, so headers must avoid them and each other.
function randHeaders() {
  const set = new Set();
  while (set.size < 4) {
    const v = 5 + Math.floor(Math.random() * (0x7fffffff - 6));
    set.add(v);
  }
  const [H1, H2, H3, H4] = [...set];
  return { H1, H2, H3, H4 };
}

/** A fresh junk-param bundle for a preset (or medium), with random headers. */
export function makeJunk(level = "medium") {
  const base = AWG_PRESETS[level] || AWG_PRESETS.medium;
  return { ...base, ...randHeaders() };
}

/** The WAN interface name (for NAT), best-effort. */
async function wanIface() {
  try {
    const { stdout } = await run("sh", ["-c", "ip route get 1.1.1.1 2>/dev/null"]);
    const m = /dev\s+(\S+)/.exec(stdout);
    if (m) return m[1];
  } catch {}
  return "eth0";
}

/** The public endpoint host for client configs: the node domain, else its public IPv4. */
async function endpointHost(settings) {
  const h = (settings && settings.host && String(settings.host).trim()) || "";
  if (h) return h.replace(/:\d+$/, "");
  try {
    const { stdout } = await run("sh", ["-c", "ip -4 addr show scope global 2>/dev/null"]);
    const m = /inet\s+([0-9.]+)/.exec(stdout);
    if (m) return m[1];
  } catch {}
  return "";
}

/** The stored AWG state on the settings doc (or a disabled default). */
export function awgState(settings) {
  return settings.awg && typeof settings.awg === "object" ? settings.awg : { enabled: false };
}

/**
 * Ensure server identity exists on the settings doc: keypair, junk params,
 * port, subnet. Idempotent - only fills what is missing. Returns the awg object
 * (caller persists the settings doc).
 */
export function ensureServer(settings, { level = "medium", port } = {}) {
  const awg = awgState(settings);
  if (!awg.server || !awg.server.privateKey) awg.server = genKeypair();
  if (!awg.junk) awg.junk = makeJunk(level);
  if (!awg.level) awg.level = AWG_PRESETS[level] ? level : "medium";
  if (!awg.port) awg.port = Number(port) || DEFAULT_PORT;
  if (!awg.subnet) awg.subnet = `${SUBNET_BASE}.0/24`;
  if (!Array.isArray(awg.peers)) awg.peers = [];
  settings.awg = awg;
  return awg;
}

/** Next free 10.13.13.x host for a new peer. */
function nextPeerIp(awg) {
  const used = new Set((awg.peers || []).map((p) => p.address));
  for (let i = 2; i < 255; i++) {
    const a = `${SUBNET_BASE}.${i}`;
    if (!used.has(a)) return a;
  }
  throw new Error("peer subnet full");
}

/** Add a peer (client keypair + IP) to the awg object. Returns the new peer. */
export function addPeer(awg, name = "") {
  const kp = genKeypair();
  const peer = {
    id: Math.random().toString(36).slice(2, 10),
    name: String(name || "").slice(0, 40) || `peer-${(awg.peers || []).length + 1}`,
    privateKey: kp.privateKey,
    publicKey: kp.publicKey,
    address: nextPeerIp(awg),
    createdAt: Date.now(),
  };
  awg.peers.push(peer);
  return peer;
}

/**
 * Make the peer set track the Nova user registry: exactly one peer per enabled
 * user, keyed by userId, created on demand. Any peer that is not a current
 * user's (a deleted/disabled user, or a legacy standalone client) is removed,
 * since WireGuard is now purely per-user. Returns true if anything changed.
 */
export function syncUserPeers(awg, users = []) {
  if (!Array.isArray(awg.peers)) awg.peers = [];
  const enabled = users.filter((u) => u && u.enabled !== false && u.id);
  const wantIds = new Set(enabled.map((u) => u.id));
  const have = new Map(awg.peers.filter((p) => p.userId).map((p) => [p.userId, p]));
  let changed = false;

  // Keep only peers that belong to a current enabled user.
  const kept = awg.peers.filter((p) => p.userId && wantIds.has(p.userId));
  if (kept.length !== awg.peers.length) { awg.peers = kept; changed = true; }

  // Add a peer for each user that does not have one yet.
  for (const u of enabled) {
    if (have.has(u.id)) {
      // keep the name in sync with the user's email
      const p = have.get(u.id);
      if (p.name !== (u.email || u.id)) { p.name = u.email || u.id; changed = true; }
      continue;
    }
    const kp = genKeypair();
    awg.peers.push({
      id: "u-" + u.id,
      userId: u.id,
      name: u.email || u.id,
      privateKey: kp.privateKey,
      publicKey: kp.publicKey,
      address: nextPeerIp(awg),
      createdAt: Date.now(),
    });
    changed = true;
  }
  return changed;
}

/** The AWG peer that belongs to a given Nova user id, if any. */
export function peerForUser(awg, userId) {
  return (awg.peers || []).find((p) => p.userId === userId) || null;
}

/** Render the server awg0.conf text. */
export function renderServerConf(awg, wan) {
  const j = awg.junk;
  const lines = [
    "[Interface]",
    `Address = ${SUBNET_BASE}.1/24`,
    `ListenPort = ${awg.port}`,
    `PrivateKey = ${awg.server.privateKey}`,
    `Jc = ${j.Jc}`,
    `Jmin = ${j.Jmin}`,
    `Jmax = ${j.Jmax}`,
    `S1 = ${j.S1}`,
    `S2 = ${j.S2}`,
    `H1 = ${j.H1}`,
    `H2 = ${j.H2}`,
    `H3 = ${j.H3}`,
    `H4 = ${j.H4}`,
    `PostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -A FORWARD -o %i -j ACCEPT; iptables -t nat -A POSTROUTING -o ${wan} -j MASQUERADE`,
    `PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; iptables -t nat -D POSTROUTING -o ${wan} -j MASQUERADE`,
    "",
  ];
  for (const p of awg.peers || []) {
    lines.push("[Peer]", `# ${p.name}`, `PublicKey = ${p.publicKey}`, `AllowedIPs = ${p.address}/32`, "");
  }
  return lines.join("\n");
}

/** Render an importable AmneziaWG client .conf for one peer. */
export function renderClientConf(awg, peer, host) {
  const j = awg.junk;
  return [
    "[Interface]",
    `PrivateKey = ${peer.privateKey}`,
    `Address = ${peer.address}/32`,
    "DNS = 1.1.1.1, 1.0.0.1",
    `Jc = ${j.Jc}`,
    `Jmin = ${j.Jmin}`,
    `Jmax = ${j.Jmax}`,
    `S1 = ${j.S1}`,
    `S2 = ${j.S2}`,
    `H1 = ${j.H1}`,
    `H2 = ${j.H2}`,
    `H3 = ${j.H3}`,
    `H4 = ${j.H4}`,
    "",
    "[Peer]",
    `PublicKey = ${awg.server.publicKey}`,
    `Endpoint = ${host}:${awg.port}`,
    "AllowedIPs = 0.0.0.0/0, ::/0",
    "PersistentKeepalive = 25",
    "",
  ].join("\n");
}

/**
 * Client config as a structured object (for the Nova app's `awg` endpoint type
 * and for building a subscription). Junk params included so both ends match.
 */
export function clientObject(awg, peer, host) {
  const j = awg.junk;
  return {
    type: "awg",
    private_key: peer.privateKey,
    address: [`${peer.address}/32`],
    jc: j.Jc, jmin: j.Jmin, jmax: j.Jmax, s1: j.S1, s2: j.S2,
    h1: String(j.H1), h2: String(j.H2), h3: String(j.H3), h4: String(j.H4),
    peers: [{
      public_key: awg.server.publicKey,
      address: host,
      port: awg.port,
      allowed_ips: ["0.0.0.0/0", "::/0"],
      persistent_keepalive_interval: 25,
    }],
  };
}

async function writeConf(text) {
  await mkdir(CONF_DIR, { recursive: true, mode: 0o700 });
  await writeFile(CONF_PATH, text, { mode: 0o600 });
}

/** Persist ip_forward and bring the interface fully up (enable + start). */
export async function applyServer(awg) {
  const wan = await wanIface();
  await writeConf(renderServerConf(awg, wan));
  await runOk("sysctl", ["-w", "net.ipv4.ip_forward=1"]);
  await runOk("sh", ["-c", "echo 'net.ipv4.ip_forward=1' > /etc/sysctl.d/99-nova-awg.conf"]);
  await runOk("awg-quick", ["down", IFACE]); // ignore if not up
  await run("awg-quick", ["up", IFACE]);
  await runOk("systemctl", ["enable", `awg-quick@${IFACE}`]);
  return { wan };
}

/** Apply peer changes live without dropping the tunnel (syncconf). */
export async function syncPeers(awg) {
  const wan = await wanIface();
  await writeConf(renderServerConf(awg, wan));
  const tmp = join(tmpdir(), `awg-sync-${Date.now()}.conf`);
  try {
    const { stdout } = await run("awg-quick", ["strip", IFACE]);
    await writeFile(tmp, stdout, { mode: 0o600 });
    await run("awg", ["syncconf", IFACE, tmp]);
  } catch {
    // interface probably down - do a full bring-up instead
    await applyServer(awg);
  }
}

/** Tear the interface down and stop it surviving reboot. */
export async function disableServer() {
  await runOk("awg-quick", ["down", IFACE]);
  await runOk("systemctl", ["disable", `awg-quick@${IFACE}`]);
}

/** Live status: whether the interface is up + a handshake map by public key. */
export async function liveStatus() {
  try {
    const { stdout } = await run("awg", ["show", IFACE, "dump"]);
    const rows = stdout.trim().split("\n").slice(1); // first row = interface
    const peers = {};
    for (const r of rows) {
      const c = r.split("\t");
      // dump columns: pubkey, psk, endpoint, allowed-ips, latest-handshake, rx, tx, keepalive
      peers[c[0]] = { endpoint: c[2], latestHandshake: Number(c[4]) || 0, rx: Number(c[5]) || 0, tx: Number(c[6]) || 0 };
    }
    return { up: true, peers };
  } catch {
    return { up: false, peers: {} };
  }
}

export { endpointHost, wanIface, CONF_PATH, IFACE };
