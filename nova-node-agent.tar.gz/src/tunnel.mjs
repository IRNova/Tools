// Full-tunnel exit bridge for the Nova "Google relay, full mode".
//
// The MHR relay (/relay) only proxies whole HTTP requests. This bridge instead
// carries raw TCP (and UDP) flows as a sequence of JSON ops, so a client can run
// a real SOCKS5 tunnel whose bytes travel: device -> (domain-fronted) Google
// Apps Script -> POST /tunnel here -> real socket -> internet. To the ISP it all
// looks like Google traffic; this node is the exit that actually talks to the
// destination.
//
// It is request/response by nature (each op is one HTTP round-trip), so it is
// SLOW compared to a normal proxy. It exists for reachability when every normal
// node is blocked, not for speed.
//
// Wire protocol (POST /tunnel, one JSON envelope, `k` is the tunnel key):
//   { k, op:"connect",  h, p }            -> { id }                 open TCP
//   { k, op:"data",     id, d? }          -> { d, closed }          write d, drain server bytes (long-poll)
//   { k, op:"close",    id }              -> { ok }                 tear down
//   { k, op:"udp_open", h, p, d? }        -> { id, d? }             open UDP, optional first datagram
//   { k, op:"udp_data", id, d? }          -> { d }                  send datagram / poll for replies
//   { k, op:"batch",    ops:[ ... ] }     -> { r:[ ... ] }          many ops, one round-trip
// All payloads (`d`) are base64. `closed` means the upstream socket ended.

import net from "node:net";
import dgram from "node:dgram";
import { randomBytes } from "node:crypto";

const MAX_SESSIONS = 256; // hard cap on concurrent flows per node
const IDLE_MS = 90_000; // reap a flow with no op for this long
const MAX_BACKLOG = 4 * 1024 * 1024; // per-flow server->client buffer cap (backpressure)
const LONGPOLL_MS = 250; // wait up to this for server bytes before answering empty
const CONNECT_TIMEOUT_MS = 12_000;

// id -> session. A session owns one real socket plus a receive backlog.
const sessions = new Map();

function newId() {
  return randomBytes(9).toString("base64url");
}

// Reuse the /relay SSRF policy for a bare host (no URL scheme): refuse
// loopback, private, CGNAT, and link-local targets so the exit can't be turned
// into an internal port scanner.
export function isPublicTunnelHost(host) {
  if (!host || typeof host !== "string") return false;
  const h = host.toLowerCase();
  // Dev/test escape hatch: lets the loopback unit test drive a real socket.
  // Never set this in production; the default policy below blocks loopback.
  if (process.env.NOVA_TUNNEL_ALLOW_LOCAL === "1" &&
      (h === "127.0.0.1" || h === "localhost" || h === "::1")) {
    return true;
  }
  if (h === "localhost" || h.endsWith(".local") || h === "::1") return false;
  if (h.startsWith("fd") || h.startsWith("fe80")) return false;
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(h);
  if (m) {
    const a = +m[1], b = +m[2];
    if (a === 0 || a === 127 || a === 10) return false;
    if (a === 172 && b >= 16 && b <= 31) return false;
    if (a === 192 && b === 168) return false;
    if (a === 169 && b === 254) return false;
    if (a === 100 && b >= 64 && b <= 127) return false;
  }
  return true;
}

function touch(s) {
  s.lastSeen = Date.now();
}

// Pull the buffered upstream bytes, clearing the backlog and lifting any
// backpressure pause we applied when it grew too large.
function drain(s) {
  if (s.buf.length === 0) return "";
  const out = Buffer.concat(s.buf);
  s.buf = [];
  s.buflen = 0;
  if (s.paused && s.sock && !s.sock.destroyed) {
    s.paused = false;
    s.sock.resume();
  }
  return out.toString("base64");
}

function destroy(id) {
  const s = sessions.get(id);
  if (!s) return;
  sessions.delete(id);
  try {
    if (s.type === "tcp") s.sock.destroy();
    else s.sock.close();
  } catch {
    /* already gone */
  }
}

function openTcp(host, port) {
  return new Promise((resolve) => {
    const id = newId();
    const sock = net.connect({ host, port, allowHalfOpen: false });
    const s = {
      id, type: "tcp", sock, buf: [], buflen: 0,
      closed: false, paused: false, lastSeen: Date.now(), ready: false,
    };
    let settled = false;
    const t = setTimeout(() => {
      if (!settled) { settled = true; sock.destroy(); resolve({ e: "connect timeout" }); }
    }, CONNECT_TIMEOUT_MS);
    sock.once("connect", () => {
      if (settled) return;
      settled = true; clearTimeout(t);
      s.ready = true; sock.setNoDelay(true);
      sessions.set(id, s);
      resolve({ id });
    });
    sock.on("data", (chunk) => {
      s.buf.push(chunk);
      s.buflen += chunk.length;
      // Wake any long-poll waiter, then apply backpressure if we're buffering
      // faster than the client drains.
      if (s.wake) { const w = s.wake; s.wake = null; w(); }
      if (s.buflen >= MAX_BACKLOG && !s.paused) { s.paused = true; sock.pause(); }
    });
    sock.on("end", () => { s.closed = true; if (s.wake) { const w = s.wake; s.wake = null; w(); } });
    sock.on("close", () => { s.closed = true; if (s.wake) { const w = s.wake; s.wake = null; w(); } });
    sock.on("error", () => {
      s.closed = true;
      if (!settled) { settled = true; clearTimeout(t); resolve({ e: "connect failed" }); }
      if (s.wake) { const w = s.wake; s.wake = null; w(); }
    });
  });
}

// Long-poll: resolve as soon as there are server bytes (or the socket closes),
// else after LONGPOLL_MS. Keeps the tunnel responsive without busy polling.
function waitForData(s) {
  if (s.buf.length > 0 || s.closed) return Promise.resolve();
  return new Promise((resolve) => {
    let done = false;
    const finish = () => { if (done) return; done = true; s.wake = null; resolve(); };
    s.wake = finish;
    setTimeout(finish, LONGPOLL_MS);
  });
}

async function tcpData(doc) {
  const s = sessions.get(doc.id);
  if (!s || s.type !== "tcp") return { e: "no session" };
  touch(s);
  if (doc.d) {
    if (s.closed || s.sock.destroyed) return { e: "closed" };
    try {
      s.sock.write(Buffer.from(String(doc.d), "base64"));
    } catch {
      return { e: "write failed" };
    }
  }
  await waitForData(s);
  const d = drain(s);
  const closed = s.closed && s.buf.length === 0;
  if (closed) destroy(s.id);
  return { d, closed };
}

function openUdp(host, port, first) {
  return new Promise((resolve) => {
    const id = newId();
    const sock = dgram.createSocket("udp4");
    const s = { id, type: "udp", sock, buf: [], buflen: 0, closed: false, lastSeen: Date.now(), host, port };
    sock.on("message", (msg) => {
      s.buf.push(msg);
      s.buflen += msg.length;
      if (s.buflen > MAX_BACKLOG) { s.buf.shift(); } // drop oldest, UDP is lossy anyway
      if (s.wake) { const w = s.wake; s.wake = null; w(); }
    });
    sock.on("error", () => { s.closed = true; });
    try {
      sock.connect(port, host, () => {
        sessions.set(id, s);
        if (first) { try { sock.send(Buffer.from(String(first), "base64")); } catch { /* ignore */ } }
        resolve({ id });
      });
    } catch {
      resolve({ e: "udp open failed" });
    }
  });
}

async function udpData(doc) {
  const s = sessions.get(doc.id);
  if (!s || s.type !== "udp") return { e: "no session" };
  touch(s);
  if (doc.d) { try { s.sock.send(Buffer.from(String(doc.d), "base64")); } catch { /* ignore */ } }
  await waitForData(s);
  return { d: drain(s) };
}

// Dispatch one op. `connect`/`udp_open` enforce the SSRF policy on the target.
export async function tunnelOp(doc) {
  switch (doc && doc.op) {
    case "connect": {
      if (sessions.size >= MAX_SESSIONS) return { e: "too many sessions" };
      const port = Number(doc.p);
      if (!doc.h || !Number.isInteger(port) || port < 1 || port > 65535) return { e: "bad target" };
      if (!isPublicTunnelHost(String(doc.h))) return { e: "target not allowed" };
      return openTcp(String(doc.h), port);
    }
    case "data":
      return tcpData(doc);
    case "close":
      destroy(doc.id);
      return { ok: true };
    case "udp_open": {
      if (sessions.size >= MAX_SESSIONS) return { e: "too many sessions" };
      const port = Number(doc.p);
      if (!doc.h || !Number.isInteger(port) || port < 1 || port > 65535) return { e: "bad target" };
      if (!isPublicTunnelHost(String(doc.h))) return { e: "target not allowed" };
      return openUdp(String(doc.h), port, doc.d);
    }
    case "udp_data":
      return udpData(doc);
    case "batch": {
      const ops = Array.isArray(doc.ops) ? doc.ops.slice(0, 32) : [];
      const r = [];
      for (const op of ops) r.push(await tunnelOp(op));
      return { r };
    }
    default:
      return { e: "unknown op" };
  }
}

// Reap idle flows. Call from the agent poll loop.
export function sweepTunnelSessions(now = Date.now()) {
  for (const [id, s] of sessions) {
    if (now - s.lastSeen > IDLE_MS) destroy(id);
  }
}

// Tear everything down on shutdown.
export function closeAllTunnelSessions() {
  for (const id of [...sessions.keys()]) destroy(id);
}

export function tunnelSessionCount() {
  return sessions.size;
}
