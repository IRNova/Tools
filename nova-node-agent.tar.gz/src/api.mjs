// Nova node REST API (v1).
//
// A token-authenticated surface that mirrors the session-auth /admin/* actions,
// so tooling, resellers and a parent Nova panel (multi-node) can drive a node
// programmatically. It calls the SAME exported service functions the browser
// panel does (no duplicated logic).
//
//   Authorization: Bearer <token>       (or ?token=<token>)
//
// Tokens live in settings.apiTokens[] as { id, name, hash, role, ownerId }, and
// only sha256(token) is stored. GET /api/v1 returns a self-describing doc and
// needs no token, so integrators can discover the shape.

import { timingSafeEqual } from "node:crypto";
import { hashToken } from "./auth.mjs";
import {
  getSettings,
  applyUserAction,
  usageData,
  readDashboard,
  getBackup,
  applyInboundAction,
  restoreBackup,
  subIdFor,
  HttpError,
  sendJson,
  readBody,
  parseJson,
} from "./server.mjs";

const PREFIX = "/api/v1";

/** Find the apiTokens[] record whose stored hash matches (timing-safe). */
export async function verifyApiToken(kv, token) {
  if (!token) return null;
  const s = await getSettings(kv);
  const want = Buffer.from(hashToken(token));
  for (const t of s.apiTokens || []) {
    const have = Buffer.from(String(t.hash || ""));
    if (have.length === want.length && timingSafeEqual(have, want)) return t;
  }
  return null;
}

// A reseller token only sees its own users; an owner token sees everything.
function scoped(users, identity) {
  if (!identity || identity.role !== "reseller") return users;
  const mine = identity.ownerId || identity.id;
  return users.filter((u) => u.ownerId === mine);
}

function subUrlFor(settings, u) {
  const host = String(settings.host || "").split(":")[0];
  return host ? `https://${host}/sub?u=${subIdFor(settings, u)}` : "";
}

async function publicUser(kv, settings, u) {
  const uid = u.id || u.uuid;
  const [tot, up, dn] = await Promise.all([
    kv.get(`uusage:${uid}`), kv.get(`uusage-up:${uid}`), kv.get(`uusage-dn:${uid}`),
  ]);
  return {
    id: uid,
    name: u.name || u.email || uid,
    email: u.email || "",
    enabled: u.enabled !== false,
    quotaBytes: Number(u.quotaBytes || 0),
    quotaUpBytes: Number(u.quotaUpBytes || 0),
    quotaDownBytes: Number(u.quotaDownBytes || 0),
    used: Number(tot || 0),
    up: Number(up || 0),
    down: Number(dn || 0),
    expiry: u.expiry || "",
    expireDays: Number(u.expireDays || 0),
    ipLimit: Number(u.ipLimit || 0),
    ownerId: u.ownerId || "",
    subUrl: subUrlFor(settings, u),
  };
}

/**
 * Handle a /api/v1/* request. Called from server.route() before the /admin gate.
 * `url` is the parsed URL, `method` the HTTP verb.
 */
export async function apiRoute(req, res, kv, opts, url, method) {
  const path = url.pathname.replace(/\/+$/, "") || PREFIX;

  // Self-describing docs. Public (no token) so the shape is discoverable.
  if (path === PREFIX && method === "GET") {
    return sendJson(res, 200, apiDocs());
  }

  // Everything else needs a valid bearer token.
  const auth = req.headers["authorization"] || "";
  const m = /^Bearer\s+(.+)$/i.exec(auth);
  const token = (m ? m[1] : url.searchParams.get("token") || "").trim();
  const identity = await verifyApiToken(kv, token);
  if (!identity) return sendJson(res, 401, { error: "unauthorized" });

  const isOwner = identity.role !== "reseller";

  // --- users ---------------------------------------------------------------
  if (path === `${PREFIX}/users`) {
    const settings = await getSettings(kv);
    if (method === "GET") {
      const list = scoped(settings.users || [], identity);
      const users = await Promise.all(list.map((u) => publicUser(kv, settings, u)));
      return sendJson(res, 200, { users });
    }
    if (method === "POST") {
      const action = parseJson(await readBody(req));
      const result = await applyUserAction(kv, action, opts, identity);
      const fresh = await getSettings(kv);
      const saved = (fresh.users || []).find((x) => (x.id || x.uuid) === (result.user && (result.user.id || result.user.uuid)));
      return sendJson(res, 200, { ok: true, user: saved ? await publicUser(kv, fresh, saved) : result.user });
    }
    throw new HttpError(405, "method not allowed");
  }

  // GET/DELETE a single user by id: /api/v1/users/<id>
  if (path.startsWith(`${PREFIX}/users/`)) {
    const id = decodeURIComponent(path.slice(`${PREFIX}/users/`.length));
    const settings = await getSettings(kv);
    const u = scoped(settings.users || [], identity).find((x) => (x.id || x.uuid) === id);
    if (!u) throw new HttpError(404, "user not found");
    if (method === "GET") return sendJson(res, 200, { user: await publicUser(kv, settings, u) });
    if (method === "DELETE") {
      await applyUserAction(kv, { action: "delete", user: { id } }, opts, identity);
      return sendJson(res, 200, { ok: true });
    }
    if (method === "PATCH") {
      const patch = parseJson(await readBody(req));
      await applyUserAction(kv, { action: "update", user: { ...patch, id } }, opts, identity);
      const fresh = await getSettings(kv);
      const nu = (fresh.users || []).find((x) => (x.id || x.uuid) === id);
      return sendJson(res, 200, { ok: true, user: nu ? await publicUser(kv, fresh, nu) : null });
    }
    throw new HttpError(405, "method not allowed");
  }

  // --- usage ---------------------------------------------------------------
  if (path === `${PREFIX}/usage` && method === "GET") {
    const all = await usageData(kv);
    if (isOwner) return sendJson(res, 200, { usage: all });
    const settings = await getSettings(kv);
    const mineIds = new Set(scoped(settings.users || [], identity).map((u) => u.id || u.uuid));
    const usage = {};
    for (const [k, v] of Object.entries(all)) if (mineIds.has(k)) usage[k] = v;
    return sendJson(res, 200, { usage });
  }

  // --- inbounds (owner only) ----------------------------------------------
  if (path === `${PREFIX}/inbounds`) {
    if (!isOwner) throw new HttpError(403, "owner only");
    if (method === "GET") {
      const s = await getSettings(kv);
      return sendJson(res, 200, { inbounds: s.inbounds || [] });
    }
    if (method === "POST") {
      const doc = parseJson(await readBody(req));
      const out = await applyInboundAction(kv, doc, opts);
      return sendJson(res, 200, { ok: true, inbounds: out.inbounds, saved: out.saved });
    }
    throw new HttpError(405, "method not allowed");
  }

  // --- node stats / health -------------------------------------------------
  if (path === `${PREFIX}/stats` && method === "GET") {
    return sendJson(res, 200, await readDashboard(kv, opts));
  }
  if (path === `${PREFIX}/health` && method === "GET") {
    return sendJson(res, 200, { ok: true, role: isOwner ? "owner" : "reseller" });
  }

  // --- backup / restore (owner only) --------------------------------------
  if (path === `${PREFIX}/backup` && method === "GET") {
    if (!isOwner) throw new HttpError(403, "owner only");
    return sendJson(res, 200, await getBackup(kv));
  }
  if (path === `${PREFIX}/restore` && method === "POST") {
    if (!isOwner) throw new HttpError(403, "owner only");
    const out = await restoreBackup(kv, parseJson(await readBody(req)), opts);
    return sendJson(res, 200, out);
  }

  throw new HttpError(404, "not found");
}

// Compact, hand-authored OpenAPI-ish description. No external deps.
function apiDocs() {
  return {
    nova: "node-api",
    version: "v1",
    auth: "Authorization: Bearer <token>  (create tokens in the panel under Settings > API)",
    baseUrl: "/api/v1",
    endpoints: [
      { method: "GET", path: "/api/v1", auth: false, desc: "This document." },
      { method: "GET", path: "/api/v1/health", auth: true, desc: "Liveness + your token role." },
      { method: "GET", path: "/api/v1/stats", auth: true, desc: "Live node dashboard (owner)." },
      { method: "GET", path: "/api/v1/users", auth: true, desc: "List users (resellers see only their own)." },
      { method: "POST", path: "/api/v1/users", auth: true, desc: "Create/update/delete a user. Body: {action, user|id}." },
      { method: "GET", path: "/api/v1/users/{id}", auth: true, desc: "One user with usage + sub link." },
      { method: "PATCH", path: "/api/v1/users/{id}", auth: true, desc: "Update fields on a user." },
      { method: "DELETE", path: "/api/v1/users/{id}", auth: true, desc: "Delete a user." },
      { method: "GET", path: "/api/v1/usage", auth: true, desc: "Per-user traffic totals." },
      { method: "GET", path: "/api/v1/inbounds", auth: true, desc: "List inbounds (owner)." },
      { method: "POST", path: "/api/v1/inbounds", auth: true, desc: "Add/update/delete/toggle an inbound (owner). Body: {action, inbound|id}." },
      { method: "GET", path: "/api/v1/backup", auth: true, desc: "Full backup dump (owner)." },
      { method: "POST", path: "/api/v1/restore", auth: true, desc: "Restore from a backup dump (owner)." },
    ],
  };
}
