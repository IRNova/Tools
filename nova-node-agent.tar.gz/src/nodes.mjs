// Nova multi-node fleet.
//
// A parent Nova panel registers remote Nova nodes and drives them over their
// REST API (src/api.mjs). Each node stays independent (resellers pay for their
// own server and keep running if the parent is offline); the parent only does
// pull-based aggregation of users/usage and pushes user provisioning to a chosen
// node. Nodes live in settings.nodes[] = { id, name, url, apiToken, ownerId,
// addedAt, lastSeen, lastError }.

/** Call a child node's REST API. Throws on transport/HTTP error. */
export async function nodeFetch(node, apiPath, { method = "GET", body, timeoutMs = 8000 } = {}) {
  const base = String(node.url || "").replace(/\/+$/, "");
  if (!base) throw new Error("node has no url");
  const r = await fetch(`${base}/api/v1${apiPath}`, {
    method,
    headers: {
      authorization: `Bearer ${node.apiToken || ""}`,
      ...(body ? { "content-type": "application/json" } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(timeoutMs),
  });
  const text = await r.text();
  let json = null;
  try { json = JSON.parse(text); } catch {}
  if (!r.ok) throw new Error((json && json.error) || `HTTP ${r.status}`);
  return json;
}

/** Validate a node is reachable + the token works. Returns {ok, role|error}. */
export async function pingNode(node) {
  try {
    const h = await nodeFetch(node, "/health");
    return { ok: true, role: (h && h.role) || "owner" };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}

/** Fan out an API GET across nodes, tolerating dead ones (allSettled). Each
 * result row carries its nodeId/nodeName; failures surface as { nodeId, error }. */
export async function fanOut(nodes, apiPath) {
  const settled = await Promise.allSettled(nodes.map((n) => nodeFetch(n, apiPath)));
  const ok = [];
  const errors = [];
  settled.forEach((s, i) => {
    const n = nodes[i];
    if (s.status === "fulfilled") ok.push({ nodeId: n.id, nodeName: n.name, data: s.value });
    else errors.push({ nodeId: n.id, nodeName: n.name, error: String((s.reason && s.reason.message) || s.reason) });
  });
  return { ok, errors };
}

/** Public (token-free) view of a node for the panel. */
export function publicNode(n) {
  return {
    id: n.id, name: n.name, url: n.url, ownerId: n.ownerId || "",
    addedAt: n.addedAt || 0, lastSeen: n.lastSeen || 0, lastError: n.lastError || "",
    hasToken: !!n.apiToken,
  };
}
