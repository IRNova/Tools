// Nova VPS agent: Clash-Meta and sing-box subscription formats.
//
// buildSub (subscription.mjs) emits the v2ray base64 list of URIs, which Hiddify,
// v2rayNG and sing-box import fine. Clash-family clients want YAML, and some want
// a native sing-box JSON. This turns the same users + inbounds into structured
// proxy objects and renders them to either format. /sub picks the format from
// ?target= or the client's User-Agent.

import { emailForUser, enabledProtocols, protocolPaths } from "./xray/config.mjs";
import { normalizeInbound, servesUser, userCredential, SS_METHOD, SUB_PROTOCOLS } from "./xray/inbounds.mjs";
import { isAllowed } from "./subscription.mjs";

// One structured proxy per user per enabled endpoint (front protocols + each
// standalone inbound the user is on). Shared by both renderers.
export async function enumerateProxies(users, opts = {}) {
  const {
    host, wsPath = "/nova", port = 443, insecure = false,
    protocols = { vless: true }, inbounds = [], directHost = null,
    kv = null, usage = null, now = new Date(), hy2Port = port,
  } = opts;
  const nowMs = now instanceof Date ? now.getTime() : Number(now);
  const on = enabledProtocols(protocols);
  const paths = protocolPaths(wsPath);
  const inbs = (inbounds || []).map((i) => (i.tag ? i : normalizeInbound(i))).filter((i) => i.enabled !== false);
  const addr = directHost || host;
  const out = [];

  for (const u of users) {
    if (!(await isAllowed(u, { kv, usage, nowMs }))) continue;
    const label = u.name || emailForUser(u);
    const id = u.uuid || u.id;

    if (on.vless) out.push({ name: label, protocol: "vless", server: host, port, uuid: id, network: "ws", path: paths.vless, wsHost: host, tls: true, sni: host, insecure });
    if (on.vmess) out.push({ name: `${label} vmess`, protocol: "vmess", server: host, port, uuid: id, network: "ws", path: paths.vmess, wsHost: host, tls: true, sni: host, insecure });
    if (on.trojan) out.push({ name: `${label} trojan`, protocol: "trojan", server: host, port, password: id, network: "ws", path: paths.trojan, wsHost: host, tls: true, sni: host, insecure });
    if (on.hysteria2) out.push({ name: `${label} hy2`, protocol: "hysteria2", server: host, port: hy2Port, password: id, sni: host, insecure });

    for (const inb of inbs) {
      if (!servesUser(inb, u)) continue;
      // socks / http / dokodemo-door are not shareable subscription protocols.
      if (!SUB_PROTOCOLS.includes(inb.protocol)) continue;
      const cred = userCredential(inb, u);
      const p = {
        name: `${label} ${inb.remark || `${inb.protocol}-${inb.network}`}`,
        protocol: inb.protocol, server: addr, port: inb.port, network: inb.network,
        fp: inb.fingerprint || "chrome", insecure,
      };
      if (inb.protocol === "shadowsocks") { p.ssMethod = inb.method || SS_METHOD; p.password = `${inb.ssPassword}:${cred}`; out.push(p); continue; }
      if (inb.protocol === "trojan") p.password = cred; else p.uuid = cred;
      if (inb.network === "ws") { p.path = inb.path || "/"; p.wsHost = inb.host || addr; }
      if (inb.network === "grpc") p.serviceName = inb.serviceName || "nova";
      if (inb.network === "xhttp") { p.path = inb.path || "/"; p.xhttpMode = inb.xhttpMode || "auto"; }
      if (inb.security === "tls") { p.tls = true; p.sni = inb.sni || addr; }
      else if (inb.security === "reality") { p.tls = true; p.reality = { pbk: inb.reality.publicKey, sid: (inb.reality.shortIds || [])[0] || "" }; p.sni = (inb.reality.serverNames || [])[0]; if (inb.flow) p.flow = inb.flow; }
      out.push(p);
    }
  }
  return out;
}

// --- Clash-Meta YAML --------------------------------------------------------

const yq = (s) => `"${String(s).replace(/"/g, '\\"')}"`;

function clashProxy(p) {
  const f = [`name: ${yq(p.name)}`, `server: ${yq(p.server)}`, `port: ${p.port}`, `udp: true`];
  if (p.protocol === "vless") {
    f.unshift("type: vless");
    f.push(`uuid: ${yq(p.uuid)}`, `tls: ${!!p.tls}`, `network: ${p.network}`, `client-fingerprint: ${yq(p.fp || "chrome")}`);
    if (p.sni) f.push(`servername: ${yq(p.sni)}`);
    if (p.flow) f.push(`flow: ${yq(p.flow)}`);
    if (p.reality) f.push(`reality-opts: {public-key: ${yq(p.reality.pbk)}, short-id: ${yq(p.reality.sid)}}`);
    if (p.network === "ws") f.push(`ws-opts: {path: ${yq(p.path)}, headers: {Host: ${yq(p.wsHost)}}}`);
    if (p.network === "grpc") f.push(`grpc-opts: {grpc-service-name: ${yq(p.serviceName)}}`);
    if (p.insecure && !p.reality) f.push(`skip-cert-verify: true`);
  } else if (p.protocol === "vmess") {
    f.unshift("type: vmess");
    f.push(`uuid: ${yq(p.uuid)}`, `alterId: 0`, `cipher: auto`, `tls: ${!!p.tls}`, `network: ${p.network}`);
    if (p.sni) f.push(`servername: ${yq(p.sni)}`);
    if (p.network === "ws") f.push(`ws-opts: {path: ${yq(p.path)}, headers: {Host: ${yq(p.wsHost)}}}`);
    if (p.insecure) f.push(`skip-cert-verify: true`);
  } else if (p.protocol === "trojan") {
    f.unshift("type: trojan");
    f.push(`password: ${yq(p.password)}`, `network: ${p.network}`);
    if (p.sni) f.push(`sni: ${yq(p.sni)}`);
    if (p.network === "ws") f.push(`ws-opts: {path: ${yq(p.path)}, headers: {Host: ${yq(p.wsHost)}}}`);
    if (p.network === "grpc") f.push(`grpc-opts: {grpc-service-name: ${yq(p.serviceName)}}`);
    if (p.insecure) f.push(`skip-cert-verify: true`);
  } else if (p.protocol === "shadowsocks") {
    f.unshift("type: ss");
    f.push(`cipher: ${yq(p.ssMethod)}`, `password: ${yq(p.password)}`);
  } else if (p.protocol === "hysteria2") {
    f.unshift("type: hysteria2");
    f.push(`password: ${yq(p.password)}`);
    if (p.sni) f.push(`sni: ${yq(p.sni)}`);
    if (p.insecure) f.push(`skip-cert-verify: true`);
  }
  return `  - {${f.join(", ")}}`;
}

export function toClash(proxies, { name = "Nova" } = {}) {
  const names = proxies.map((p) => yq(p.name));
  return [
    "mixed-port: 7890",
    "allow-lan: false",
    "mode: rule",
    "log-level: info",
    "proxies:",
    ...proxies.map(clashProxy),
    "proxy-groups:",
    `  - {name: ${yq(name)}, type: url-test, url: "http://www.gstatic.com/generate_204", interval: 300, tolerance: 50, proxies: [${names.join(", ")}]}`,
    `  - {name: "Manual", type: select, proxies: [${yq(name)}, ${names.join(", ")}]}`,
    "rules:",
    `  - MATCH,${name}`,
    "",
  ].join("\n");
}

// --- sing-box JSON ----------------------------------------------------------

function singboxOutbound(p) {
  const tag = p.name;
  if (p.protocol === "vless") {
    const o = { type: "vless", tag, server: p.server, server_port: p.port, uuid: p.uuid };
    if (p.flow) o.flow = p.flow;
    o.tls = tlsBlock(p);
    if (p.network === "ws") o.transport = { type: "ws", path: p.path, headers: { Host: p.wsHost } };
    if (p.network === "grpc") o.transport = { type: "grpc", service_name: p.serviceName };
    return o;
  }
  if (p.protocol === "vmess") {
    const o = { type: "vmess", tag, server: p.server, server_port: p.port, uuid: p.uuid, security: "auto", alter_id: 0, tls: tlsBlock(p) };
    if (p.network === "ws") o.transport = { type: "ws", path: p.path, headers: { Host: p.wsHost } };
    return o;
  }
  if (p.protocol === "trojan") {
    const o = { type: "trojan", tag, server: p.server, server_port: p.port, password: p.password, tls: tlsBlock(p) };
    if (p.network === "ws") o.transport = { type: "ws", path: p.path, headers: { Host: p.wsHost } };
    if (p.network === "grpc") o.transport = { type: "grpc", service_name: p.serviceName };
    return o;
  }
  if (p.protocol === "shadowsocks") {
    return { type: "shadowsocks", tag, server: p.server, server_port: p.port, method: p.ssMethod, password: p.password };
  }
  if (p.protocol === "hysteria2") {
    return { type: "hysteria2", tag, server: p.server, server_port: p.port, password: p.password, tls: { enabled: true, server_name: p.sni, insecure: !!p.insecure } };
  }
  return null;
}

function tlsBlock(p) {
  if (!p.tls) return { enabled: false };
  const t = { enabled: true, server_name: p.sni, utls: { enabled: true, fingerprint: p.fp || "chrome" } };
  if (p.reality) t.reality = { enabled: true, public_key: p.reality.pbk, short_id: p.reality.sid };
  else if (p.insecure) t.insecure = true;
  return t;
}

export function toSingbox(proxies) {
  const outs = proxies.map(singboxOutbound).filter(Boolean);
  const tags = outs.map((o) => o.tag);
  const config = {
    outbounds: [
      { type: "selector", tag: "Nova", outbounds: ["auto", ...tags], default: "auto" },
      { type: "urltest", tag: "auto", outbounds: tags, url: "http://www.gstatic.com/generate_204", interval: "5m" },
      ...outs,
      { type: "direct", tag: "direct" },
    ],
    route: { final: "Nova", auto_detect_interface: true },
  };
  return JSON.stringify(config, null, 2);
}
