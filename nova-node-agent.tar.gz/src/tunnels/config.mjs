// Nova tunnel layer: config generation for the Iran-bridge <-> foreign-exit link.
//
// The problem: an Iran VPS has a clean domestic IP but a throttled/censored
// international link; a foreign VPS runs the real Nova exit (xray + Hysteria2).
// We tunnel between them so clients connect to the clean Iran IP and the traffic
// rides a censorship-resistant transport to the foreign exit.
//
// Two roles:
//   bridge = the Iran box. End-users connect here. Runs the tunnel "server":
//            it accepts the tunnel from the exit and exposes the forwarded ports.
//   exit   = the foreign box (the real Nova node). Runs the tunnel "client":
//            it dials the bridge and forwards to local xray/Hysteria2.
//
// Selectable backends (all carry TCP + UDP so Hysteria2 survives):
//   backhaul - widest transport set (tcp/ws/wss + mux), pooling, self-signed OK
//   rathole  - lightweight Rust, TCP+UDP, Noise/TLS
//   wstunnel - tunnels over WebSocket/HTTPS, fronts cleanly behind a CDN
//
// These functions are PURE (spec -> config text): unit-tested, no I/O. The
// manager (./manager.mjs) writes them + drives systemd.

export const BACKENDS = ["backhaul", "rathole", "wstunnel"];
export const ROLES = ["bridge", "exit"];

// Per-backend allowed transports (validated so we never emit a config the binary
// rejects). Values map straight into each backend's own config vocabulary.
export const TRANSPORTS = {
  backhaul: ["tcp", "tcpmux", "ws", "wsmux", "wss", "wssmux"],
  rathole: ["tcp", "udp", "tls", "noise"],
  wstunnel: ["ws", "wss"],
};

function bad(msg) {
  return { ok: false, error: msg };
}

/** Validate a tunnel spec. Returns {ok:true} or {ok:false, error}. */
export function validateTunnel(t) {
  if (!t || typeof t !== "object") return bad("no tunnel config");
  if (!BACKENDS.includes(t.backend)) return bad(`unknown backend ${t.backend}`);
  if (!ROLES.includes(t.role)) return bad(`role must be bridge or exit`);
  const tr = t.transport || TRANSPORTS[t.backend][0];
  if (!TRANSPORTS[t.backend].includes(tr)) return bad(`transport ${tr} not supported by ${t.backend}`);
  const port = Number(t.tunnelPort);
  if (!Number.isInteger(port) || port < 1 || port > 65535) return bad("tunnelPort must be 1-65535");
  if (!t.token || String(t.token).length < 8) return bad("token must be at least 8 chars");
  if (t.role === "exit") {
    if (!t.bridgeAddr || !/^[^\s:]+:\d+$/.test(String(t.bridgeAddr))) return bad("exit needs bridgeAddr host:port");
  }
  const fwd = normalizeForwards(t.forwards);
  if (!fwd.length) return bad("at least one forwarded port is required");
  return { ok: true };
}

// Forwards are ["443", "8443/udp", "443=127.0.0.1:443"] -> normalized records.
export function normalizeForwards(forwards) {
  const out = [];
  for (const raw of forwards || []) {
    const s = String(raw).trim();
    if (!s) continue;
    const proto = /\/udp$/i.test(s) ? "udp" : "tcp";
    const body = s.replace(/\/(tcp|udp)$/i, "");
    let listen, target;
    if (body.includes("=")) {
      [listen, target] = body.split("=");
    } else {
      listen = body;
      target = `127.0.0.1:${body}`;
    }
    const lp = Number(listen);
    if (!Number.isInteger(lp) || lp < 1 || lp > 65535) continue;
    out.push({ listen: lp, target: target.includes(":") ? target : `127.0.0.1:${target}`, proto });
  }
  return out;
}

const defTransport = (t) => t.transport || TRANSPORTS[t.backend][0];
const usesTls = (tr) => /^wss/.test(tr) || tr === "tls";
const isMux = (tr) => /mux$/.test(tr);

// --- Backhaul --------------------------------------------------------------
export function backhaulConfig(t) {
  const tr = defTransport(t);
  const pool = Number(t.mux) > 0 ? Number(t.mux) : 8;
  const fwd = normalizeForwards(t.forwards);
  const lines = [];
  if (t.role === "bridge") {
    // The Iran server: end-users connect to <listen>, tunneled to the exit's target.
    lines.push("[server]");
    lines.push(`bind_addr = "0.0.0.0:${t.tunnelPort}"`);
    lines.push(`transport = "${tr}"`);
    lines.push(`token = "${t.token}"`);
    if (isMux(tr)) lines.push(`mux_con = ${pool}`);
    lines.push(`channel_size = 2048`);
    lines.push(`heartbeat = 40`);
    if (usesTls(tr)) {
      lines.push(`tls_cert = "${t.tlsCert || "/etc/nova/tunnel/cert.pem"}"`);
      lines.push(`tls_key = "${t.tlsKey || "/etc/nova/tunnel/key.pem"}"`);
    }
    lines.push(`ports = [`);
    for (const f of fwd) lines.push(`  "${f.listen}=${f.target}",`);
    lines.push(`]`);
  } else {
    // The foreign client: dials the bridge, forwards to local xray/hysteria.
    lines.push("[client]");
    lines.push(`remote_addr = "${t.bridgeAddr}"`);
    lines.push(`transport = "${tr}"`);
    lines.push(`token = "${t.token}"`);
    if (isMux(tr)) lines.push(`mux_con = ${pool}`);
    lines.push(`connection_pool = ${pool}`);
    lines.push(`heartbeat = 40`);
    if (usesTls(tr)) lines.push(`edge_ip = ""`);
  }
  return lines.join("\n") + "\n";
}

// --- rathole ---------------------------------------------------------------
export function ratholeConfig(t) {
  const fwd = normalizeForwards(t.forwards);
  const tr = defTransport(t);
  const transportBlock = tr === "tls"
    ? `\n[${t.role}.transport]\ntype = "tls"\n`
    : tr === "noise"
      ? `\n[${t.role}.transport]\ntype = "noise"\n`
      : "";
  const lines = [];
  if (t.role === "bridge") {
    lines.push("[server]");
    lines.push(`bind_addr = "0.0.0.0:${t.tunnelPort}"`);
    if (transportBlock) lines.push(transportBlock.trim());
    for (const f of fwd) {
      lines.push(`[server.services.nova_${f.listen}]`);
      lines.push(`token = "${t.token}"`);
      lines.push(`bind_addr = "0.0.0.0:${f.listen}"`);
    }
  } else {
    lines.push("[client]");
    lines.push(`remote_addr = "${t.bridgeAddr}"`);
    if (transportBlock) lines.push(transportBlock.trim());
    for (const f of fwd) {
      lines.push(`[client.services.nova_${f.listen}]`);
      lines.push(`token = "${t.token}"`);
      lines.push(`local_addr = "${f.target}"`);
    }
  }
  return lines.join("\n") + "\n";
}

// --- wstunnel (CLI args, not a file) ---------------------------------------
export function wstunnelArgs(t) {
  const tr = defTransport(t);
  const scheme = tr === "wss" ? "wss" : "ws";
  const fwd = normalizeForwards(t.forwards);
  if (t.role === "bridge") {
    // server listens for the tunnel; --restrict-to limits exposed targets.
    return ["server", `${scheme}://0.0.0.0:${t.tunnelPort}`];
  }
  // client dials the bridge and forwards each port to the local service.
  const args = ["client"];
  for (const f of fwd) {
    const p = f.proto === "udp" ? "udp" : "tcp";
    args.push("-L", `${p}://${f.listen}:${f.target}`);
  }
  args.push(`${scheme}://${t.bridgeAddr}`);
  return args;
}

/**
 * Render the deployable artifact for a tunnel spec:
 *   { kind:"file", path, content, exec, args }  (backhaul/rathole: a config file)
 *   { kind:"args", exec, args }                 (wstunnel: pure CLI)
 */
export function renderTunnel(t) {
  const v = validateTunnel(t);
  if (!v.ok) throw new Error(v.error);
  if (t.backend === "backhaul") {
    return { kind: "file", exec: "backhaul", path: "/etc/nova/tunnel/backhaul.toml", content: backhaulConfig(t), args: ["-c", "/etc/nova/tunnel/backhaul.toml"] };
  }
  if (t.backend === "rathole") {
    const mode = t.role === "bridge" ? "--server" : "--client";
    return { kind: "file", exec: "rathole", path: "/etc/nova/tunnel/rathole.toml", content: ratholeConfig(t), args: [mode, "/etc/nova/tunnel/rathole.toml"] };
  }
  return { kind: "args", exec: "wstunnel", args: wstunnelArgs(t) };
}
