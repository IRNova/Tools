// Nova tunnel manager: writes the generated config + drives a systemd unit for
// the selected tunnel backend. Best-effort and guarded (mirrors src/awg.mjs): on
// a node without the binary or without systemd, the calls no-op cleanly so the
// rest of the panel keeps working.

import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { writeFile, mkdir } from "node:fs/promises";
import { renderTunnel, validateTunnel } from "./config.mjs";

const pExecFile = promisify(execFile);
const CONF_DIR = "/etc/nova/tunnel";
const UNIT = "nova-tunnel";
const UNIT_PATH = `/etc/systemd/system/${UNIT}.service`;

async function runOk(cmd, args) {
  try {
    await pExecFile(cmd, args, { timeout: 15_000 });
    return true;
  } catch {
    return false;
  }
}

/** Is the selected backend's binary installed? */
export async function backendAvailable(backend) {
  return runOk("bash", ["-lc", `command -v ${backend}`]);
}

/** Live systemd status of the tunnel unit. */
export async function tunnelStatus() {
  try {
    const { stdout } = await pExecFile("systemctl", ["is-active", UNIT], { timeout: 8000 });
    return { up: stdout.trim() === "active", state: stdout.trim() };
  } catch (e) {
    const out = (e && e.stdout ? String(e.stdout).trim() : "") || "inactive";
    return { up: false, state: out };
  }
}

// The systemd unit that runs the tunnel binary with the rendered args.
function unitFile(art) {
  const exec = art.kind === "file"
    ? `/usr/local/bin/${art.exec} ${art.args.join(" ")}`
    : `/usr/local/bin/${art.exec} ${art.args.map((a) => (/\s/.test(a) ? `'${a}'` : a)).join(" ")}`;
  return [
    "[Unit]",
    "Description=Nova tunnel (Iran bridge <-> foreign exit)",
    "After=network-online.target",
    "Wants=network-online.target",
    "",
    "[Service]",
    "Type=simple",
    `ExecStart=${exec}`,
    "Restart=always",
    "RestartSec=3",
    "LimitNOFILE=1048576",
    "",
    "[Install]",
    "WantedBy=multi-user.target",
    "",
  ].join("\n");
}

// A TLS transport (wss / wssmux / tls) needs a cert. On the bridge we mint a
// self-signed pair once (no domain required); the exit trusts it via the shared
// token, so self-signed is fine here.
async function ensureTunnelCert() {
  const cert = `${CONF_DIR}/cert.pem`;
  const key = `${CONF_DIR}/key.pem`;
  await runOk("bash", ["-lc",
    `test -f '${cert}' && test -f '${key}' || openssl req -x509 -newkey rsa:2048 -nodes ` +
    `-keyout '${key}' -out '${cert}' -days 3650 -subj '/CN=nova-tunnel' >/dev/null 2>&1`]);
}

/** Apply a tunnel spec: write config + unit, enable + (re)start. */
export async function applyTunnel(t) {
  const v = validateTunnel(t);
  if (!v.ok) throw new Error(v.error);
  const art = renderTunnel(t);
  await mkdir(CONF_DIR, { recursive: true, mode: 0o700 });
  // TLS transports on the bridge role need a cert on disk.
  if (t.role === "bridge" && /^(wss|tls)/.test(String(t.transport || ""))) {
    await ensureTunnelCert();
  }
  if (art.kind === "file") {
    await writeFile(art.path, art.content, { mode: 0o600 });
  }
  await writeFile(UNIT_PATH, unitFile(art), { mode: 0o644 });
  await runOk("systemctl", ["daemon-reload"]);
  await runOk("systemctl", ["enable", UNIT]);
  await runOk("systemctl", ["restart", UNIT]);
  return { ok: true };
}

/** Stop + disable the tunnel unit. */
export async function disableTunnel() {
  await runOk("systemctl", ["stop", UNIT]);
  await runOk("systemctl", ["disable", UNIT]);
  return { ok: true };
}

export { CONF_DIR, UNIT };
