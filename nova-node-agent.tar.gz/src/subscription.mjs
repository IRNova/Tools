// Nova VPS agent: subscription (/sub) builder.
//
// buildSub(users, opts) returns a base64 subscription body: one vless:// line per
// user that is currently allowed to connect, i.e. enabled AND not expired AND
// under quota. Expiry and quota are enforced here by reading the same counters
// the panel and the stats bridge use: KV key "uusage:<id>" (total bytes) vs the
// user's quotaBytes, and the user's expiry date vs now.
//
// The link format matches the generated xray inbound (VLESS + WS + TLS on :443,
// SNI/host = the public domain):
//
//   vless://<uuid>@<host>:443?type=ws&security=tls&host=<host>&path=<wsPath>&sni=<host>#<name>

import { emailForUser, enabledProtocols, protocolPaths } from "./xray/config.mjs";

/**
 * @param {Array<object>} users  Nova user registry.
 * @param {object} opts
 *   host    public domain Cloudflare fronts (required)
 *   wsPath  WebSocket path of the inbound (default "/nova")
 *   token   sub token (accepted for API symmetry; not embedded in links)
 *   port    remote port (default 443)
 *   kv      KV store; used to read "uusage:<id>" for quota checks
 *   usage   optional { id: bytes } map used instead of kv (tests)
 *   now     Date for expiry checks (default now)
 * @returns {Promise<string>} base64-encoded subscription body
 */
export async function buildSub(users, opts = {}) {
  const {
    host,
    wsPath = "/nova",
    port = 443,
    kv = null,
    usage = null,
    now = new Date(),
    // No-domain case: the agent serves a self-signed cert, so the client must
    // skip certificate verification. Adds allowInsecure=1 to each link.
    insecure = false,
    // Which protocols to emit a link for (mirrors the xray config).
    protocols = { vless: true },
  } = opts;
  if (!host) throw new Error("buildSub: host is required");

  const nowMs = now instanceof Date ? now.getTime() : Number(now);
  const on = enabledProtocols(protocols);
  const paths = protocolPaths(wsPath);
  const lines = [];

  for (const u of users) {
    if (!(await isAllowed(u, { kv, usage, nowMs }))) continue;
    // One link per enabled protocol, so the client's urltest auto-selector
    // measures them and routes through the fastest working one.
    if (on.vless) lines.push(vlessLine(u, { host, wsPath: paths.vless, port, insecure }));
    if (on.vmess) lines.push(vmessLine(u, { host, wsPath: paths.vmess, port, insecure }));
    if (on.trojan) lines.push(trojanLine(u, { host, wsPath: paths.trojan, port, insecure }));
  }

  const body = lines.join("\n");
  return Buffer.from(body, "utf8").toString("base64");
}

/** Whether a user should appear in the subscription right now. */
export async function isAllowed(u, { kv = null, usage = null, nowMs = Date.now() } = {}) {
  if (u.enabled === false) return false;
  if (!(u.uuid || u.id)) return false;

  // Expiry: a date string (YYYY-MM-DD) or ms epoch. End-of-day inclusive.
  if (u.expiry) {
    const exp = parseExpiry(u.expiry);
    if (Number.isFinite(exp) && nowMs > exp) return false;
  }

  // Quota: total accrued bytes vs quotaBytes.
  if (u.quotaBytes && Number(u.quotaBytes) > 0) {
    const used = await readUsage(u, { kv, usage });
    if (used >= Number(u.quotaBytes)) return false;
  }

  return true;
}

function vlessLine(u, { host, wsPath, port, insecure = false }) {
  const uuid = u.uuid || u.id;
  const params = new URLSearchParams({
    // The inbound is decryption:"none", so the share link must carry
    // encryption=none or some VLESS clients reject/misparse it (M2).
    encryption: "none",
    type: "ws",
    security: "tls",
    host,
    path: wsPath,
    sni: host,
  });
  // No-domain: the cert is self-signed, so tell the client to skip verification.
  if (insecure) params.set("allowInsecure", "1");
  const label = u.name || emailForUser(u);
  return `vless://${uuid}@${host}:${port}?${params.toString()}#${encodeURIComponent(label)}`;
}

function trojanLine(u, { host, wsPath, port, insecure = false }) {
  const password = u.uuid || u.id;
  const params = new URLSearchParams({
    type: "ws",
    security: "tls",
    host,
    path: wsPath,
    sni: host,
  });
  if (insecure) params.set("allowInsecure", "1");
  const label = `${u.name || emailForUser(u)} (Trojan)`;
  return `trojan://${password}@${host}:${port}?${params.toString()}#${encodeURIComponent(label)}`;
}

function vmessLine(u, { host, wsPath, port, insecure = false }) {
  // v2rayN vmess://base64(json) format.
  const cfg = {
    v: "2",
    ps: `${u.name || emailForUser(u)} (VMess)`,
    add: host,
    port: String(port),
    id: u.uuid || u.id,
    aid: "0",
    scy: "auto",
    net: "ws",
    type: "none",
    host,
    path: wsPath,
    tls: "tls",
    sni: host,
  };
  if (insecure) cfg.allowInsecure = "1";
  return `vmess://${Buffer.from(JSON.stringify(cfg), "utf8").toString("base64")}`;
}

async function readUsage(u, { kv, usage }) {
  const id = u.id || emailForUser(u);
  if (usage && Object.prototype.hasOwnProperty.call(usage, id)) {
    return Number(usage[id]) || 0;
  }
  if (kv) {
    const v = await kv.get(`uusage:${id}`);
    return Number(v || 0);
  }
  return 0;
}

// Treat a bare date as end-of-day UTC so the whole expiry day is still valid.
function parseExpiry(expiry) {
  if (typeof expiry === "number") return expiry;
  const s = String(expiry);
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
    return Date.parse(`${s}T23:59:59.999Z`);
  }
  return Date.parse(s);
}

export { vlessLine, trojanLine, vmessLine, parseExpiry };
