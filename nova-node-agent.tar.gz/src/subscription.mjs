// Nova VPS agent: subscription (/sub) builder.
//
// buildSub(users, opts) returns a base64 subscription body: one vless:// line per
// user that is currently allowed to connect, i.e. enabled AND not expired AND
// under quota. Expiry and quota are enforced here by reading the same counters
// the panel and the stats bridge use: KV key "uusage:<id>" (total bytes) vs the
// user's quotaBytes, and the user's expiry date vs now.
//
// The link format matches the generated xray inbound (VLESS + WS + TLS on :443,
// SNI/host = the public domain):
//
//   vless://<uuid>@<host>:443?type=ws&security=tls&host=<host>&path=<wsPath>&sni=<host>#<name>

import { emailForUser, enabledProtocols, protocolPaths } from "./xray/config.mjs";
import { normalizeInbound, servesUser, userCredential } from "./xray/inbounds.mjs";

/**
 * @param {Array<object>} users  Nova user registry.
 * @param {object} opts
 *   host    public domain Cloudflare fronts (required)
 *   wsPath  WebSocket path of the inbound (default "/nova")
 *   token   sub token (accepted for API symmetry; not embedded in links)
 *   port    remote port (default 443)
 *   kv      KV store; used to read "uusage:<id>" for quota checks
 *   usage   optional { id: bytes } map used instead of kv (tests)
 *   now     Date for expiry checks (default now)
 * @returns {Promise<string>} base64-encoded subscription body
 */
export async function buildSub(users, opts = {}) {
  const {
    host,
    wsPath = "/nova",
    port = 443,
    kv = null,
    usage = null,
    now = new Date(),
    // No-domain case: the agent serves a self-signed cert, so the client must
    // skip certificate verification. Adds allowInsecure=1 to each link.
    insecure = false,
    // Which protocols to emit a link for (mirrors the xray config).
    protocols = { vless: true },
    // Data-driven standalone inbounds (REALITY, gRPC, XHTTP, Shadowsocks, ...).
    inbounds = [],
    // Address standalone inbounds connect to. They bypass Cloudflare (Reality
    // terminates its own TLS), so this is the node's direct host/IP; the front
    // links keep using `host`. Defaults to `host` when not given.
    directHost = null,
    // Hysteria2 Brutal bandwidth hints (Mbps). >0 => the client uses Brutal
    // congestion control instead of BBR, the throughput win on throttled links.
    hy2Up = 0,
    hy2Down = 0,
    // Hysteria2 UDP port (defaults to the main port; admins can move it for
    // UDP port-hopping when 443/udp is throttled).
    hy2Port = port,
  } = opts;
  if (!host) throw new Error("buildSub: host is required");

  const nowMs = now instanceof Date ? now.getTime() : Number(now);
  const on = enabledProtocols(protocols);
  const paths = protocolPaths(wsPath);
  const inbs = (inbounds || []).map((i) => (i.tag ? i : normalizeInbound(i))).filter((i) => i.enabled !== false);
  const addr = directHost || host;
  const lines = [];

  for (const u of users) {
    if (!(await isAllowed(u, { kv, usage, nowMs }))) continue;
    // One link per enabled protocol, so the client's urltest auto-selector
    // measures them and routes through the fastest working one.
    if (on.vless) lines.push(vlessLine(u, { host, wsPath: paths.vless, port, insecure }));
    if (on.vmess) lines.push(vmessLine(u, { host, wsPath: paths.vmess, port, insecure }));
    if (on.trojan) lines.push(trojanLine(u, { host, wsPath: paths.trojan, port, insecure }));
    if (on.hysteria2) lines.push(hysteria2Line(u, { host, port: hy2Port, insecure, up: hy2Up, down: hy2Down }));
    // Plus one link per standalone inbound this user is served on.
    for (const inb of inbs) {
      if (servesUser(inb, u)) lines.push(inboundLine(u, inb, { host: addr, insecure }));
    }
  }

  const body = lines.join("\n");
  return Buffer.from(body, "utf8").toString("base64");
}

/** Whether a user should appear in the subscription right now. */
export async function isAllowed(u, { kv = null, usage = null, nowMs = Date.now() } = {}) {
  if (u.enabled === false) return false;
  if (!(u.uuid || u.id)) return false;

  // Expiry: a date string (YYYY-MM-DD) or ms epoch. End-of-day inclusive.
  if (u.expiry) {
    const exp = parseExpiry(u.expiry);
    if (Number.isFinite(exp) && nowMs > exp) return false;
  }

  // Quota: total accrued bytes vs quotaBytes.
  if (u.quotaBytes && Number(u.quotaBytes) > 0) {
    const used = await readUsage(u, { kv, usage });
    if (used >= Number(u.quotaBytes)) return false;
  }

  return true;
}

function vlessLine(u, { host, wsPath, port, insecure = false }) {
  const uuid = u.uuid || u.id;
  const params = new URLSearchParams({
    // The inbound is decryption:"none", so the share link must carry
    // encryption=none or some VLESS clients reject/misparse it (M2).
    encryption: "none",
    type: "ws",
    security: "tls",
    host,
    path: wsPath,
    sni: host,
  });
  // No-domain: the cert is self-signed, so tell the client to skip verification.
  if (insecure) params.set("allowInsecure", "1");
  const label = u.name || emailForUser(u);
  return `vless://${uuid}@${host}:${port}?${params.toString()}#${encodeURIComponent(label)}`;
}

function trojanLine(u, { host, wsPath, port, insecure = false }) {
  const password = u.uuid || u.id;
  const params = new URLSearchParams({
    type: "ws",
    security: "tls",
    host,
    path: wsPath,
    sni: host,
  });
  if (insecure) params.set("allowInsecure", "1");
  const label = `${u.name || emailForUser(u)} (Trojan)`;
  return `trojan://${password}@${host}:${port}?${params.toString()}#${encodeURIComponent(label)}`;
}

function hysteria2Line(u, { host, port, insecure = false, up = 0, down = 0 }) {
  // QUIC/UDP, no WS path. password = the user's uuid, matching the sing-box
  // inbound. The client (sing-box) parses hysteria2://password@host:port?sni=..
  const password = u.uuid || u.id;
  const params = new URLSearchParams({ sni: host });
  if (insecure) params.set("insecure", "1");
  // Brutal bandwidth hints (Mbps). The client turns these on as Brutal CC.
  if (Number(up) > 0) params.set("upmbps", String(Math.round(up)));
  if (Number(down) > 0) params.set("downmbps", String(Math.round(down)));
  const label = `${u.name || emailForUser(u)} (Hysteria2)`;
  return `hysteria2://${password}@${host}:${port}?${params.toString()}#${encodeURIComponent(label)}`;
}

function vmessLine(u, { host, wsPath, port, insecure = false }) {
  // v2rayN vmess://base64(json) format.
  const cfg = {
    v: "2",
    ps: `${u.name || emailForUser(u)} (VMess)`,
    add: host,
    port: String(port),
    id: u.uuid || u.id,
    aid: "0",
    scy: "auto",
    net: "ws",
    type: "none",
    host,
    path: wsPath,
    tls: "tls",
    sni: host,
  };
  if (insecure) cfg.allowInsecure = "1";
  return `vmess://${Buffer.from(JSON.stringify(cfg), "utf8").toString("base64")}`;
}

// A base64url encoder (no padding), for the Shadowsocks userinfo blob.
function b64url(s) {
  return Buffer.from(s, "utf8").toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

/**
 * Build the share link for one user on one standalone inbound (Reality/Vision,
 * gRPC, XHTTP, HTTPUpgrade, Shadowsocks-2022, ...). The transport + security
 * params mirror exactly what the inbound's xray config expects, so a scanned
 * link connects without hand-editing.
 */
export function inboundLine(u, inb, { host, insecure = false } = {}) {
  const label = `${u.name || emailForUser(u)} (${inb.remark || `${inb.protocol}-${inb.network}`})`;
  const cred = userCredential(inb, u);

  // Shadowsocks-2022: SIP002 with userinfo = base64url(method:serverPSK:userPSK).
  if (inb.protocol === "shadowsocks") {
    const userinfo = b64url(`${inb.method}:${inb.ssPassword}:${cred}`);
    return `ss://${userinfo}@${host}:${inb.port}#${encodeURIComponent(label)}`;
  }

  if (inb.protocol === "vmess") return vmessInboundLine(u, inb, { host, insecure });

  const params = new URLSearchParams();
  if (inb.protocol === "vless") params.set("encryption", "none");
  params.set("type", inb.network);

  if (inb.network === "ws") {
    params.set("host", inb.host || host);
    params.set("path", inb.path || "/");
  } else if (inb.network === "grpc") {
    params.set("serviceName", inb.serviceName || "nova");
    params.set("mode", "gun");
  } else if (inb.network === "xhttp") {
    if (inb.host) params.set("host", inb.host);
    params.set("path", inb.path || "/");
    params.set("mode", inb.xhttpMode || "auto");
  } else if (inb.network === "httpupgrade") {
    params.set("host", inb.host || host);
    params.set("path", inb.path || "/");
  }

  params.set("security", inb.security);
  if (inb.security === "tls") {
    params.set("sni", inb.sni || host);
    params.set("fp", inb.fingerprint || "chrome");
    if (Array.isArray(inb.alpn) && inb.alpn.length) params.set("alpn", inb.alpn.join(","));
    if (insecure) params.set("allowInsecure", "1");
  } else if (inb.security === "reality") {
    params.set("sni", inb.reality.serverNames[0]);
    params.set("pbk", inb.reality.publicKey);
    const sid = (inb.reality.shortIds && inb.reality.shortIds[0]) || "";
    if (sid) params.set("sid", sid);
    params.set("fp", inb.fingerprint || "chrome");
    params.set("spx", "/");
  }
  if (inb.flow) params.set("flow", inb.flow);

  return `${inb.protocol}://${cred}@${host}:${inb.port}?${params.toString()}#${encodeURIComponent(label)}`;
}

// VMess standalone inbound (v2rayN base64-json form). VMess never pairs with
// Reality, so security is tls or none.
function vmessInboundLine(u, inb, { host, insecure = false }) {
  const cfg = {
    v: "2",
    ps: `${u.name || emailForUser(u)} (${inb.remark || `vmess-${inb.network}`})`,
    add: host,
    port: String(inb.port),
    id: userCredential(inb, u),
    aid: "0",
    scy: "auto",
    net: inb.network,
    type: "none",
    host: inb.host || (inb.network === "ws" || inb.network === "httpupgrade" ? host : ""),
    path: inb.network === "grpc" ? (inb.serviceName || "nova") : (inb.path || "/"),
    tls: inb.security === "tls" ? "tls" : "",
    sni: inb.security === "tls" ? (inb.sni || host) : "",
  };
  if (inb.security === "tls") cfg.fp = inb.fingerprint || "chrome";
  if (insecure && inb.security === "tls") cfg.allowInsecure = "1";
  return `vmess://${Buffer.from(JSON.stringify(cfg), "utf8").toString("base64")}`;
}

async function readUsage(u, { kv, usage }) {
  const id = u.id || emailForUser(u);
  if (usage && Object.prototype.hasOwnProperty.call(usage, id)) {
    return Number(usage[id]) || 0;
  }
  if (kv) {
    const v = await kv.get(`uusage:${id}`);
    return Number(v || 0);
  }
  return 0;
}

// Treat a bare date as end-of-day UTC so the whole expiry day is still valid.
function parseExpiry(expiry) {
  if (typeof expiry === "number") return expiry;
  const s = String(expiry);
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
    return Date.parse(`${s}T23:59:59.999Z`);
  }
  return Date.parse(s);
}

export { vlessLine, trojanLine, vmessLine, hysteria2Line, parseExpiry };
