// Nova VPS agent: KV store over node:sqlite (Node 24+ built-in).
//
// Mirrors the panel's Cloudflare KV surface (get/put/delete/list) so the same
// JSON documents (network-settings.json, admin_pass, uusage:*, ...) load and
// round-trip unchanged. Backed by a single table:
//
//   CREATE TABLE kvstore(k TEXT PRIMARY KEY, v TEXT, updated INTEGER)
//
// The DatabaseSync engine is synchronous; the public API is async on purpose so
// callers match the Worker's KV (which returns promises) with no code changes.

import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";

/**
 * Open (or create) a SQLite-backed KV store.
 * @param {string} path  File path, or ":memory:" for an ephemeral store.
 * @returns {{
 *   get(k:string):Promise<string|null>,
 *   put(k:string, v:string):Promise<void>,
 *   delete(k:string):Promise<void>,
 *   list(o?:{prefix?:string}):Promise<Array<{name:string}>>,
 *   close():void,
 *   raw: import("node:sqlite").DatabaseSync,
 * }}
 */
export function openKv(path = ":memory:") {
  if (path && path !== ":memory:") {
    mkdirSync(dirname(path), { recursive: true });
  }
  const db = new DatabaseSync(path);
  db.exec("PRAGMA journal_mode = WAL");
  db.exec(
    "CREATE TABLE IF NOT EXISTS kvstore(k TEXT PRIMARY KEY, v TEXT, updated INTEGER)",
  );

  const getStmt = db.prepare("SELECT v FROM kvstore WHERE k = ?");
  const putStmt = db.prepare(
    "INSERT INTO kvstore(k, v, updated) VALUES(?, ?, ?) " +
      "ON CONFLICT(k) DO UPDATE SET v = excluded.v, updated = excluded.updated",
  );
  const delStmt = db.prepare("DELETE FROM kvstore WHERE k = ?");
  const listAllStmt = db.prepare("SELECT k FROM kvstore ORDER BY k");
  const listPrefixStmt = db.prepare(
    "SELECT k FROM kvstore WHERE k LIKE ? ESCAPE '\\' ORDER BY k",
  );

  // Escape LIKE wildcards so a prefix is matched literally.
  const likePrefix = (p) =>
    p.replace(/[\\%_]/g, (c) => "\\" + c) + "%";

  return {
    async get(k) {
      const row = getStmt.get(String(k));
      return row ? row.v : null;
    },
    async put(k, v) {
      putStmt.run(String(k), String(v), Date.now());
    },
    async delete(k) {
      delStmt.run(String(k));
    },
    async list({ prefix = "" } = {}) {
      const rows = prefix
        ? listPrefixStmt.all(likePrefix(prefix))
        : listAllStmt.all();
      return rows.map((r) => ({ name: r.k }));
    },
    close() {
      db.close();
    },
    raw: db,
  };
}

export default openKv;
