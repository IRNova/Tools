// Nova VPS agent: TLS certificate provisioning for the "add a domain" flow.
//
// A fresh node runs a self-signed cert (the app's "no domain" mode). To move to
// a real domain with a trusted cert, the panel/app/installer call provisionCert
// with one of:
//   - method "letsencrypt": certbot standalone gets a free cert (needs port 80
//     reachable). A renewal deploy-hook keeps /etc/nova/origin.* in sync.
//   - method "origin": the user pastes a Cloudflare Origin Certificate + key
//     (Full-strict path, no open port needed).
// Either way the cert lands at /etc/nova/origin.{pem,key}; the caller then sets
// host=domain, insecure=false and reloads xray.

import {
  writeFileSync,
  copyFileSync,
  mkdirSync,
} from "node:fs";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const pExecFile = promisify(execFile);

const DOMAIN_RE =
  /^(?=.{1,253}$)([a-z0-9](-?[a-z0-9])*\.)+[a-z]{2,}$/i;

export function isValidDomain(d) {
  return typeof d === "string" && DOMAIN_RE.test(d.trim());
}

/**
 * Provision + install a trusted cert for `domain` at certPem/certKey.
 * Throws on any failure (invalid input, certbot error, ...).
 */
export async function provisionCert({
  domain,
  method = "letsencrypt",
  cert = "",
  key = "",
  email = "",
  certPem = "/etc/nova/origin.pem",
  certKey = "/etc/nova/origin.key",
  certGroup = "nogroup",
  runExec = pExecFile,
}) {
  const d = String(domain || "").trim().toLowerCase();
  if (!isValidDomain(d)) throw new Error("invalid domain");

  if (method === "origin" || method === "manual") {
    if (!/BEGIN CERTIFICATE/.test(cert) || !/PRIVATE KEY/.test(key)) {
      throw new Error("paste a valid certificate and private key");
    }
    writeFileSync(certPem, cert.trim() + "\n");
    writeFileSync(certKey, key.trim() + "\n");
  } else {
    await ensureCertbot(runExec);
    const args = [
      "certonly",
      "--standalone",
      "--non-interactive",
      "--agree-tos",
      "--preferred-challenges",
      "http",
      "-d",
      d,
    ];
    if (email && /@/.test(email)) args.push("-m", email, "--no-eff-email");
    else args.push("--register-unsafely-without-email");
    // certbot binds :80 for the HTTP-01 challenge; it must be reachable.
    await runExec("certbot", args, { timeout: 150_000 });
    const live = `/etc/letsencrypt/live/${d}`;
    copyFileSync(`${live}/fullchain.pem`, certPem);
    copyFileSync(`${live}/privkey.pem`, certKey);
    await installRenewHook({ certPem, certKey, certGroup, runExec });
  }
  await fixPerms({ certPem, certKey, certGroup, runExec });
  return { domain: d };
}

/** Regenerate a self-signed cert (revert to the no-domain / insecure mode). */
export async function genSelfSigned({
  host,
  certPem = "/etc/nova/origin.pem",
  certKey = "/etc/nova/origin.key",
  certGroup = "nogroup",
  runExec = pExecFile,
}) {
  const cn = String(host || "nova.local").trim();
  await runExec(
    "openssl",
    [
      "req", "-x509", "-newkey", "rsa:2048", "-sha256", "-days", "3650",
      "-nodes", "-keyout", certKey, "-out", certPem, "-subj", `/CN=${cn}`,
    ],
    { timeout: 30_000 },
  );
  await fixPerms({ certPem, certKey, certGroup, runExec });
}

async function ensureCertbot(runExec) {
  try {
    await runExec("bash", ["-c", "command -v certbot"], { timeout: 5000 });
    return;
  } catch {}
  await runExec(
    "bash",
    [
      "-c",
      "DEBIAN_FRONTEND=noninteractive apt-get update -y && apt-get install -y certbot",
    ],
    { timeout: 180_000 },
  );
}

async function fixPerms({ certPem, certKey, certGroup, runExec }) {
  try {
    await runExec("chgrp", [certGroup, certPem, certKey], { timeout: 10_000 });
  } catch {}
  await runExec("chmod", ["640", certPem, certKey], { timeout: 10_000 });
}

// certbot renews to /etc/letsencrypt/live/*; this deploy hook copies the fresh
// cert into Nova's origin paths and reloads xray so renewal is hands-off.
async function installRenewHook({ certPem, certKey, certGroup, runExec }) {
  const dir = "/etc/letsencrypt/renewal-hooks/deploy";
  mkdirSync(dir, { recursive: true });
  const hook = `${dir}/nova-reload.sh`;
  writeFileSync(
    hook,
    `#!/bin/bash
d="\${RENEWED_LINEAGE:-}"
[ -n "$d" ] || exit 0
cp "$d/fullchain.pem" ${certPem}
cp "$d/privkey.pem" ${certKey}
chgrp ${certGroup} ${certPem} ${certKey} 2>/dev/null || true
chmod 640 ${certPem} ${certKey}
systemctl restart xray 2>/dev/null || true
`,
  );
  await runExec("chmod", ["+x", hook], { timeout: 5000 });
}
