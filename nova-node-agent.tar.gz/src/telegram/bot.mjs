// Nova node Telegram command bot.
//
// Upgrades the notify-only integration (server.notifyTelegram) into a full
// command bot. It runs INSIDE the single agent process via long-poll getUpdates
// (no extra port, no public webhook), so it works behind Cloudflare + xray on
// :443 unchanged. Authorization is an admin chat-id allowlist (tgAdminChatIds[],
// falling back to the single tgChatId). Every command calls the SAME exported
// service functions the panel and the REST API use, so there is one code path.
//
// Toggle: settings.enableTelegram && settings.tgBotEnabled && settings.tgBotToken.
// The loop re-reads settings each cycle, so turning it on/off in the panel takes
// effect within a few seconds with no restart.

import {
  getSettings,
  applyUserAction,
  resetUserUsage,
  readDashboard,
  subIdFor,
} from "../server.mjs";

function api(token, method) {
  return `https://api.telegram.org/bot${token}/${method}`;
}

async function tg(token, method, body, timeoutMs = 15_000) {
  const r = await fetch(api(token, method), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(timeoutMs),
  });
  return r.json();
}

// Who may command the bot: the explicit allowlist if set, else the single
// notification chat id. Everyone else is ignored silently (no reply, so the bot
// never leaks its existence to a stranger who guesses the username).
function allowed(s, chatId) {
  const list = Array.isArray(s.tgAdminChatIds) && s.tgAdminChatIds.length
    ? s.tgAdminChatIds.map((x) => String(x).trim())
    : (s.tgChatId ? [String(s.tgChatId)] : []);
  return list.includes(String(chatId));
}

function fmtBytes(n) {
  n = Number(n) || 0;
  const u = ["B", "KB", "MB", "GB", "TB"];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(i ? 1 : 0)} ${u[i]}`;
}

function esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

const HELP = [
  "<b>Nova node bot</b>",
  "/status - node health + counts",
  "/users - list users",
  "/user &lt;id&gt; - one user's usage + sub link",
  "/add &lt;name&gt; - create a user",
  "/enable &lt;id&gt; - enable a user",
  "/disable &lt;id&gt; - disable a user",
  "/reset &lt;id&gt; - reset a user's traffic",
  "/help - this message",
].join("\n");

async function usageOf(kv, id) {
  const [t, up, dn] = await Promise.all([
    kv.get(`uusage:${id}`), kv.get(`uusage-up:${id}`), kv.get(`uusage-dn:${id}`),
  ]);
  return { used: Number(t || 0), up: Number(up || 0), down: Number(dn || 0) };
}

function subUrlFor(s, u) {
  const host = String(s.host || "").split(":")[0];
  return host ? `https://${host}/sub?u=${subIdFor(s, u)}` : "(set a host to get a sub link)";
}

export async function handleCommand(kv, s, text, opts) {
  return handle(kv, s, text, opts);
}

async function handle(kv, s, text, opts) {
  const parts = text.trim().split(/\s+/);
  const cmd = (parts[0] || "").toLowerCase();
  const arg = parts.slice(1).join(" ").trim();

  if (cmd === "/start" || cmd === "/help") return HELP;

  if (cmd === "/status") {
    const d = await readDashboard(kv, opts);
    const sys = d.system || {};
    return [
      "<b>Node status</b>",
      `Host: ${esc(d.host || "(none)")} (${d.tls})`,
      `Users: ${d.counts.usersEnabled}/${d.counts.users} enabled`,
      `Inbounds: ${d.counts.inbounds}`,
      sys.cpu != null ? `CPU: ${sys.cpu}%  Mem: ${sys.memUsedPct != null ? sys.memUsedPct + "%" : "?"}` : "",
      sys.xrayVersion ? `Xray: ${esc(sys.xrayVersion)}` : "",
    ].filter(Boolean).join("\n");
  }

  if (cmd === "/users") {
    const users = (s.users || []);
    if (!users.length) return "No users yet. /add &lt;name&gt;";
    const rows = await Promise.all(users.slice(0, 40).map(async (u) => {
      const id = u.id || u.uuid;
      const { used } = await usageOf(kv, id);
      const flag = u.enabled === false ? "⛔" : "✅";
      return `${flag} <code>${esc(id)}</code> ${esc(u.name || u.email || "")} - ${fmtBytes(used)}`;
    }));
    const extra = users.length > 40 ? `\n… and ${users.length - 40} more` : "";
    return `<b>Users (${users.length})</b>\n` + rows.join("\n") + extra;
  }

  if (cmd === "/user") {
    if (!arg) return "Usage: /user &lt;id&gt;";
    const u = (s.users || []).find((x) => (x.id || x.uuid) === arg || x.name === arg || x.email === arg);
    if (!u) return "User not found.";
    const id = u.id || u.uuid;
    const { used, up, down } = await usageOf(kv, id);
    const quota = Number(u.quotaBytes || 0);
    return [
      `<b>${esc(u.name || u.email || id)}</b>`,
      `id: <code>${esc(id)}</code>  ${u.enabled === false ? "⛔ disabled" : "✅ enabled"}`,
      `Used: ${fmtBytes(used)}${quota ? " / " + fmtBytes(quota) : ""}`,
      `Up: ${fmtBytes(up)}  Down: ${fmtBytes(down)}`,
      u.expiry ? `Expiry: ${esc(u.expiry)}` : "",
      `Sub: ${esc(subUrlFor(s, u))}`,
    ].filter(Boolean).join("\n");
  }

  if (cmd === "/add") {
    if (!arg) return "Usage: /add &lt;name&gt;";
    const r = await applyUserAction(kv, { action: "add", user: { name: arg, email: arg } }, opts);
    const u = r.user;
    const fresh = await getSettings(kv);
    return `✅ Added <b>${esc(arg)}</b>\nid: <code>${esc(u.id)}</code>\nSub: ${esc(subUrlFor(fresh, u))}`;
  }

  if (cmd === "/enable" || cmd === "/disable") {
    if (!arg) return `Usage: ${cmd} &lt;id&gt;`;
    const u = (s.users || []).find((x) => (x.id || x.uuid) === arg);
    if (!u) return "User not found.";
    await applyUserAction(kv, { action: "update", user: { id: u.id, enabled: cmd === "/enable" } }, opts);
    return `${cmd === "/enable" ? "✅ Enabled" : "⛔ Disabled"} <code>${esc(u.id)}</code>`;
  }

  if (cmd === "/reset") {
    if (!arg) return "Usage: /reset &lt;id&gt;";
    const u = (s.users || []).find((x) => (x.id || x.uuid) === arg);
    if (!u) return "User not found.";
    await resetUserUsage(kv, u.id || u.uuid);
    return `♻️ Traffic reset for <code>${esc(u.id)}</code>`;
  }

  return "Unknown command. /help";
}

/**
 * Start the long-poll command loop. Returns { stop() }. Only bin/ should call
 * this (never createServer), so tests never spawn a network poller.
 */
export function runTelegramBot(kv, opts = {}) {
  let stopped = false;
  let failures = 0;

  function schedule(ms) {
    if (stopped) return;
    const t = setTimeout(loop, ms);
    t.unref?.();
  }

  async function loop() {
    if (stopped) return;
    try {
      const s = await getSettings(kv);
      if (s.enableTelegram !== true || s.tgBotEnabled !== true || !s.tgBotToken) {
        // Bot disabled: idle, re-checking settings periodically.
        return schedule(4000);
      }
      const offset = Number((await kv.get("tg:offset")) || 0);
      // Long-poll: getUpdates blocks up to 50s server-side; give the fetch headroom.
      const res = await tg(s.tgBotToken, "getUpdates",
        { offset, timeout: 50, allowed_updates: ["message"] }, 60_000);
      failures = 0;
      if (res && res.ok && Array.isArray(res.result)) {
        for (const upd of res.result) {
          await kv.put("tg:offset", String(upd.update_id + 1));
          const msg = upd.message;
          if (!msg || typeof msg.text !== "string") continue;
          const chatId = msg.chat && msg.chat.id;
          if (!allowed(s, chatId)) continue; // ignore non-admins silently
          let reply;
          try {
            reply = await handle(kv, s, msg.text, opts);
          } catch (e) {
            reply = "Error: " + esc((e && e.message) || e);
          }
          if (reply) {
            await tg(s.tgBotToken, "sendMessage",
              { chat_id: chatId, text: reply, parse_mode: "HTML", disable_web_page_preview: true })
              .catch(() => {});
          }
        }
      }
      schedule(0);
    } catch {
      // Network hiccup / Telegram 5xx: back off, never crash the process.
      failures++;
      schedule(Math.min(30_000, 2000 * failures));
    }
  }

  schedule(800);
  return { stop() { stopped = true; } };
}
