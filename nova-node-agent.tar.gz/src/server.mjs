// Nova VPS agent: plain node:http server (no framework).
//
// Routes the subset of the Nova panel contract the MVP needs, backed by the
// SQLite KV. The admin's user registry lives inside "network-settings.json" as
// users[], exactly like the panel, so the same docs load unchanged. Any user
// change is pushed to xray via manager.applyUsers and re-persisted.
//
// Session cookies are pinned to the client User-Agent (the Nova desktop client
// sends "Nova/1.0.0 (desktop; sing-box)"); see src/auth.mjs.

import { createServer as httpCreateServer } from "node:http";
import { randomUUID, randomBytes, timingSafeEqual } from "node:crypto";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import os from "node:os";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const pExecFile = promisify(execFile);

// The browser admin dashboard, served on the same origin as the API. Loaded
// once at startup; a bare 200 fallback if the file is missing (API still works).
const PANEL_HTML = (() => {
  try {
    return readFileSync(
      join(dirname(fileURLToPath(import.meta.url)), "web", "panel.html"),
      "utf8",
    );
  } catch {
    return "<!doctype html><title>Nova</title><p>Panel UI not installed.</p>";
  }
})();
import {
  makeSession,
  verifySession,
  checkPassword,
  setPassword,
  readAuthCookie,
  clearSessionCookie,
} from "./auth.mjs";
import { applyUsers } from "./xray/manager.mjs";
import { buildSub } from "./subscription.mjs";
import { provisionCert, genSelfSigned, isValidDomain } from "./cert.mjs";
import {
  normalizeInbound,
  validateInbound,
  genRealityKeys,
  genShortId,
  genSSPassword,
} from "./xray/inbounds.mjs";
import { registerWarp } from "./xray/warp.mjs";

export const BUILD = "nova-node-agent/0.1.0";
const SETTINGS_KEY = "network-settings.json";
const MAX_BODY = 1 << 20; // 1 MiB

const UUID_RE =
  /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
const WSPATH_RE = /^\/[\w./-]*$/;

// --- registry write serialization (H1) -------------------------------------
// Every registry mutation reads settings, mutates, writes, then applies to xray.
// Without serialization two concurrent writes clobber each other and race the
// xray apply. A per-kv promise chain makes each mutation atomic end to end.
class Mutex {
  constructor() {
    this.tail = Promise.resolve();
  }
  run(fn) {
    const result = this.tail.then(() => fn());
    // Keep the chain alive whether fn resolves or rejects.
    this.tail = result.then(
      () => {},
      () => {},
    );
    return result;
  }
}
const kvLocks = new WeakMap();
function kvLock(kv) {
  let m = kvLocks.get(kv);
  if (!m) {
    m = new Mutex();
    kvLocks.set(kv, m);
  }
  return m;
}

// --- input validation (H4) -------------------------------------------------
// A single fat-fingered admin PUT must not be able to write a config.json xray
// cannot parse and brick the node on restart.
function validateUser(u) {
  if (!u || typeof u !== "object") throw new HttpError(400, "invalid user");
  const uuid = u.uuid || u.id;
  if (!uuid || !UUID_RE.test(String(uuid))) {
    throw new HttpError(400, "user requires a valid uuid");
  }
  const label = u.email || u.id;
  if (!label || !String(label).trim()) {
    throw new HttpError(400, "user requires a non-empty id/email");
  }
}

function validateWsPath(p) {
  if (p === undefined || p === null) return;
  if (typeof p !== "string" || !WSPATH_RE.test(p)) {
    throw new HttpError(400, "invalid wsPath");
  }
}

// --- settings / registry helpers (shared with the smoke test) --------------

function defaultSettings() {
  return {
    host: "",
    wsPath: "/nova-" + randomBytes(3).toString("hex"),
    subToken: randomBytes(16).toString("hex"),
    users: [],
  };
}

/** Load the settings doc, creating a default one (with a random sub token). */
export async function getSettings(kv) {
  const raw = await kv.get(SETTINGS_KEY);
  if (raw) {
    try {
      const doc = JSON.parse(raw);
      if (!Array.isArray(doc.users)) doc.users = [];
      return doc;
    } catch {
      // fall through and reset a corrupt doc
    }
  }
  const doc = defaultSettings();
  await kv.put(SETTINGS_KEY, JSON.stringify(doc));
  return doc;
}

export async function putSettings(kv, doc) {
  await kv.put(SETTINGS_KEY, JSON.stringify(doc));
  return doc;
}

// The xray-generation options derived from a settings doc. Single source of
// truth so every applyUsers call serves the same wsPath, protocols, the
// data-driven standalone inbounds (Reality, gRPC, XHTTP, Shadowsocks, ...), and
// the routing/WARP/DNS/fragment options (the whole settings doc is the `net`
// bag routing.mjs reads). The registered WARP account, if any, is read from KV.
async function xrayOptsFor(kv, s) {
  let warpAccount = null;
  try {
    warpAccount = JSON.parse((await kv.get("warp-account.json")) || "null");
  } catch {}
  return {
    wsPath: s.wsPath,
    protocols: s.protocols,
    inbounds: s.inbounds || [],
    net: s,
    warpAccount,
  };
}

// The front (:443) and api (:10085) ports a standalone inbound may not reuse.
const FRONT_PORT = 443;
const API_PORT = 10085;

function inboundPortConflict(inbounds, inb) {
  if (inb.port === FRONT_PORT) return `port ${FRONT_PORT} is the main front port`;
  if (inb.port === API_PORT) return `port ${API_PORT} is reserved`;
  for (const o of inbounds || []) {
    if (o.id !== inb.id && Number(o.port) === Number(inb.port)) {
      return `port ${inb.port} is already used by another inbound`;
    }
  }
  return null;
}

/**
 * Apply a user CRUD action, persist the registry, and push it to xray.
 * @param {object} action  { action: "add"|"update"|"delete", user }
 * @param {object} opts     managerOpts forwarded to applyUsers
 * @returns {Promise<{settings:object, user:object|null, apply:object}>}
 */
export async function applyUserAction(kv, action, opts = {}) {
  return kvLock(kv).run(async () => {
    const settings = await getSettings(kv);
    const prev = settings.users.slice();
    const { action: verb, user = {} } = action || {};
    let touched = null;

    if (verb === "add") {
      touched = {
        id: user.id || "u_" + randomBytes(5).toString("hex"),
        uuid: user.uuid || randomUUID(),
        email: user.email || user.id || "",
        enabled: user.enabled !== false,
        ...pickOptional(user),
      };
      if (!touched.email) touched.email = touched.id;
      validateUser(touched);
      // Idempotent: replace a user with the same id or email instead of adding
      // a duplicate (xray rejects two clients that share an email).
      const dup = settings.users.findIndex(
        (u) => u.id === touched.id || String(u.email || u.id) === touched.email,
      );
      if (dup >= 0) settings.users[dup] = touched;
      else settings.users.push(touched);
    } else if (verb === "update") {
      const i = settings.users.findIndex((u) => u.id === user.id);
      if (i < 0) throw new HttpError(404, "user not found");
      touched = { ...settings.users[i], ...user };
      validateUser(touched);
      settings.users[i] = touched;
    } else if (verb === "delete") {
      const i = settings.users.findIndex((u) => u.id === user.id);
      if (i < 0) throw new HttpError(404, "user not found");
      touched = settings.users[i];
      settings.users.splice(i, 1);
    } else {
      throw new HttpError(400, "unknown action");
    }

    await putSettings(kv, settings);

    // A single-protocol (VLESS-only) node can hot-patch the client list. With
    // VMess/Trojan also on, the user lives on several inbounds, so hot-patching
    // just vless-ws would leave the others stale, force a full reload instead.
    const apply = await applyUsers(settings.users, {
      prev,
      forceReload: isMultiProtocol(settings.protocols),
      xrayOpts: await xrayOptsFor(kv, settings),
      ...(opts.managerOpts || {}),
    });

    return { settings, user: touched, apply };
  });
}

function pickOptional(user) {
  const out = {};
  for (const k of ["quotaBytes", "expiry", "name"]) {
    if (user[k] !== undefined) out[k] = user[k];
  }
  return out;
}

/** Per-user total usage from the "uusage:<id>" keys. */
export async function usageData(kv) {
  const keys = await kv.list({ prefix: "uusage:" });
  const usage = {};
  for (const { name } of keys) {
    const id = name.slice("uusage:".length);
    usage[id] = Number((await kv.get(name)) || 0);
  }
  return usage;
}

// --- dashboard: real VPS stats a Cloudflare Worker can never show -----------

// Live host stats (cpu load, memory, disk, uptime) + service health. Runs
// straight on the node; `df`/`systemctl` are best-effort so it degrades to just
// the os-module numbers on a box without them (or in dev).
async function systemStats(runExec) {
  const cpus = os.cpus() || [];
  const load1 = (os.loadavg() || [0])[0];
  const totalmem = os.totalmem();
  const freemem = os.freemem();
  const stat = {
    hostname: os.hostname(),
    platform: `${os.type()} ${os.release()}`,
    uptime: Math.round(os.uptime()),
    cpu: { cores: cpus.length, model: cpus[0] ? cpus[0].model : "", load1, pct: cpus.length ? Math.min(100, Math.round((load1 / cpus.length) * 100)) : 0 },
    mem: { total: totalmem, used: totalmem - freemem, pct: totalmem ? Math.round(((totalmem - freemem) / totalmem) * 100) : 0 },
    disk: null,
    xray: false,
    singbox: false,
  };
  if (runExec) {
    try {
      const { stdout } = await runExec("df", ["-kP", "/"], { timeout: 4000 });
      const line = stdout.trim().split("\n").pop().split(/\s+/);
      const total = Number(line[1]) * 1024, used = Number(line[2]) * 1024;
      if (total > 0) stat.disk = { total, used, pct: Math.round((used / total) * 100) };
    } catch {}
    for (const [svc, key] of [["xray", "xray"], ["sing-box", "singbox"]]) {
      try {
        const { stdout } = await runExec("systemctl", ["is-active", svc], { timeout: 4000 });
        stat[key] = stdout.trim() === "active";
      } catch {}
    }
  }
  return stat;
}

// Total + today + a `days`-long daily series of traffic, summed across users
// from the uusage / uusage-d:<id>:<date> buckets the stats bridge writes.
async function trafficStats(kv, { days = 14, now = new Date() } = {}) {
  let total = 0;
  for (const { name } of await kv.list({ prefix: "uusage:" })) {
    total += Number((await kv.get(name)) || 0);
  }
  const perDay = new Map();
  for (const { name } of await kv.list({ prefix: "uusage-d:" })) {
    const day = name.slice(name.lastIndexOf(":") + 1);
    perDay.set(day, (perDay.get(day) || 0) + Number((await kv.get(name)) || 0));
  }
  const series = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 86400000).toISOString().slice(0, 10);
    series.push({ date: d, bytes: perDay.get(d) || 0 });
  }
  const today = now.toISOString().slice(0, 10);
  return { total, today: perDay.get(today) || 0, series };
}

// The server's own geo + ISP, cached in KV (one lookup, best-effort). Lets the
// dashboard show "City, Country" and the ISP, like the main panel, but real.
async function serverGeo(kv, { fetchImpl = fetch } = {}) {
  try {
    const cached = JSON.parse((await kv.get("geo:self")) || "null");
    if (cached && cached.country) return cached;
  } catch {}
  try {
    const r = await fetchImpl("http://ip-api.com/json/?fields=status,country,countryCode,city,isp,query", {
      signal: AbortSignal.timeout(4000),
    });
    const d = await r.json();
    if (d && d.status === "success") {
      const geo = { country: d.country, countryCode: d.countryCode, city: d.city, isp: d.isp, ip: d.query };
      await kv.put("geo:self", JSON.stringify(geo));
      return geo;
    }
  } catch {}
  return null;
}

// A small ring buffer of admin activity (logins, changes), newest first.
async function logActivity(kv, action, req) {
  try {
    const ip = (req && (req.headers["x-forwarded-for"] || req.socket?.remoteAddress)) || "";
    const list = JSON.parse((await kv.get("activity:log")) || "[]");
    list.unshift({ t: Date.now(), action, ip: String(ip).split(",")[0].trim() });
    await kv.put("activity:log", JSON.stringify(list.slice(0, 100)));
  } catch {}
}

// --- HTTP server -----------------------------------------------------------

/**
 * @param {object} kv        SQLite KV store
 * @param {object} opts
 *   managerOpts  forwarded to applyUsers (e.g. { exec:false } for dev)
 * @returns {import("node:http").Server}
 */
export function createServer(kv, opts = {}) {
  const rate = new RateLimiter(10, 60_000); // 10 login attempts / IP / minute

  const server = httpCreateServer(async (req, res) => {
    try {
      await route(req, res, kv, opts, rate);
    } catch (err) {
      if (err instanceof HttpError) {
        sendJson(res, err.status, { error: err.message });
      } else {
        sendJson(res, 500, { error: "internal error" });
      }
    }
  });
  return server;
}

async function route(req, res, kv, opts, rate) {
  const url = new URL(req.url, "http://localhost");
  const path = url.pathname;
  const method = req.method || "GET";
  const ua = req.headers["user-agent"] || "";

  // Public endpoints -------------------------------------------------------

  // The browser dashboard (a single-page app). Served at the root and a couple
  // of friendly aliases; all its data comes from the API routes below over the
  // same origin. xray's TLS front on :443 forwards non-tunnel requests here, so
  // visiting https://<vps>/ in a browser lands on this.
  if (
    method === "GET" &&
    (path === "/" || path === "/index.html" || path === "/panel")
  ) {
    res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
    return res.end(PANEL_HTML);
  }

  if (path === "/install/status" && method === "GET") {
    const configured = !!(await kv.get("admin_pass"));
    return sendJson(res, 200, {
      configured,
      admin: configured,
      store: "sqlite",
      build: BUILD,
    });
  }

  if (path === "/install/set" && method === "POST") {
    if (await kv.get("admin_pass")) {
      throw new HttpError(409, "already configured");
    }
    const body = await readBody(req);
    const password = fieldFrom(body, "password");
    if (!password || String(password).length < 6) {
      throw new HttpError(400, "password too short");
    }
    await setPassword(kv, password);
    await getSettings(kv); // materialize default settings on first install
    const sess = await makeSession(kv, { userAgent: ua });
    res.setHeader("Set-Cookie", sess.cookie);
    return sendJson(res, 200, { ok: true });
  }

  if (path === "/login" && method === "POST") {
    const ip = clientIp(req);
    if (!rate.allow(ip)) throw new HttpError(429, "too many attempts");
    const body = await readBody(req);
    const password = fieldFrom(body, "password");
    if (!(await checkPassword(kv, password))) {
      return sendJson(res, 401, { error: "invalid password" });
    }
    rate.reset(ip);
    const sess = await makeSession(kv, { userAgent: ua });
    res.setHeader("Set-Cookie", sess.cookie);
    await logActivity(kv, "Admin sign in", req);
    return sendJson(res, 200, { ok: true });
  }

  if (path === "/logout" && method === "GET") {
    res.setHeader("Set-Cookie", clearSessionCookie());
    return sendJson(res, 200, { ok: true });
  }

  if (path === "/sub" && method === "GET") {
    const settings = await getSettings(kv);
    const token = url.searchParams.get("token") || "";
    if (!settings.subToken || !constEq(token, settings.subToken)) {
      throw new HttpError(403, "bad token");
    }
    const host = settings.host || req.headers["host"] || "";
    const body = await buildSub(settings.users, {
      host: stripPort(host),
      wsPath: settings.wsPath,
      token,
      kv,
      // No-domain nodes serve a self-signed cert; emit allowInsecure=1 links.
      insecure: settings.insecure === true,
      protocols: settings.protocols,
      inbounds: settings.inbounds || [],
      // Standalone inbounds bypass Cloudflare (Reality does its own TLS), so
      // they connect to the node's direct address, not the CF-fronted host.
      directHost: settings.directHost || stripPort(host),
    });
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.setHeader("Profile-Update-Interval", "12");
    return res.end(body);
  }

  // Authenticated endpoints ------------------------------------------------
  const needsAuth = path.startsWith("/admin/");
  if (needsAuth) {
    const cookie = readAuthCookie(req.headers["cookie"] || "");
    const ok = await verifySession(kv, cookie, { userAgent: ua });
    if (!ok) throw new HttpError(401, "unauthorized");
  }

  if (path === "/admin/network-settings.json") {
    if (method === "GET") {
      return sendJson(res, 200, await getSettings(kv));
    }
    if (method === "POST") {
      const body = await readBody(req);
      const doc = parseJson(body);
      const result = await kvLock(kv).run(async () => {
        const settings = await getSettings(kv);
        const prev = settings.users.slice();
        const merged = { ...settings, ...doc };
        if (!Array.isArray(merged.users)) merged.users = settings.users;

        // Reject anything that would produce a config.json xray cannot parse (H4).
        validateWsPath(merged.wsPath);
        for (const u of merged.users) validateUser(u);

        await putSettings(kv, merged);

        // A wsPath change, a protocol-set change, or having multiple protocols
        // is config-only / multi-inbound: xray must be reloaded, it cannot be
        // hot-patched via HandlerService (H3).
        const forceReload =
          merged.wsPath !== settings.wsPath ||
          JSON.stringify(merged.protocols || {}) !==
            JSON.stringify(settings.protocols || {}) ||
          JSON.stringify(merged.inbounds || []) !==
            JSON.stringify(settings.inbounds || []) ||
          isMultiProtocol(merged.protocols);
        return applyUsers(merged.users, {
          prev,
          forceReload,
          xrayOpts: await xrayOptsFor(kv, merged),
          ...(opts.managerOpts || {}),
        });
      });
      await logActivity(kv, "Network settings saved", req);
      return sendJson(res, 200, { ok: true, apply: result });
    }
    throw new HttpError(405, "method not allowed");
  }

  if (path === "/admin/users.json" && method === "POST") {
    const body = await readBody(req);
    const action = parseJson(body);
    const result = await applyUserAction(kv, action, opts);
    await logActivity(kv, `User ${action && action.action === "delete" ? "removed" : action && action.action === "update" ? "updated" : "added"}`, req);
    return sendJson(res, 200, {
      ok: true,
      user: result.user,
      apply: result.apply,
    });
  }

  if (path === "/admin/usage-data" && method === "GET") {
    return sendJson(res, 200, { usage: await usageData(kv) });
  }

  // Live dashboard: real host stats, service health, counts and traffic. The
  // heavy version of what a Cloudflare Worker can only fake.
  if (path === "/admin/dashboard" && method === "GET") {
    const s = await getSettings(kv);
    const canExec = !(opts.managerOpts && opts.managerOpts.exec === false);
    const [sys, traffic, geo] = await Promise.all([
      systemStats(canExec ? pExecFile : null),
      trafficStats(kv),
      serverGeo(kv).catch(() => null),
    ]);
    sys.geo = geo;
    const users = s.users || [];
    return sendJson(res, 200, {
      host: s.host || "",
      tls: s.insecure === true ? "self-signed" : "trusted",
      system: sys,
      traffic,
      counts: {
        users: users.length,
        usersEnabled: users.filter((u) => u.enabled !== false).length,
        inbounds: (s.inbounds || []).filter((i) => i.enabled !== false).length,
      },
      protocols: s.protocols || {},
      warp: { enabled: s.enableWarp === true, calls: s.warpCalls === true },
    });
  }

  // Recent admin activity (logins + changes), newest first.
  if (path === "/admin/activity" && method === "GET") {
    let list = [];
    try {
      list = JSON.parse((await kv.get("activity:log")) || "[]");
    } catch {}
    return sendJson(res, 200, { activity: list });
  }

  // The panel config the Nova client reads. The client imports the node from
  // optimizedSubGeneration.TOKEN (-> /sub?token=), and the admin editor toggles
  // tlsFragment / skipCertVerify / enable0RTT / randomPath. Mirrors the Worker.
  if (path === "/admin/config.json" && method === "GET") {
    const s = await getSettings(kv);
    const first = (s.users || [])[0] || {};
    return sendJson(res, 200, {
      HOST: s.host || "",
      UUID: first.uuid || first.id || "",
      optimizedSubGeneration: { TOKEN: s.subToken || "" },
      tlsFragment: s.tlsFragment === true,
      skipCertVerify: s.insecure === true,
      enable0RTT: s.enable0RTT === true,
      randomPath: s.randomPath === true,
    });
  }
  if (path === "/admin/config.json" && method === "POST") {
    const doc = parseJson(await readBody(req));
    await kvLock(kv).run(async () => {
      const s = await getSettings(kv);
      const merged = { ...s };
      if ("tlsFragment" in doc) merged.tlsFragment = doc.tlsFragment === true;
      if ("skipCertVerify" in doc) merged.insecure = doc.skipCertVerify === true;
      if ("enable0RTT" in doc) merged.enable0RTT = doc.enable0RTT === true;
      if ("randomPath" in doc) merged.randomPath = doc.randomPath === true;
      await putSettings(kv, merged);
    });
    return sendJson(res, 200, { ok: true });
  }

  // Connection info card. A VPS node has no upstream ISP lookup, so this is a
  // valid-but-empty shape (the client tolerates blank fields).
  if (path === "/admin/whoami" && method === "GET") {
    return sendJson(res, 200, {
      asn: 0,
      isp: "",
      country: "",
      city: "",
      carrier: "",
    });
  }

  if (path === "/admin/security/status" && method === "GET") {
    const has = Boolean(await kv.get("admin_pass"));
    return sendJson(res, 200, {
      twofa: false,
      passwordSource: "kv",
      kvSet: has,
    });
  }

  // Custom clean-IP list (raw text), same contract as the Worker's ADD.txt.
  if (path === "/admin/ADD.txt" && method === "GET") {
    const s = await getSettings(kv);
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    return res.end(String(s.customIPs || ""));
  }
  if (path === "/admin/ADD.txt" && method === "POST") {
    const text = String(await readBody(req));
    await kvLock(kv).run(async () => {
      const s = await getSettings(kv);
      await putSettings(kv, { ...s, customIPs: text });
    });
    return sendJson(res, 200, { ok: true });
  }

  // Authenticated snapshot of the subscription (import fallback when the client
  // cannot read the token from config).
  if (path === "/admin/sub-content" && method === "GET") {
    const s = await getSettings(kv);
    const body = await buildSub(s.users, {
      host: stripPort(s.host || ""),
      wsPath: s.wsPath,
      kv,
      insecure: s.insecure === true,
      protocols: s.protocols,
      inbounds: s.inbounds || [],
      directHost: s.directHost || stripPort(s.host || ""),
    });
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    return res.end(body);
  }

  // Current domain / TLS status (idle | provisioning | active | error).
  if (path === "/admin/domain" && method === "GET") {
    const s = await getSettings(kv);
    let st = {};
    try {
      st = JSON.parse((await kv.get("domain:status")) || "{}");
    } catch {}
    return sendJson(res, 200, {
      host: s.host || "",
      tls: s.insecure === true ? "self-signed" : "trusted",
      state: st.state || "idle",
      error: st.error || "",
    });
  }

  // Add a domain (async: certbot can take a minute; poll GET /admin/domain),
  // or clear back to a self-signed / no-domain node.
  if (path === "/admin/domain" && method === "POST") {
    const doc = parseJson(await readBody(req));
    const certGroup = process.env.NOVA_CERT_GROUP || "nogroup";
    if (doc.clear === true) {
      const host = String(doc.host || "").trim();
      await genSelfSigned({ host: host || "nova.local", certGroup });
      await kvLock(kv).run(async () => {
        const s = await getSettings(kv);
        const merged = { ...s, insecure: true, ...(host ? { host } : {}) };
        await putSettings(kv, merged);
        await applyUsers(merged.users, {
          forceReload: true,
          xrayOpts: await xrayOptsFor(kv, merged),
          ...(opts.managerOpts || {}),
        });
      });
      await kv.put("domain:status", JSON.stringify({ state: "idle" }));
      return sendJson(res, 200, { ok: true, tls: "self-signed" });
    }
    const domain = String(doc.domain || "").trim().toLowerCase();
    if (!isValidDomain(domain)) throw new HttpError(400, "invalid domain");
    const cmethod = doc.method === "origin" ? "origin" : "letsencrypt";
    await kv.put("domain:status", JSON.stringify({ state: "provisioning", domain }));
    // Background; the client polls GET /admin/domain for the outcome.
    runDomainJob(kv, opts, {
      domain,
      method: cmethod,
      cert: doc.cert || "",
      key: doc.key || "",
      email: doc.email || "",
      certGroup,
    });
    return sendJson(res, 202, { ok: true, state: "provisioning", host: domain });
  }

  // Standalone inbounds (Reality, gRPC, XHTTP, Shadowsocks, ...). ------------
  if (path === "/admin/inbounds" && method === "GET") {
    const s = await getSettings(kv);
    return sendJson(res, 200, {
      inbounds: (s.inbounds || []).map((i) => (i.tag ? i : normalizeInbound(i))),
      frontPort: FRONT_PORT,
    });
  }

  // A fresh Reality x25519 keypair + shortId, for the panel to prefill a new
  // Reality inbound (also auto-generated on add if omitted).
  if (path === "/admin/reality-keys" && method === "POST") {
    const k = await genRealityKeys(undefined, process.env.NOVA_XRAY_BIN || "xray");
    return sendJson(res, 200, { ...k, shortId: genShortId() });
  }

  // WARP (Cloudflare WireGuard) account: status, register, or clear. Enabling
  // it for routing is the enableWarp/warpCalls toggle in network-settings.
  if (path === "/admin/warp" && method === "GET") {
    let acc = null;
    try {
      acc = JSON.parse((await kv.get("warp-account.json")) || "null");
    } catch {}
    const s = await getSettings(kv);
    return sendJson(res, 200, {
      registered: !!(acc && acc.privateKey),
      endpoint: acc ? acc.endpoint : "",
      addressV4: acc ? acc.addressV4 : "",
      enableWarp: s.enableWarp === true,
      warpMode: s.warpMode || "warp",
      warpCalls: s.warpCalls === true,
    });
  }
  if (path === "/admin/warp" && method === "POST") {
    const doc = parseJson(await readBody(req));
    if (doc.action === "clear") {
      await kv.delete("warp-account.json");
      await kvLock(kv).run(async () => {
        const s = await getSettings(kv);
        const merged = { ...s, enableWarp: false, warpCalls: false };
        await putSettings(kv, merged);
        await applyUsers(merged.users, {
          forceReload: true,
          xrayOpts: await xrayOptsFor(kv, merged),
          ...(opts.managerOpts || {}),
        });
      });
      return sendJson(res, 200, { ok: true, registered: false });
    }
    // Register a fresh account with Cloudflare, then reload so the WireGuard
    // outbound is available (routing turns on via enableWarp/warpCalls).
    let acc;
    try {
      acc = await registerWarp();
    } catch (e) {
      throw new HttpError(502, `WARP registration failed: ${(e && e.message) || e}`);
    }
    await kv.put("warp-account.json", JSON.stringify(acc));
    await kvLock(kv).run(async () => {
      const s = await getSettings(kv);
      await applyUsers(s.users, {
        forceReload: true,
        xrayOpts: await xrayOptsFor(kv, s),
        ...(opts.managerOpts || {}),
      });
    });
    await logActivity(kv, "WARP account registered", req);
    return sendJson(res, 200, { ok: true, registered: true, endpoint: acc.endpoint, addressV4: acc.addressV4 });
  }

  if (path === "/admin/inbounds" && method === "POST") {
    const doc = parseJson(await readBody(req));
    const verb = doc.action || "add";
    const result = await kvLock(kv).run(async () => {
      const s = await getSettings(kv);
      const list = Array.isArray(s.inbounds) ? s.inbounds.slice() : [];
      let saved = null;

      if (verb === "delete" || verb === "toggle") {
        const id = doc.id || (doc.inbound && doc.inbound.id);
        const i = list.findIndex((x) => x.id === id);
        if (i < 0) throw new HttpError(404, "inbound not found");
        if (verb === "delete") list.splice(i, 1);
        else list[i] = { ...list[i], enabled: list[i].enabled === false };
        saved = verb === "toggle" ? list[i] : null;
      } else if (verb === "add" || verb === "update") {
        const inb = normalizeInbound(doc.inbound || {});
        // Auto-provision key material so the panel can create a Reality or
        // Shadowsocks inbound in a single call.
        if (inb.security === "reality") {
          inb.reality = inb.reality || {};
          if (!inb.reality.privateKey || !inb.reality.publicKey) {
            const k = await genRealityKeys(undefined, process.env.NOVA_XRAY_BIN || "xray");
            inb.reality.privateKey = k.privateKey;
            inb.reality.publicKey = k.publicKey;
          }
          if (!Array.isArray(inb.reality.shortIds) || !inb.reality.shortIds.length) {
            inb.reality.shortIds = [genShortId()];
          }
          if (!inb.reality.dest && inb.reality.serverNames && inb.reality.serverNames[0]) {
            inb.reality.dest = `${inb.reality.serverNames[0]}:443`;
          }
        }
        if (inb.protocol === "shadowsocks" && !inb.ssPassword) {
          inb.ssPassword = genSSPassword();
        }
        const v = validateInbound(inb);
        if (!v.ok) throw new HttpError(400, v.error);
        const conflict = inboundPortConflict(list, inb);
        if (conflict) throw new HttpError(409, conflict);
        if (verb === "update") {
          const i = list.findIndex((x) => x.id === inb.id);
          if (i < 0) throw new HttpError(404, "inbound not found");
          inb.tag = list[i].tag || inb.tag; // keep the xray tag stable
          list[i] = inb;
        } else {
          list.push(inb);
        }
        saved = inb;
      } else {
        throw new HttpError(400, "unknown action");
      }

      const merged = { ...s, inbounds: list };
      await putSettings(kv, merged);
      const apply = await applyUsers(merged.users, {
        forceReload: true,
        xrayOpts: await xrayOptsFor(kv, merged),
        ...(opts.managerOpts || {}),
      });
      return { inbounds: list, saved, apply };
    });
    await logActivity(kv, `Inbound ${verb === "delete" ? "removed" : verb === "toggle" ? "toggled" : verb === "update" ? "updated" : "added"}`, req);
    return sendJson(res, 200, { ok: true, ...result });
  }

  throw new HttpError(404, "not found");
}

// Provision a cert for `domain`, then flip the node to trusted-domain mode and
// reload xray. Runs detached from the request; status lives in KV.
async function runDomainJob(kv, opts, { domain, method, cert, key, email, certGroup }) {
  try {
    await provisionCert({ domain, method, cert, key, email, certGroup });
    await kvLock(kv).run(async () => {
      const s = await getSettings(kv);
      const merged = { ...s, host: domain, insecure: false };
      await putSettings(kv, merged);
      await applyUsers(merged.users, {
        forceReload: true,
        xrayOpts: await xrayOptsFor(kv, merged),
        ...(opts.managerOpts || {}),
      });
    });
    await kv.put("domain:status", JSON.stringify({ state: "active", domain }));
  } catch (err) {
    await kv.put(
      "domain:status",
      JSON.stringify({ state: "error", domain, error: String((err && err.message) || err) }),
    );
  }
}

// --- small http utilities --------------------------------------------------

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (c) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject(new HttpError(413, "body too large"));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

// Accept either JSON ({password:...}) or urlencoded (password=...) bodies.
function fieldFrom(body, name) {
  const t = (body || "").trim();
  if (t.startsWith("{")) {
    try {
      return JSON.parse(t)[name];
    } catch {
      return undefined;
    }
  }
  return new URLSearchParams(t).get(name) ?? undefined;
}

function parseJson(body) {
  try {
    return JSON.parse(body || "{}");
  } catch {
    throw new HttpError(400, "invalid JSON");
  }
}

// Derive the client IP from the trusted transport by default. X-Forwarded-For is
// client-spoofable, so honour it only when TRUST_PROXY is set (agent runs behind
// a known proxy). Otherwise a fresh spoofed header per request hands each attempt
// its own rate-limit bucket, defeating the brute-force limiter (H2).
function clientIp(req) {
  if (process.env.TRUST_PROXY) {
    const fwd = req.headers["x-forwarded-for"];
    if (fwd) return String(fwd).split(",")[0].trim();
  }
  return req.socket?.remoteAddress || "unknown";
}

function stripPort(host) {
  return String(host).replace(/:\d+$/, "");
}

// True when the node serves more than VLESS, so a user change spans several
// inbounds and must trigger a full xray reload rather than a vless-ws hot-patch.
function isMultiProtocol(protocols) {
  return Boolean(
    protocols && (protocols.vmess === true || protocols.trojan === true),
  );
}

function constEq(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ba.length !== bb.length) return false;
  return timingSafeEqual(ba, bb);
}

// Fixed-window per-key rate limiter. Expired buckets are swept so a flood of
// distinct (e.g. spoofed) keys cannot grow the map without bound (H2).
class RateLimiter {
  constructor(limit, windowMs) {
    this.limit = limit;
    this.windowMs = windowMs;
    this.hits = new Map();
    this.lastSweep = Date.now();
  }
  sweep(now) {
    if (now - this.lastSweep < this.windowMs) return;
    this.lastSweep = now;
    for (const [k, e] of this.hits) {
      if (now > e.resetAt) this.hits.delete(k);
    }
  }
  allow(key) {
    const now = Date.now();
    this.sweep(now);
    const e = this.hits.get(key);
    if (!e || now > e.resetAt) {
      this.hits.set(key, { count: 1, resetAt: now + this.windowMs });
      return true;
    }
    if (e.count >= this.limit) return false;
    e.count++;
    return true;
  }
  reset(key) {
    this.hits.delete(key);
  }
}

export { HttpError };
