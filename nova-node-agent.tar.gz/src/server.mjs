// Nova VPS agent: plain node:http server (no framework).
//
// Routes the subset of the Nova panel contract the MVP needs, backed by the
// SQLite KV. The admin's user registry lives inside "network-settings.json" as
// users[], exactly like the panel, so the same docs load unchanged. Any user
// change is pushed to xray via manager.applyUsers and re-persisted.
//
// Session cookies are pinned to the client User-Agent (the Nova desktop client
// sends "Nova/1.0.0 (desktop; sing-box)"); see src/auth.mjs.

import { createServer as httpCreateServer } from "node:http";
import { randomUUID, randomBytes, timingSafeEqual, createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import os from "node:os";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const pExecFile = promisify(execFile);

// The browser admin dashboard, served on the same origin as the API. Loaded
// once at startup; a bare 200 fallback if the file is missing (API still works).
const PANEL_HTML = (() => {
  try {
    return readFileSync(
      join(dirname(fileURLToPath(import.meta.url)), "web", "panel.html"),
      "utf8",
    );
  } catch {
    return "<!doctype html><title>Nova</title><p>Panel UI not installed.</p>";
  }
})();

// The per-user subscription page (shown when a human opens their /sub?u=<id>
// link in a browser). Reads window.__NOVA_SUB__ injected by the /sub handler.
const SUBPAGE_HTML = (() => {
  try {
    return readFileSync(
      join(dirname(fileURLToPath(import.meta.url)), "web", "subpage.html"),
      "utf8",
    );
  } catch {
    return "<!doctype html><title>Nova subscription</title><p>Subscription page not installed.</p>";
  }
})();
import {
  makeSession,
  verifySession,
  checkPassword,
  setPassword,
  readAuthCookie,
  clearSessionCookie,
} from "./auth.mjs";
import { applyUsers } from "./xray/manager.mjs";
import { buildSub, parseExpiry } from "./subscription.mjs";
import { enumerateProxies, toClash, toSingbox } from "./sub-formats.mjs";
import { provisionCert, genSelfSigned, isValidDomain } from "./cert.mjs";
import {
  normalizeInbound,
  validateInbound,
  genRealityKeys,
  genShortId,
  genSSPassword,
} from "./xray/inbounds.mjs";
import { registerWarp } from "./xray/warp.mjs";
import { onlineCounts } from "./xray/access.mjs";
import { tunnelOp, tunnelSessionCount } from "./tunnel.mjs";
import * as awg from "./awg.mjs";

export const BUILD = "nova-node-agent/0.2.2";
const SETTINGS_KEY = "network-settings.json";
// Settings that change the generated xray/sing-box config (as opposed to just
// the user list, which hot-patches). A change to any of these forces a reload
// and is validated before it is saved.
const CONFIG_KEYS = [
  "wsPath", "protocols", "inbounds", "insecure", "directHost", "enableIPv6",
  "customRules", "routingRules", "antiCensorship", "blockPorn", "blockBittorrent", "blockQUIC", "enableAdBlock",
  "enableDomesticBypass", "bypassIran", "bypassChina", "bypassRussia",
  "enableWarp", "warpMode", "warpAll", "warpCalls", "warpEndpoint", "warpCleanIp", "warpAmnezia",
  "tlsFragment", "fragmentParams", "chainProxy",
  "enableDoH", "dohProvider", "enableAntiSanctionDNS", "antiSanction",
  "hy2UpMbps", "hy2DownMbps", "hy2Port",
  // Xray Settings page: logs, routing/egress strategy, Prometheus metrics.
  "logLevel", "accessLog", "errorLog", "dnsLog", "maskAddress",
  "routingDomainStrategy", "freedomStrategy", "enableMetrics", "metricsPort",
  // Extra egress paths (per-inbound via routing rules): Tor + Psiphon.
  "enableTor", "torPort", "enablePsiphon", "psiphonPort",
];

// The Hysteria2 (sing-box) UDP listen port. Defaults to 443 (shares the port
// with xray's TCP 443 - QUIC is UDP, so they coexist). Admins can move it to any
// valid port for UDP port-hopping when 443/udp is throttled. Clamped to 1-65535.
function hy2PortOf(s) {
  const n = Number(s && s.hy2Port);
  return Number.isInteger(n) && n >= 1 && n <= 65535 ? n : 443;
}

// A user's per-user subscription id: the secret in their personal
// GET /sub?u=<subId> auto-import link (clients poll it, no admin login). Derived
// from the (secret) subToken plus the user id, so it is stable across restarts,
// unguessable without the token, and needs no extra stored field.
function subIdFor(settings, u) {
  return createHash("sha256")
    .update((settings && settings.subToken ? settings.subToken : "") + ":" + (u.id || u.uuid || ""))
    .digest("hex")
    .slice(0, 24);
}

// One-time phone-home so novaproxy.online can count how many Nova nodes get set
// up, exactly like the worker panel, web installer, bot, and wizard already do
// (same `nova-panel:<host>` hash scheme, so one deployment counts once in the
// site's install total). Fires only on the very first password set. Reports an
// opaque hash of this node's host, never the host itself. Best-effort, bounded to
// 2.5s, fire-and-forget, and fully skippable with the STATS_OPTOUT env var.
function reportInstall(host) {
  try {
    if (["1", "true", "yes"].includes(String(process.env.STATS_OPTOUT || "").toLowerCase())) return;
    if (!host || typeof fetch !== "function") return;
    const id = "w_" + createHash("sha256").update("nova-panel:" + host).digest("hex").slice(0, 32);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 2500);
    fetch("https://novaproxy.online/api/stats", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "install", id }),
      signal: ctrl.signal,
    }).catch(() => {}).finally(() => clearTimeout(timer));
  } catch {
    // best-effort: never block or break setup
  }
}

// Per-ISP client optimization profile: the client detects the carrier (SIM
// MCC+MNC) or public-IP ASN and applies these settings for the best throughput.
// The VALUES here are a starting point; retune them from real measurements. The
// client fetches this from GET /isp-profile so it updates without an app release.
const DEFAULT_ISP_PROFILE = {
  version: 1,
  updated: "",
  default: { fingerprint: "chrome", tlsFragment: false, mux: false, mtu: 1280 },
  isps: [
    { label: "Irancell (MTN)", mccmnc: ["43235"], asn: ["44244"], settings: { fingerprint: "chrome", tlsFragment: true } },
    { label: "MCI (Hamrah-e Aval)", mccmnc: ["43211"], asn: ["197207"], settings: { fingerprint: "randomized", tlsFragment: true } },
    { label: "Rightel", mccmnc: ["43220"], asn: ["57218"], settings: { fingerprint: "firefox", tlsFragment: true } },
    { label: "Shatel", asn: ["31549"], settings: { fingerprint: "chrome", tlsFragment: false } },
    { label: "MobinNet", asn: ["50810"], settings: { fingerprint: "chrome", tlsFragment: true } },
  ],
};
function ispProfileOf(settings) {
  if (settings && settings.ispProfile && typeof settings.ispProfile === "object") return settings.ispProfile;
  if (settings && typeof settings.ispProfile === "string" && settings.ispProfile.trim()) {
    try { return JSON.parse(settings.ispProfile); } catch {}
  }
  return DEFAULT_ISP_PROFILE;
}
const MAX_BODY = 1 << 20; // 1 MiB

const UUID_RE =
  /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
const WSPATH_RE = /^\/[\w./-]*$/;

// --- registry write serialization (H1) -------------------------------------
// Every registry mutation reads settings, mutates, writes, then applies to xray.
// Without serialization two concurrent writes clobber each other and race the
// xray apply. A per-kv promise chain makes each mutation atomic end to end.
class Mutex {
  constructor() {
    this.tail = Promise.resolve();
  }
  run(fn) {
    const result = this.tail.then(() => fn());
    // Keep the chain alive whether fn resolves or rejects.
    this.tail = result.then(
      () => {},
      () => {},
    );
    return result;
  }
}
const kvLocks = new WeakMap();
function kvLock(kv) {
  let m = kvLocks.get(kv);
  if (!m) {
    m = new Mutex();
    kvLocks.set(kv, m);
  }
  return m;
}

// The panel is served THROUGH xray on :443, so a forced xray restart (needed
// when the inbound set changes) briefly drops the panel's own connection. To
// avoid a "Failed to fetch" on the very request that triggered it, the handler
// persists + responds first, then schedules the xray apply here. Rapid changes
// coalesce into a single restart once they settle.
let _applyTimer = null;
function scheduleXrayApply(kv, opts = {}, ms = 500) {
  if (_applyTimer) return; // a restart is already pending; it will pick up the latest settings
  _applyTimer = setTimeout(async () => {
    _applyTimer = null;
    try {
      await kvLock(kv).run(async () => {
        const s = await getSettings(kv);
        return applyUsers(s.users, { forceReload: true, xrayOpts: await xrayOptsFor(kv, s), ...(opts.managerOpts || {}) });
      });
    } catch (e) {
      console.error("deferred xray apply failed:", (e && e.message) || e);
      try { await logActivity(kv, "xray apply failed after an inbound change"); } catch {}
    }
  }, ms);
  if (_applyTimer && _applyTimer.unref) _applyTimer.unref();
}

// WireGuard is a per-user protocol: when settings.protocols.wireguard is on, the
// AmneziaWG server runs and carries one peer per enabled Nova user (each user's
// per-user page then shows their WireGuard config). Coalesced + deferred so a
// burst of user changes results in one interface sync.
let _wgTimer = null;
function scheduleWireguardSync(kv, ms = 700) {
  if (_wgTimer) return;
  _wgTimer = setTimeout(async () => {
    _wgTimer = null;
    try {
      if (!(await awg.awgAvailable())) return;
      await kvLock(kv).run(async () => {
        const s = await getSettings(kv);
        const wgOn = !!(s.protocols && s.protocols.wireguard === true);
        if (wgOn) {
          const a = awg.ensureServer(s);
          a.enabled = true;
          awg.syncUserPeers(a, s.users || []);
          s.awg = a;
          await putSettings(kv, s);
          const live = await awg.liveStatus();
          if (live.up) await awg.syncPeers(a);
          else await awg.applyServer(a);
        } else {
          const a = awg.awgState(s);
          if (a.enabled) { a.enabled = false; s.awg = a; await putSettings(kv, s); await awg.disableServer(); }
        }
      });
    } catch (e) {
      console.error("wireguard sync failed:", (e && e.message) || e);
    }
  }, ms);
  if (_wgTimer && _wgTimer.unref) _wgTimer.unref();
}

// --- input validation (H4) -------------------------------------------------
// A single fat-fingered admin PUT must not be able to write a config.json xray
// cannot parse and brick the node on restart.
function validateUser(u) {
  if (!u || typeof u !== "object") throw new HttpError(400, "invalid user");
  const uuid = u.uuid || u.id;
  if (!uuid || !UUID_RE.test(String(uuid))) {
    throw new HttpError(400, "user requires a valid uuid");
  }
  const label = u.email || u.id;
  if (!label || !String(label).trim()) {
    throw new HttpError(400, "user requires a non-empty id/email");
  }
}

function validateWsPath(p) {
  if (p === undefined || p === null) return;
  if (typeof p !== "string" || !WSPATH_RE.test(p)) {
    throw new HttpError(400, "invalid wsPath");
  }
}

// --- settings / registry helpers (shared with the smoke test) --------------

function defaultSettings() {
  return {
    host: "",
    wsPath: "/nova-" + randomBytes(3).toString("hex"),
    subToken: randomBytes(16).toString("hex"),
    users: [],
  };
}

/** Load the settings doc, creating a default one (with a random sub token). */
export async function getSettings(kv) {
  const raw = await kv.get(SETTINGS_KEY);
  if (raw) {
    try {
      const doc = JSON.parse(raw);
      if (!Array.isArray(doc.users)) doc.users = [];
      return doc;
    } catch {
      // fall through and reset a corrupt doc
    }
  }
  const doc = defaultSettings();
  await kv.put(SETTINGS_KEY, JSON.stringify(doc));
  return doc;
}

export async function putSettings(kv, doc) {
  await kv.put(SETTINGS_KEY, JSON.stringify(doc));
  return doc;
}

// The xray-generation options derived from a settings doc. Single source of
// truth so every applyUsers call serves the same wsPath, protocols, the
// data-driven standalone inbounds (Reality, gRPC, XHTTP, Shadowsocks, ...), and
// the routing/WARP/DNS/fragment options (the whole settings doc is the `net`
// bag routing.mjs reads). The registered WARP account, if any, is read from KV.
async function xrayOptsFor(kv, s) {
  let warpAccount = null;
  try {
    warpAccount = JSON.parse((await kv.get("warp-account.json")) || "null");
  } catch {}
  return {
    wsPath: s.wsPath,
    protocols: s.protocols,
    inbounds: s.inbounds || [],
    net: s,
    warpAccount,
    hy2Port: hy2PortOf(s),
  };
}

// The front (:443) and api (:10085) ports a standalone inbound may not reuse.
const FRONT_PORT = 443;
const API_PORT = 10085;

function inboundPortConflict(inbounds, inb) {
  if (inb.port === FRONT_PORT) return `port ${FRONT_PORT} is the main front port`;
  if (inb.port === API_PORT) return `port ${API_PORT} is reserved`;
  for (const o of inbounds || []) {
    if (o.id !== inb.id && Number(o.port) === Number(inb.port)) {
      return `port ${inb.port} is already used by another inbound`;
    }
  }
  return null;
}

/**
 * Apply a user CRUD action, persist the registry, and push it to xray.
 * @param {object} action  { action: "add"|"update"|"delete", user }
 * @param {object} opts     managerOpts forwarded to applyUsers
 * @returns {Promise<{settings:object, user:object|null, apply:object}>}
 */
export async function applyUserAction(kv, action, opts = {}) {
  return kvLock(kv).run(async () => {
    const settings = await getSettings(kv);
    const prev = settings.users.slice();
    const { action: verb, user = {} } = action || {};
    let touched = null;

    if (verb === "add") {
      touched = {
        id: user.id || "u_" + randomBytes(5).toString("hex"),
        uuid: user.uuid || randomUUID(),
        email: user.email || user.id || "",
        enabled: user.enabled !== false,
        ...pickOptional(user),
      };
      if (!touched.email) touched.email = touched.id;
      validateUser(touched);
      // Idempotent: replace a user with the same id or email instead of adding
      // a duplicate (xray rejects two clients that share an email).
      const dup = settings.users.findIndex(
        (u) => u.id === touched.id || String(u.email || u.id) === touched.email,
      );
      if (dup >= 0) settings.users[dup] = touched;
      else settings.users.push(touched);
    } else if (verb === "update") {
      const i = settings.users.findIndex((u) => u.id === user.id);
      if (i < 0) throw new HttpError(404, "user not found");
      touched = { ...settings.users[i], ...user };
      validateUser(touched);
      settings.users[i] = touched;
    } else if (verb === "delete") {
      const i = settings.users.findIndex((u) => u.id === user.id);
      if (i < 0) throw new HttpError(404, "user not found");
      touched = settings.users[i];
      settings.users.splice(i, 1);
    } else {
      throw new HttpError(400, "unknown action");
    }

    await putSettings(kv, settings);

    // A single-protocol (VLESS-only) node can hot-patch the client list. With
    // VMess/Trojan also on, the user lives on several inbounds, so hot-patching
    // just vless-ws would leave the others stale, force a full reload instead.
    const apply = await applyUsers(settings.users, {
      prev,
      forceReload: isMultiProtocol(settings.protocols),
      xrayOpts: await xrayOptsFor(kv, settings),
      ...(opts.managerOpts || {}),
    });

    return { settings, user: touched, apply };
  });
}

function pickOptional(user) {
  const out = {};
  for (const k of ["quotaBytes", "quotaUpBytes", "quotaDownBytes", "expiry", "name", "note", "ipLimit", "resetStrategy", "expireDays"]) {
    if (user[k] !== undefined) out[k] = user[k];
  }
  return out;
}

/** Per-user total usage from the "uusage:<id>" keys. */
export async function usageData(kv) {
  const keys = await kv.list({ prefix: "uusage:" });
  const usage = {};
  for (const { name } of keys) {
    const id = name.slice("uusage:".length);
    usage[id] = Number((await kv.get(name)) || 0);
  }
  return usage;
}

// --- dashboard: real VPS stats a Cloudflare Worker can never show -----------

// Live host stats (cpu load, memory, disk, uptime) + service health. Runs
// straight on the node; `df`/`systemctl` are best-effort so it degrades to just
// the os-module numbers on a box without them (or in dev).
async function systemStats(runExec) {
  const cpus = os.cpus() || [];
  const load1 = (os.loadavg() || [0])[0];
  const totalmem = os.totalmem();
  const freemem = os.freemem();
  const stat = {
    hostname: os.hostname(),
    platform: `${os.type()} ${os.release()}`,
    uptime: Math.round(os.uptime()),
    cpu: { cores: cpus.length, model: cpus[0] ? cpus[0].model : "", load1, pct: cpus.length ? Math.min(100, Math.round((load1 / cpus.length) * 100)) : 0 },
    mem: { total: totalmem, used: totalmem - freemem, pct: totalmem ? Math.round(((totalmem - freemem) / totalmem) * 100) : 0 },
    disk: null,
    xray: false,
    singbox: false,
  };
  if (runExec) {
    try {
      const { stdout } = await runExec("df", ["-kP", "/"], { timeout: 4000 });
      const line = stdout.trim().split("\n").pop().split(/\s+/);
      const total = Number(line[1]) * 1024, used = Number(line[2]) * 1024;
      if (total > 0) stat.disk = { total, used, pct: Math.round((used / total) * 100) };
    } catch {}
    for (const [svc, key] of [["xray", "xray"], ["sing-box", "singbox"]]) {
      try {
        const { stdout } = await runExec("systemctl", ["is-active", svc], { timeout: 4000 });
        stat[key] = stdout.trim() === "active";
      } catch {}
    }
    // xray version (fixes a "vUnknown" card when detection was missing).
    try {
      const { stdout } = await runExec("xray", ["version"], { timeout: 4000 });
      const m = stdout.match(/Xray[^\d]*([\d.]+)/i);
      if (m) stat.xrayVersion = "v" + m[1];
    } catch {}
    // xray uptime (seconds) from its unit's active-enter time, so the dashboard
    // can show OS uptime and xray uptime separately.
    try {
      const { stdout } = await runExec("systemctl", ["show", "xray", "-p", "ActiveEnterTimestampMonotonic"], { timeout: 4000 });
      const us = Number((stdout.split("=")[1] || "").trim());
      if (us > 0) stat.xrayUptime = Math.max(0, Math.round(os.uptime() - us / 1e6));
    } catch {}
    // Live connection counts (TCP established / UDP), best-effort via ss.
    try {
      const { stdout } = await runExec("sh", ["-c", "ss -tan 2>/dev/null | grep -c ESTAB"], { timeout: 4000 });
      stat.tcpConns = Number(stdout.trim()) || 0;
    } catch {}
    try {
      const { stdout } = await runExec("sh", ["-c", "ss -uan 2>/dev/null | grep -c UNCONN"], { timeout: 4000 });
      stat.udpConns = Number(stdout.trim()) || 0;
    } catch {}
  }
  return stat;
}

// Total + today + a `days`-long daily series of traffic (with up/down split),
// summed across users from the uusage-* buckets the stats bridge writes.
async function trafficStats(kv, { days = 14, now = new Date() } = {}) {
  const sumPrefix = async (prefix) => {
    let t = 0;
    for (const { name } of await kv.list({ prefix })) t += Number((await kv.get(name)) || 0);
    return t;
  };
  const perDay = async (prefix) => {
    const m = new Map();
    for (const { name } of await kv.list({ prefix })) {
      const day = name.slice(name.lastIndexOf(":") + 1);
      m.set(day, (m.get(day) || 0) + Number((await kv.get(name)) || 0));
    }
    return m;
  };
  const total = await sumPrefix("uusage:");
  const totalUp = await sumPrefix("uusage-up:");
  const totalDn = await sumPrefix("uusage-dn:");
  const dTotal = await perDay("uusage-d:");
  const dUp = await perDay("uusage-d-up:");
  const dDn = await perDay("uusage-d-dn:");

  const series = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 86400000).toISOString().slice(0, 10);
    series.push({ date: d, bytes: dTotal.get(d) || 0, up: dUp.get(d) || 0, down: dDn.get(d) || 0 });
  }
  const today = now.toISOString().slice(0, 10);
  return {
    total, up: totalUp, down: totalDn,
    today: dTotal.get(today) || 0,
    todayUp: dUp.get(today) || 0,
    todayDown: dDn.get(today) || 0,
    series,
  };
}

// The server's own geo + ISP, cached in KV (one lookup, best-effort). Lets the
// dashboard show "City, Country" and the ISP, like the main panel, but real.
async function serverGeo(kv, { fetchImpl = fetch } = {}) {
  try {
    const cached = JSON.parse((await kv.get("geo:self")) || "null");
    if (cached && cached.country) return cached;
  } catch {}
  try {
    const r = await fetchImpl("http://ip-api.com/json/?fields=status,country,countryCode,city,isp,query", {
      signal: AbortSignal.timeout(4000),
    });
    const d = await r.json();
    if (d && d.status === "success") {
      const geo = { country: d.country, countryCode: d.countryCode, city: d.city, isp: d.isp, ip: d.query };
      await kv.put("geo:self", JSON.stringify(geo));
      return geo;
    }
  } catch {}
  return null;
}

// Best-effort Telegram alert. Reads the bot token + chat id from settings (or a
// settings doc passed in to avoid a re-read). Silent on any failure.
async function notifyTelegram(kv, text, settings = null) {
  try {
    const s = settings || (await getSettings(kv));
    if (s.enableTelegram !== true || !s.tgBotToken || !s.tgChatId) return;
    await fetch(`https://api.telegram.org/bot${s.tgBotToken}/sendMessage`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ chat_id: s.tgChatId, text, parse_mode: "HTML", disable_web_page_preview: true }),
      signal: AbortSignal.timeout(5000),
    });
  } catch {}
}

// A small ring buffer of admin activity (logins, changes), newest first.
async function logActivity(kv, action, req) {
  try {
    const ip = (req && (req.headers["x-forwarded-for"] || req.socket?.remoteAddress)) || "";
    const list = JSON.parse((await kv.get("activity:log")) || "[]");
    list.unshift({ t: Date.now(), action, ip: String(ip).split(",")[0].trim() });
    await kv.put("activity:log", JSON.stringify(list.slice(0, 100)));
  } catch {}
}

// The teeth: run from the poll loop, this makes xray actually stop serving a
// user who is over quota, expired, or (opt-in) over their device limit, and runs
// the per-user schedules (data-reset cycles + expire-on-first-connect). It only
// reloads xray when the set of active users truly changes, so a steady state is
// a cheap no-op. Runs under the same lock as admin mutations.
export async function enforcePolicies(kv, opts = {}) {
  return kvLock(kv).run(async () => {
    const settings = await getSettings(kv);
    const users = settings.users || [];
    if (!users.length) return { changed: false };

    const now = Date.now();
    const usage = await usageData(kv);
    const online = await onlineCounts(kv);
    const enforceIp = settings.enforceIpLimit === true;
    const COOLDOWN = Number(process.env.NOVA_IPLOCK_MS || 120_000);
    let dirty = false;

    // Schedules mutate the user record (reset cycle rollover, first-use expiry).
    for (const u of users) {
      const strat = u.resetStrategy;
      // "no"/"none"/empty = off; only day/week/month schedule a reset. The panel
      // writes "none" for off, so it must count as off here (else it fell through
      // to the 30-day default and quietly reset every "off" user monthly).
      if (strat && strat !== "no" && strat !== "none") {
        const cycle = strat === "day" ? 86400000 : strat === "week" ? 604800000 : 2592000000;
        const last = Number(u.lastReset || 0);
        if (!last) { u.lastReset = now; dirty = true; }
        else if (now - last >= cycle) {
          await kv.put(`uusage:${u.id}`, "0");
          await kv.delete(`uusage-up:${u.id}`);
          await kv.delete(`uusage-dn:${u.id}`);
          u.lastReset = now; dirty = true;
          usage[u.id] = 0;
        }
      }
      const days = Number(u.expireDays || 0);
      if (days > 0 && !u.expiry && (usage[u.id] || 0) > 0) {
        u.expiry = new Date(now + days * 86400000).toISOString().slice(0, 10);
        dirty = true;
      }
    }

    // Effective active state: enabled AND not expired AND under quota AND (opt-in)
    // not over the device limit.
    const effective = [];
    for (const u of users) {
      let active = u.enabled !== false;
      let reason = "";
      if (active && u.expiry) {
        const exp = parseExpiry(u.expiry);
        if (Number.isFinite(exp) && now > exp) { active = false; reason = "expired"; }
      }
      if (active && Number(u.quotaBytes || 0) > 0 && (usage[u.id] || 0) >= Number(u.quotaBytes)) { active = false; reason = "data cap reached"; }
      if (enforceIp) {
        const lim = Number(u.ipLimit || 0);
        const key = `iplock:${u.id}`;
        const lock = Number((await kv.get(key)) || 0);
        const over = lim > 0 && (online[u.id] || 0) > lim;
        if (over) { if (!lock) { await kv.put(key, String(now)); await logActivity(kv, `IP limit reached: ${u.email || u.id}`); } active = false; reason = "device limit"; }
        else if (lock) { if (now - lock >= COOLDOWN) await kv.delete(key); else { active = false; reason = "device limit"; } }
      }
      // Telegram: alert once when a user is newly blocked by policy (not admin
      // disabled), and clear the flag when they are active again.
      const flag = `tgflag:${u.id}`;
      if (!active && u.enabled !== false) {
        if (!(await kv.get(flag))) {
          await kv.put(flag, "1");
          notifyTelegram(kv, `⛔ <b>${u.name || u.email || u.id}</b> was blocked: ${reason}.`, settings);
        }
      } else if (await kv.get(flag)) {
        await kv.delete(flag);
      }
      effective.push(active ? u : { ...u, enabled: false });
    }

    if (dirty) await putSettings(kv, settings);

    // Reload only when the active set changed since last time.
    const sig = effective.map((u) => `${u.id}:${u.enabled !== false ? 1 : 0}`).join(",");
    if (sig !== (await kv.get("enforce:sig"))) {
      await kv.put("enforce:sig", sig);
      await applyUsers(effective, {
        forceReload: true,
        xrayOpts: await xrayOptsFor(kv, settings),
        ...(opts.managerOpts || {}),
      });
      return { changed: true };
    }
    return { changed: false };
  });
}

// --- HTTP server -----------------------------------------------------------

// On boot, if the AmneziaWG server is enabled in settings but the interface is
// down (fresh reboot, agent restart), bring it back up. Best-effort and quiet.
export async function reconcileAwg(kv) {
  try {
    if (!(await awg.awgAvailable())) return;
    const s = await getSettings(kv);
    const wgOn = !!(s.protocols && s.protocols.wireguard === true);
    const a = awg.awgState(s);
    // Per-user WireGuard: keep the peer set in sync with users, then ensure the
    // interface is up. Falls back to the legacy enabled flag for older configs.
    if (wgOn) {
      const srv = awg.ensureServer(s);
      srv.enabled = true;
      awg.syncUserPeers(srv, s.users || []);
      s.awg = srv;
      await putSettings(kv, s);
      const live = await awg.liveStatus();
      if (!live.up) await awg.applyServer(srv);
      else await awg.syncPeers(srv);
      return;
    }
    if (a.enabled !== true) return;
    const live = await awg.liveStatus();
    if (!live.up) await awg.applyServer(a);
  } catch (e) {
    console.error("awg reconcile:", e && e.message ? e.message : e);
  }
}

/**
 * @param {object} kv        SQLite KV store
 * @param {object} opts
 *   managerOpts  forwarded to applyUsers (e.g. { exec:false } for dev)
 * @returns {import("node:http").Server}
 */
export function createServer(kv, opts = {}) {
  const rate = new RateLimiter(10, 60_000); // 10 login attempts / IP / minute

  const server = httpCreateServer(async (req, res) => {
    try {
      await route(req, res, kv, opts, rate);
    } catch (err) {
      if (err instanceof HttpError) {
        sendJson(res, err.status, { error: err.message });
      } else {
        sendJson(res, 500, { error: "internal error" });
      }
    }
  });
  return server;
}

async function route(req, res, kv, opts, rate) {
  const url = new URL(req.url, "http://localhost");
  const path = url.pathname;
  const method = req.method || "GET";
  const ua = req.headers["user-agent"] || "";

  // Public endpoints -------------------------------------------------------

  // The browser dashboard (a single-page app). Served at the root and a couple
  // of friendly aliases; all its data comes from the API routes below over the
  // same origin. xray's TLS front on :443 forwards non-tunnel requests here, so
  // visiting https://<vps>/ in a browser lands on this.
  if (
    method === "GET" &&
    (path === "/" || path === "/index.html" || path === "/panel")
  ) {
    res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
    return res.end(PANEL_HTML);
  }

  if (path === "/install/status" && method === "GET") {
    const configured = !!(await kv.get("admin_pass"));
    return sendJson(res, 200, {
      configured,
      admin: configured,
      store: "sqlite",
      build: BUILD,
    });
  }

  if (path === "/install/set" && method === "POST") {
    if (await kv.get("admin_pass")) {
      throw new HttpError(409, "already configured");
    }
    const body = await readBody(req);
    const password = fieldFrom(body, "password");
    if (!password || String(password).length < 6) {
      throw new HttpError(400, "password too short");
    }
    await setPassword(kv, password);
    await getSettings(kv); // materialize default settings on first install
    // Count this node in novaproxy.online's install total, like the other deploy
    // channels. Only reachable once (the admin_pass guard above 409s afterward),
    // so it fires exactly once per node. Host is taken from how the admin reached
    // the panel (its domain or IP); fire-and-forget so setup is never delayed.
    reportInstall(String(req.headers["host"] || "").split(":")[0]);
    const sess = await makeSession(kv, { userAgent: ua });
    res.setHeader("Set-Cookie", sess.cookie);
    return sendJson(res, 200, { ok: true });
  }

  if (path === "/login" && method === "POST") {
    const ip = clientIp(req);
    if (!rate.allow(ip)) throw new HttpError(429, "too many attempts");
    const body = await readBody(req);
    const password = fieldFrom(body, "password");
    if (!(await checkPassword(kv, password))) {
      return sendJson(res, 401, { error: "invalid password" });
    }
    rate.reset(ip);
    const sess = await makeSession(kv, { userAgent: ua });
    res.setHeader("Set-Cookie", sess.cookie);
    await logActivity(kv, "Admin sign in", req);
    return sendJson(res, 200, { ok: true });
  }

  if (path === "/logout" && method === "GET") {
    res.setHeader("Set-Cookie", clearSessionCookie());
    return sendJson(res, 200, { ok: true });
  }

  // Per-ISP client optimization profile. Public so a Nova client can fetch it
  // (by carrier / ASN) and auto-tune fingerprint / fragment / mtu for the best
  // throughput on that network, updatable centrally without an app release.
  if (path === "/isp-profile" && method === "GET") {
    const settings = await getSettings(kv);
    res.setHeader("Cache-Control", "public, max-age=300");
    return sendJson(res, 200, ispProfileOf(settings));
  }

  if (path === "/sub" && method === "GET") {
    const settings = await getSettings(kv);
    // Per-user auto-subscription: /sub?u=<subId> returns only that one user's
    // configs, keyed by the unguessable per-user subId (no admin token needed).
    // A user's whole personal link set updates in place, so every client can
    // auto-import and auto-update it. The old global /sub?token= still works.
    const subId = url.searchParams.get("u") || "";
    const token = url.searchParams.get("token") || "";
    let subUsers;
    if (subId) {
      const one = (settings.users || []).find((x) => constEq(subIdFor(settings, x), subId));
      if (!one) throw new HttpError(403, "unknown subscription");
      subUsers = [one];
    } else {
      if (!settings.subToken || !constEq(token, settings.subToken)) {
        throw new HttpError(403, "bad token");
      }
      subUsers = settings.users;
    }
    const host = settings.host || req.headers["host"] || "";
    const subOpts = {
      host: stripPort(host),
      wsPath: settings.wsPath,
      token,
      kv,
      // No-domain nodes serve a self-signed cert; emit allowInsecure=1 links.
      insecure: settings.insecure === true,
      protocols: settings.protocols,
      inbounds: settings.inbounds || [],
      // Standalone inbounds bypass Cloudflare (Reality does its own TLS), so
      // they connect to the node's direct address, not the CF-fronted host.
      directHost: settings.directHost || stripPort(host),
      // Hysteria2 Brutal bandwidth hints (0 = off = BBR). Set to match typical
      // client line speed to push through loss-based throttling.
      hy2Up: Number(settings.hy2UpMbps) || 0,
      hy2Down: Number(settings.hy2DownMbps) || 0,
      hy2Port: hy2PortOf(settings),
    };
    // Human opened their personal link in a browser: show the subscription page
    // (usage, expiry, every config + QR) instead of raw base64. Clients
    // (v2rayNG / clash / sing-box ...) do not send Accept: text/html, so they
    // still get the config. `?raw` forces the config in a browser too.
    const wantsHtml = subId && !url.searchParams.has("raw") && !url.searchParams.get("target")
      && /text\/html/i.test(String(req.headers["accept"] || ""));
    if (wantsHtml) {
      const one = subUsers[0];
      const uid = one.id || one.uuid;
      const [totU, upU, dnU] = await Promise.all([
        kv.get(`uusage:${uid}`), kv.get(`uusage-up:${uid}`), kv.get(`uusage-dn:${uid}`),
      ]);
      let links = [];
      try {
        const b64 = await buildSub([one], subOpts);
        links = Buffer.from(b64, "base64").toString("utf8").split(/\r?\n/).map((s) => s.trim()).filter(Boolean)
          .map((uri) => ({ uri, proto: (uri.split("://")[0] || "").toLowerCase(), label: decodeURIComponent(uri.split("#")[1] || "") || (uri.split("://")[0] || "") }));
      } catch {}
      const exp = one.expiry ? parseExpiry(one.expiry) : 0;
      const status = one.enabled === false ? "disabled"
        : (exp && Date.now() > exp ? "expired"
          : (Number(one.quotaBytes) > 0 && Number(totU || 0) >= Number(one.quotaBytes) ? "quota" : "active"));
      const data = {
        name: one.name || one.email || uid,
        status,
        used: Number(totU || 0), up: Number(upU || 0), down: Number(dnU || 0),
        quotaBytes: Number(one.quotaBytes || 0),
        quotaUpBytes: Number(one.quotaUpBytes || 0), quotaDownBytes: Number(one.quotaDownBytes || 0),
        expiry: one.expiry || "", expireDays: Number(one.expireDays || 0), ipLimit: Number(one.ipLimit || 0),
        subUrl: `https://${stripPort(host)}/sub?u=${subId}`,
        links,
      };
      const inject = `<script>window.__NOVA_SUB__=${JSON.stringify(data).replace(/</g, "\\u003c")}</script>`;
      res.statusCode = 200;
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      res.setHeader("Cache-Control", "no-store");
      return res.end(SUBPAGE_HTML.replace("</head>", inject + "</head>"));
    }
    // Format from ?target= or the client's User-Agent.
    const fmt = subFormat(url.searchParams.get("target") || "", ua);
    if (fmt === "clash" || fmt === "singbox") {
      const proxies = await enumerateProxies(subUsers, subOpts);
      res.statusCode = 200;
      res.setHeader("Content-Type", fmt === "clash" ? "text/yaml; charset=utf-8" : "application/json; charset=utf-8");
      res.setHeader("Profile-Update-Interval", "12");
      return res.end(fmt === "clash" ? toClash(proxies) : toSingbox(proxies));
    }
    const body = await buildSub(subUsers, subOpts);
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.setHeader("Profile-Update-Interval", "12");
    return res.end(body);
  }

  // Google-relay exit (MHR protocol). A public, key-authed endpoint so the node
  // itself can be a Cloudflare-independent relay exit: a Google Apps Script (or
  // the Nova client) POSTs {k, u, m, h, b, r}, the node fetches `u` and returns
  // {s, h, b}. Enabled + keyed via settings.enableRelay / settings.relayKey.
  if (path === "/relay") {
    if (method === "GET") {
      res.statusCode = 200;
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      return res.end("Nova relay exit. POST the relay envelope here.");
    }
    if (method !== "POST") throw new HttpError(405, "method not allowed");
    const s = await getSettings(kv);
    if (s.enableRelay !== true || !s.relayKey) return sendJson(res, 503, { e: "relay not configured" });
    let doc;
    try {
      doc = parseJson(await readBody(req));
    } catch {
      return sendJson(res, 400, { e: "invalid JSON" });
    }
    if (!doc.k) return sendJson(res, 401, { e: "missing auth key" });
    if (!constEq(String(doc.k), String(s.relayKey))) return sendJson(res, 401, { e: "unauthorized" });
    if (!doc.u) return sendJson(res, 400, { e: "missing url" });
    let target;
    try {
      target = new URL(doc.u);
    } catch {
      return sendJson(res, 400, { e: "bad url" });
    }
    if (!isPublicRelayTarget(target)) return sendJson(res, 400, { e: "target not allowed" });
    try {
      const headers = {};
      if (doc.h && typeof doc.h === "object") {
        for (const [k, v] of Object.entries(doc.h)) {
          if (!/^(host|connection|content-length|transfer-encoding|proxy-)/i.test(k)) headers[k] = String(v);
        }
      }
      const init = { method: (doc.m || "GET").toUpperCase(), headers, redirect: doc.r === false ? "manual" : "follow", signal: AbortSignal.timeout(20_000) };
      if (doc.b) init.body = Buffer.from(String(doc.b), "base64");
      const r = await fetch(target.toString(), init);
      const buf = Buffer.from(await r.arrayBuffer());
      const rh = {};
      r.headers.forEach((v, k) => { rh[k] = v; });
      return sendJson(res, 200, { s: r.status, h: rh, b: buf.toString("base64") });
    } catch (err) {
      return sendJson(res, 502, { e: String((err && err.message) || err) });
    }
  }

  // Full-tunnel exit: carries raw TCP/UDP flows as JSON ops (see src/tunnel.mjs).
  // Public + self-authed by tunnelKey, exactly like /relay.
  if (path === "/tunnel") {
    if (method === "GET") {
      res.statusCode = 200;
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      return res.end("Nova tunnel exit. POST tunnel ops here.");
    }
    if (method !== "POST") throw new HttpError(405, "method not allowed");
    const s = await getSettings(kv);
    if (s.enableTunnel !== true || !s.tunnelKey) return sendJson(res, 503, { e: "tunnel not configured" });
    let doc;
    try {
      doc = parseJson(await readBody(req));
    } catch {
      return sendJson(res, 400, { e: "invalid JSON" });
    }
    if (!doc.k) return sendJson(res, 401, { e: "missing auth key" });
    if (!constEq(String(doc.k), String(s.tunnelKey))) return sendJson(res, 401, { e: "unauthorized" });
    try {
      const out = await tunnelOp(doc);
      return sendJson(res, 200, out);
    } catch (err) {
      return sendJson(res, 502, { e: String((err && err.message) || err) });
    }
  }

  // Authenticated endpoints ------------------------------------------------
  const needsAuth = path.startsWith("/admin/");
  if (needsAuth) {
    const cookie = readAuthCookie(req.headers["cookie"] || "");
    const ok = await verifySession(kv, cookie, { userAgent: ua });
    if (!ok) throw new HttpError(401, "unauthorized");
  }

  if (path === "/admin/network-settings.json") {
    if (method === "GET") {
      return sendJson(res, 200, await getSettings(kv));
    }
    if (method === "POST") {
      const body = await readBody(req);
      const doc = parseJson(body);
      const { forceReload, prev, merged } = await kvLock(kv).run(async () => {
        const settings = await getSettings(kv);
        const prev = settings.users.slice();
        const merged = { ...settings, ...doc };
        if (!Array.isArray(merged.users)) merged.users = settings.users;

        // Reject anything that would produce a config.json xray cannot parse (H4).
        validateWsPath(merged.wsPath);
        for (const u of merged.users) validateUser(u);

        // Any config-affecting change forces an xray reload (it cannot be
        // hot-patched via HandlerService, H3). User-only changes stay hot.
        const forceReload =
          CONFIG_KEYS.some((k) => JSON.stringify(merged[k]) !== JSON.stringify(settings[k])) ||
          isMultiProtocol(merged.protocols);

        // Validate the resulting xray config BEFORE saving it, so a bad routing
        // rule (or any bad setting) is rejected up front and never persisted.
        if (forceReload) {
          try {
            await applyUsers(merged.users, {
              validateOnly: true,
              prev,
              xrayOpts: await xrayOptsFor(kv, merged),
              ...(opts.managerOpts || {}),
            });
          } catch (e) {
            throw new HttpError(400, (e && e.message) || "xray rejected the settings");
          }
        }

        await putSettings(kv, merged);
        return { forceReload, prev, merged };
      });
      await logActivity(kv, "Network settings saved", req);
      scheduleWireguardSync(kv);
      if (forceReload) {
        // A full xray restart drops the :443 panel proxy; respond first.
        sendJson(res, 200, { ok: true });
        scheduleXrayApply(kv, opts);
        return;
      }
      // Hot user changes apply immediately via HandlerService (no restart).
      const result = await kvLock(kv).run(async () =>
        applyUsers(merged.users, {
          prev,
          forceReload: false,
          xrayOpts: await xrayOptsFor(kv, merged),
          ...(opts.managerOpts || {}),
        }),
      );
      return sendJson(res, 200, { ok: true, apply: result });
    }
    throw new HttpError(405, "method not allowed");
  }

  if (path === "/admin/users.json" && method === "POST") {
    const body = await readBody(req);
    const action = parseJson(body);
    const result = await applyUserAction(kv, action, opts);
    await logActivity(kv, `User ${action && action.action === "delete" ? "removed" : action && action.action === "update" ? "updated" : "added"}`, req);
    scheduleWireguardSync(kv);
    return sendJson(res, 200, {
      ok: true,
      user: result.user,
      apply: result.apply,
    });
  }

  if (path === "/admin/usage-data" && method === "GET") {
    return sendJson(res, 200, { usage: await usageData(kv) });
  }

  // One user's share links across every enabled protocol (for the per-user page).
  // Reuses the exact subscription builder, filtered to a single user.
  if (path === "/admin/user-links" && method === "GET") {
    const id = url.searchParams.get("id") || "";
    const settings = await getSettings(kv);
    const u = (settings.users || []).find((x) => x.id === id);
    if (!u) throw new HttpError(404, "user not found");
    const host = settings.host || req.headers["host"] || "";
    const subOpts = {
      host: stripPort(host), wsPath: settings.wsPath, token: settings.subToken, kv,
      insecure: settings.insecure === true, protocols: settings.protocols,
      inbounds: settings.inbounds || [], directHost: settings.directHost || stripPort(host),
      hy2Up: Number(settings.hy2UpMbps) || 0, hy2Down: Number(settings.hy2DownMbps) || 0,
      hy2Port: hy2PortOf(settings),
    };
    let links = [];
    try {
      const b64 = await buildSub([u], subOpts);
      const uris = Buffer.from(b64, "base64").toString("utf8").split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
      links = uris.map((uri) => ({
        uri,
        proto: (uri.split("://")[0] || "").toLowerCase(),
        label: decodeURIComponent(uri.split("#")[1] || "") || (uri.split("://")[0] || ""),
      }));
    } catch (e) {
      throw new HttpError(500, "could not build links");
    }
    // WireGuard is a per-user protocol: append this user's AmneziaWG config (a
    // full .conf, not a URI). uri is set to the conf so the QR still scans.
    const a = awg.awgState(settings);
    if (settings.protocols && settings.protocols.wireguard && a.enabled && a.server && a.junk) {
      const peer = awg.peerForUser(a, u.id);
      if (peer) {
        const wgHost = await awg.endpointHost(settings);
        const conf = awg.renderClientConf(a, peer, wgHost);
        links.push({ proto: "wireguard", label: "WireGuard", uri: conf, conf });
      }
    }
    // The user's personal auto-subscription: one link every client imports once
    // and then auto-updates from. subId is the unguessable secret; no admin login.
    const subId = subIdFor(settings, u);
    const subUrl = `https://${stripPort(host)}/sub?u=${subId}`;
    return sendJson(res, 200, { id: u.id, name: u.email || u.id, links, subId, subUrl });
  }

  // Live dashboard: real host stats, service health, counts and traffic. The
  // heavy version of what a Cloudflare Worker can only fake.
  if (path === "/admin/dashboard" && method === "GET") {
    const s = await getSettings(kv);
    const canExec = !(opts.managerOpts && opts.managerOpts.exec === false);
    const [sys, traffic, geo] = await Promise.all([
      systemStats(canExec ? pExecFile : null),
      trafficStats(kv),
      serverGeo(kv).catch(() => null),
    ]);
    sys.geo = geo;
    const users = s.users || [];
    return sendJson(res, 200, {
      host: s.host || "",
      tls: s.insecure === true ? "self-signed" : "trusted",
      system: sys,
      traffic,
      counts: {
        users: users.length,
        usersEnabled: users.filter((u) => u.enabled !== false).length,
        inbounds: (s.inbounds || []).filter((i) => i.enabled !== false).length,
      },
      protocols: s.protocols || {},
      warp: { enabled: s.enableWarp === true, calls: s.warpCalls === true },
    });
  }

  // Live online-device counts per user (distinct source IPs in the last window).
  if (path === "/admin/online" && method === "GET") {
    return sendJson(res, 200, { online: await onlineCounts(kv) });
  }

  // Relay exit config: make this node a Cloudflare-independent relay exit.
  if (path === "/admin/relay" && method === "GET") {
    const s = await getSettings(kv);
    const host = stripPort(s.host || "");
    return sendJson(res, 200, {
      enabled: s.enableRelay === true,
      hasKey: !!s.relayKey,
      key: s.relayKey || "",
      url: host ? `https://${host}/relay` : "",
    });
  }
  if (path === "/admin/relay" && method === "POST") {
    const doc = parseJson(await readBody(req));
    const result = await kvLock(kv).run(async () => {
      const s = await getSettings(kv);
      const merged = { ...s };
      if (doc.action === "disable") merged.enableRelay = false;
      else {
        if (doc.action === "generate" || !merged.relayKey) merged.relayKey = randomBytes(18).toString("base64url");
        merged.enableRelay = true;
      }
      await putSettings(kv, merged);
      return merged;
    });
    await logActivity(kv, `Relay exit ${result.enableRelay ? "enabled" : "disabled"}`, req);
    const host = stripPort(result.host || "");
    return sendJson(res, 200, { ok: true, enabled: result.enableRelay === true, key: result.relayKey || "", url: host ? `https://${host}/relay` : "" });
  }
  if (path === "/admin/tunnel" && method === "GET") {
    const s = await getSettings(kv);
    const host = stripPort(s.host || "");
    return sendJson(res, 200, {
      enabled: s.enableTunnel === true,
      hasKey: !!s.tunnelKey,
      key: s.tunnelKey || "",
      url: host ? `https://${host}/tunnel` : "",
      sessions: tunnelSessionCount(),
    });
  }
  if (path === "/admin/tunnel" && method === "POST") {
    const doc = parseJson(await readBody(req));
    const result = await kvLock(kv).run(async () => {
      const s = await getSettings(kv);
      const merged = { ...s };
      if (doc.action === "disable") merged.enableTunnel = false;
      else {
        if (doc.action === "generate" || !merged.tunnelKey) merged.tunnelKey = randomBytes(18).toString("base64url");
        merged.enableTunnel = true;
      }
      await putSettings(kv, merged);
      return merged;
    });
    await logActivity(kv, `Tunnel exit ${result.enableTunnel ? "enabled" : "disabled"}`, req);
    const host = stripPort(result.host || "");
    return sendJson(res, 200, { ok: true, enabled: result.enableTunnel === true, key: result.tunnelKey || "", url: host ? `https://${host}/tunnel` : "" });
  }

  // AmneziaWG server: obfuscated-WireGuard exit with junk packets. Clients get a
  // .conf whose junk params match the server so DPI can't fingerprint the tunnel.
  if (path === "/admin/awg" && method === "GET") {
    const s = await getSettings(kv);
    const a = awg.awgState(s);
    const available = await awg.awgAvailable();
    const live = a.enabled ? await awg.liveStatus() : { up: false, peers: {} };
    const host = await awg.endpointHost(s);
    return sendJson(res, 200, {
      available,
      enabled: a.enabled === true,
      up: live.up,
      port: a.port || null,
      level: a.level || "medium",
      endpoint: host && a.port ? `${host}:${a.port}` : "",
      serverPublicKey: a.server ? a.server.publicKey : "",
      peers: (a.peers || []).map((p) => ({
        id: p.id, name: p.name, address: p.address, publicKey: p.publicKey,
        latestHandshake: (live.peers[p.publicKey] || {}).latestHandshake || 0,
        conf: (a.enabled && a.server && a.junk) ? awg.renderClientConf(a, p, host) : "",
      })),
    });
  }
  if (path === "/admin/awg" && method === "POST") {
    if (!(await awg.awgAvailable())) throw new HttpError(400, "AmneziaWG is not installed on this node");
    const doc = parseJson(await readBody(req));
    const action = String(doc.action || "");
    const out = await kvLock(kv).run(async () => {
      const s = await getSettings(kv);
      if (action === "disable") {
        const a = awg.awgState(s); a.enabled = false; s.awg = a;
        await putSettings(kv, s);
        await awg.disableServer();
        return { ok: true, enabled: false };
      }
      if (action === "enable") {
        const a = awg.ensureServer(s, { level: doc.level, port: doc.port });
        a.enabled = true; s.awg = a;
        await putSettings(kv, s);
        await awg.applyServer(a);
        return { ok: true, enabled: true };
      }
      if (action === "add-peer") {
        const a = awg.ensureServer(s);
        const peer = awg.addPeer(a, doc.name);
        s.awg = a; await putSettings(kv, s);
        if (a.enabled) await awg.syncPeers(a);
        const host = await awg.endpointHost(s);
        return { ok: true, peer, conf: awg.renderClientConf(a, peer, host), config: awg.clientObject(a, peer, host) };
      }
      if (action === "remove-peer") {
        const a = awg.awgState(s);
        a.peers = (a.peers || []).filter((p) => p.id !== doc.id);
        s.awg = a; await putSettings(kv, s);
        if (a.enabled) await awg.syncPeers(a);
        return { ok: true };
      }
      if (action === "peer-config") {
        const a = awg.awgState(s);
        const peer = (a.peers || []).find((p) => p.id === doc.id);
        if (!peer) throw new HttpError(404, "peer not found");
        const host = await awg.endpointHost(s);
        return { ok: true, conf: awg.renderClientConf(a, peer, host), config: awg.clientObject(a, peer, host) };
      }
      throw new HttpError(400, "unknown action");
    });
    await logActivity(kv, `AmneziaWG ${action}`, req);
    return sendJson(res, 200, out);
  }

  // Send a Telegram test message with the currently saved bot token + chat id.
  if (path === "/admin/telegram/test" && method === "POST") {
    const s = await getSettings(kv);
    if (!s.tgBotToken || !s.tgChatId) throw new HttpError(400, "set the bot token and chat id first");
    try {
      const r = await fetch(`https://api.telegram.org/bot${s.tgBotToken}/sendMessage`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ chat_id: s.tgChatId, text: "✅ Nova node connected. Alerts will arrive here." }),
        signal: AbortSignal.timeout(6000),
      });
      const d = await r.json();
      if (!d.ok) throw new HttpError(502, d.description || "Telegram rejected the message");
    } catch (e) {
      if (e instanceof HttpError) throw e;
      throw new HttpError(502, "could not reach Telegram");
    }
    return sendJson(res, 200, { ok: true });
  }

  // Recent admin activity (logins + changes), newest first.
  if (path === "/admin/activity" && method === "GET") {
    let list = [];
    try {
      list = JSON.parse((await kv.get("activity:log")) || "[]");
    } catch {}
    return sendJson(res, 200, { activity: list });
  }

  // Full backup: the settings doc + the WARP account, as a downloadable JSON.
  if (path === "/admin/backup" && method === "GET") {
    const s = await getSettings(kv);
    let warp = null;
    try {
      warp = JSON.parse((await kv.get("warp-account.json")) || "null");
    } catch {}
    const dump = { nova: "node-backup", build: BUILD, exportedAt: Date.now(), settings: s, warp };
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="nova-node-backup.json"');
    return res.end(JSON.stringify(dump, null, 2));
  }

  // Restore from a backup dump: validate, persist, re-apply to xray.
  if (path === "/admin/restore" && method === "POST") {
    const dump = parseJson(await readBody(req));
    const incoming = dump && dump.settings;
    if (!incoming || typeof incoming !== "object") throw new HttpError(400, "backup has no settings");
    if (!Array.isArray(incoming.users)) incoming.users = [];
    validateWsPath(incoming.wsPath);
    for (const u of incoming.users) validateUser(u);
    for (const raw of incoming.inbounds || []) {
      const v = validateInbound(normalizeInbound(raw));
      if (!v.ok) throw new HttpError(400, `inbound invalid: ${v.error}`);
    }
    await kvLock(kv).run(async () => {
      await putSettings(kv, incoming);
      if (dump.warp && dump.warp.privateKey) await kv.put("warp-account.json", JSON.stringify(dump.warp));
      await applyUsers(incoming.users, {
        forceReload: true,
        xrayOpts: await xrayOptsFor(kv, incoming),
        ...(opts.managerOpts || {}),
      });
    });
    await logActivity(kv, "Settings restored from backup", req);
    return sendJson(res, 200, { ok: true, users: incoming.users.length });
  }

  // Is a newer agent published? Fetches the version marker next to the tarball on
  // IRNova/Tools and compares it (semver) to this build, so the panel can show
  // "up to date" vs "update available" before the admin clicks Update.
  if (path === "/admin/update-check" && method === "GET") {
    const current = (BUILD.split("/")[1] || "0").trim();
    let latest = null;
    try {
      if (typeof fetch === "function") {
        const vurl = process.env.NOVA_VERSION_URL ||
          "https://raw.githubusercontent.com/IRNova/Nova-Server/main/nova-node-agent.version";
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 5000);
        try {
          const r = await fetch(vurl, { signal: ctrl.signal, cache: "no-store" });
          if (r.ok) latest = ((await r.text()).trim().split(/\s+/)[0] || "").trim() || null;
        } finally { clearTimeout(t); }
      }
    } catch {}
    const cmp = (a, b) => {
      const pa = String(a).split("."), pb = String(b).split(".");
      for (let i = 0; i < 3; i++) { const d = (Number(pa[i]) || 0) - (Number(pb[i]) || 0); if (d) return d > 0 ? 1 : -1; }
      return 0;
    };
    return sendJson(res, 200, { current, latest, updateAvailable: !!(latest && cmp(latest, current) > 0) });
  }

  // Pull the latest agent from IRNova/Tools and restart (detached from this req).
  if (path === "/admin/self-update" && method === "POST") {
    if (opts.managerOpts && opts.managerOpts.exec === false) return sendJson(res, 200, { ok: true, skipped: true });
    const url = process.env.NOVA_TARBALL_URL ||
      "https://raw.githubusercontent.com/IRNova/Nova-Server/main/nova-node-agent.tar.gz";
    const agentDir = join(dirname(fileURLToPath(import.meta.url)), "..");
    const script = `sleep 1; curl -fsSL '${url}' -o /tmp/nova-agent.tgz && tar xzf /tmp/nova-agent.tgz -C '${agentDir}' && systemctl restart nova-agent`;
    try {
      const { spawn } = await import("node:child_process");
      spawn("bash", ["-c", script], { detached: true, stdio: "ignore" }).unref();
    } catch {
      throw new HttpError(500, "could not start self-update");
    }
    await logActivity(kv, "Agent self-update started", req);
    return sendJson(res, 202, { ok: true, state: "updating" });
  }

  // The panel config the Nova client reads. The client imports the node from
  // optimizedSubGeneration.TOKEN (-> /sub?token=), and the admin editor toggles
  // tlsFragment / skipCertVerify / enable0RTT / randomPath. Mirrors the Worker.
  if (path === "/admin/config.json" && method === "GET") {
    const s = await getSettings(kv);
    const first = (s.users || [])[0] || {};
    return sendJson(res, 200, {
      HOST: s.host || "",
      UUID: first.uuid || first.id || "",
      optimizedSubGeneration: { TOKEN: s.subToken || "" },
      tlsFragment: s.tlsFragment === true,
      skipCertVerify: s.insecure === true,
      enable0RTT: s.enable0RTT === true,
      randomPath: s.randomPath === true,
    });
  }
  if (path === "/admin/config.json" && method === "POST") {
    const doc = parseJson(await readBody(req));
    await kvLock(kv).run(async () => {
      const s = await getSettings(kv);
      const merged = { ...s };
      if ("tlsFragment" in doc) merged.tlsFragment = doc.tlsFragment === true;
      if ("skipCertVerify" in doc) merged.insecure = doc.skipCertVerify === true;
      if ("enable0RTT" in doc) merged.enable0RTT = doc.enable0RTT === true;
      if ("randomPath" in doc) merged.randomPath = doc.randomPath === true;
      await putSettings(kv, merged);
    });
    return sendJson(res, 200, { ok: true });
  }

  // Connection info card. A VPS node has no upstream ISP lookup, so this is a
  // valid-but-empty shape (the client tolerates blank fields).
  if (path === "/admin/whoami" && method === "GET") {
    return sendJson(res, 200, {
      asn: 0,
      isp: "",
      country: "",
      city: "",
      carrier: "",
    });
  }

  if (path === "/admin/security/status" && method === "GET") {
    const has = Boolean(await kv.get("admin_pass"));
    return sendJson(res, 200, {
      twofa: false,
      passwordSource: "kv",
      kvSet: has,
    });
  }

  // Custom clean-IP list (raw text), same contract as the Worker's ADD.txt.
  if (path === "/admin/ADD.txt" && method === "GET") {
    const s = await getSettings(kv);
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    return res.end(String(s.customIPs || ""));
  }
  if (path === "/admin/ADD.txt" && method === "POST") {
    const text = String(await readBody(req));
    await kvLock(kv).run(async () => {
      const s = await getSettings(kv);
      await putSettings(kv, { ...s, customIPs: text });
    });
    return sendJson(res, 200, { ok: true });
  }

  // Authenticated snapshot of the subscription (import fallback when the client
  // cannot read the token from config).
  if (path === "/admin/sub-content" && method === "GET") {
    const s = await getSettings(kv);
    const body = await buildSub(s.users, {
      host: stripPort(s.host || ""),
      wsPath: s.wsPath,
      kv,
      insecure: s.insecure === true,
      protocols: s.protocols,
      inbounds: s.inbounds || [],
      directHost: s.directHost || stripPort(s.host || ""),
      hy2Up: Number(s.hy2UpMbps) || 0,
      hy2Down: Number(s.hy2DownMbps) || 0,
      hy2Port: hy2PortOf(s),
    });
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    return res.end(body);
  }

  // Current domain / TLS status (idle | provisioning | active | error).
  if (path === "/admin/domain" && method === "GET") {
    const s = await getSettings(kv);
    let st = {};
    try {
      st = JSON.parse((await kv.get("domain:status")) || "{}");
    } catch {}
    return sendJson(res, 200, {
      host: s.host || "",
      tls: s.insecure === true ? "self-signed" : "trusted",
      state: st.state || "idle",
      error: st.error || "",
    });
  }

  // Add a domain (async: certbot can take a minute; poll GET /admin/domain),
  // or clear back to a self-signed / no-domain node.
  if (path === "/admin/domain" && method === "POST") {
    const doc = parseJson(await readBody(req));
    const certGroup = process.env.NOVA_CERT_GROUP || "nogroup";
    if (doc.clear === true) {
      const host = String(doc.host || "").trim();
      await genSelfSigned({ host: host || "nova.local", certGroup });
      await kvLock(kv).run(async () => {
        const s = await getSettings(kv);
        const merged = { ...s, insecure: true, ...(host ? { host } : {}) };
        await putSettings(kv, merged);
        await applyUsers(merged.users, {
          forceReload: true,
          xrayOpts: await xrayOptsFor(kv, merged),
          ...(opts.managerOpts || {}),
        });
      });
      await kv.put("domain:status", JSON.stringify({ state: "idle" }));
      return sendJson(res, 200, { ok: true, tls: "self-signed" });
    }
    const domain = String(doc.domain || "").trim().toLowerCase();
    if (!isValidDomain(domain)) throw new HttpError(400, "invalid domain");
    const cmethod = doc.method === "origin" ? "origin" : "letsencrypt";
    await kv.put("domain:status", JSON.stringify({ state: "provisioning", domain }));
    // Background; the client polls GET /admin/domain for the outcome.
    runDomainJob(kv, opts, {
      domain,
      method: cmethod,
      cert: doc.cert || "",
      key: doc.key || "",
      email: doc.email || "",
      certGroup,
    });
    return sendJson(res, 202, { ok: true, state: "provisioning", host: domain });
  }

  // Standalone inbounds (Reality, gRPC, XHTTP, Shadowsocks, ...). ------------
  if (path === "/admin/inbounds" && method === "GET") {
    const s = await getSettings(kv);
    return sendJson(res, 200, {
      inbounds: (s.inbounds || []).map((i) => (i.tag ? i : normalizeInbound(i))),
      frontPort: FRONT_PORT,
    });
  }

  // A fresh Reality x25519 keypair + shortId, for the panel to prefill a new
  // Reality inbound (also auto-generated on add if omitted).
  if (path === "/admin/reality-keys" && method === "POST") {
    const k = await genRealityKeys(undefined, process.env.NOVA_XRAY_BIN || "xray");
    return sendJson(res, 200, { ...k, shortId: genShortId() });
  }

  // WARP (Cloudflare WireGuard) account: status, register, or clear. Enabling
  // it for routing is the enableWarp/warpCalls toggle in network-settings.
  if (path === "/admin/warp" && method === "GET") {
    let acc = null;
    try {
      acc = JSON.parse((await kv.get("warp-account.json")) || "null");
    } catch {}
    const s = await getSettings(kv);
    return sendJson(res, 200, {
      registered: !!(acc && acc.privateKey),
      endpoint: acc ? acc.endpoint : "",
      addressV4: acc ? acc.addressV4 : "",
      enableWarp: s.enableWarp === true,
      warpMode: s.warpMode || "warp",
      warpCalls: s.warpCalls === true,
    });
  }
  if (path === "/admin/warp" && method === "POST") {
    const doc = parseJson(await readBody(req));
    if (doc.action === "clear") {
      await kv.delete("warp-account.json");
      await kvLock(kv).run(async () => {
        const s = await getSettings(kv);
        const merged = { ...s, enableWarp: false, warpCalls: false };
        await putSettings(kv, merged);
        await applyUsers(merged.users, {
          forceReload: true,
          xrayOpts: await xrayOptsFor(kv, merged),
          ...(opts.managerOpts || {}),
        });
      });
      return sendJson(res, 200, { ok: true, registered: false });
    }
    // Register a fresh account with Cloudflare, then reload so the WireGuard
    // outbound is available (routing turns on via enableWarp/warpCalls).
    let acc;
    try {
      acc = await registerWarp();
    } catch (e) {
      throw new HttpError(502, `WARP registration failed: ${(e && e.message) || e}`);
    }
    await kv.put("warp-account.json", JSON.stringify(acc));
    await kvLock(kv).run(async () => {
      const s = await getSettings(kv);
      await applyUsers(s.users, {
        forceReload: true,
        xrayOpts: await xrayOptsFor(kv, s),
        ...(opts.managerOpts || {}),
      });
    });
    await logActivity(kv, "WARP account registered", req);
    return sendJson(res, 200, { ok: true, registered: true, endpoint: acc.endpoint, addressV4: acc.addressV4 });
  }

  if (path === "/admin/inbounds" && method === "POST") {
    const doc = parseJson(await readBody(req));
    const verb = doc.action || "add";
    const result = await kvLock(kv).run(async () => {
      const s = await getSettings(kv);
      const list = Array.isArray(s.inbounds) ? s.inbounds.slice() : [];
      let saved = null;

      if (verb === "delete" || verb === "toggle") {
        const id = doc.id || (doc.inbound && doc.inbound.id);
        const i = list.findIndex((x) => x.id === id);
        if (i < 0) throw new HttpError(404, "inbound not found");
        if (verb === "delete") list.splice(i, 1);
        else list[i] = { ...list[i], enabled: list[i].enabled === false };
        saved = verb === "toggle" ? list[i] : null;
      } else if (verb === "add" || verb === "update") {
        const inb = normalizeInbound(doc.inbound || {});
        // Auto-provision key material so the panel can create a Reality or
        // Shadowsocks inbound in a single call.
        if (inb.security === "reality") {
          inb.reality = inb.reality || {};
          if (!inb.reality.privateKey || !inb.reality.publicKey) {
            const k = await genRealityKeys(undefined, process.env.NOVA_XRAY_BIN || "xray");
            inb.reality.privateKey = k.privateKey;
            inb.reality.publicKey = k.publicKey;
          }
          if (!Array.isArray(inb.reality.shortIds) || !inb.reality.shortIds.length) {
            inb.reality.shortIds = [genShortId()];
          }
          if (!inb.reality.dest && inb.reality.serverNames && inb.reality.serverNames[0]) {
            inb.reality.dest = `${inb.reality.serverNames[0]}:443`;
          }
        }
        if (inb.protocol === "shadowsocks" && !inb.ssPassword) {
          inb.ssPassword = genSSPassword();
        }
        const v = validateInbound(inb);
        if (!v.ok) throw new HttpError(400, v.error);
        const conflict = inboundPortConflict(list, inb);
        if (conflict) throw new HttpError(409, conflict);
        if (verb === "update") {
          const i = list.findIndex((x) => x.id === inb.id);
          if (i < 0) throw new HttpError(404, "inbound not found");
          inb.tag = list[i].tag || inb.tag; // keep the xray tag stable
          list[i] = inb;
        } else {
          list.push(inb);
        }
        saved = inb;
      } else {
        throw new HttpError(400, "unknown action");
      }

      const merged = { ...s, inbounds: list };
      await putSettings(kv, merged);
      return { inbounds: list, saved };
    });
    await logActivity(kv, `Inbound ${verb === "delete" ? "removed" : verb === "toggle" ? "toggled" : verb === "update" ? "updated" : "added"}`, req);
    // Respond first, then restart xray, so the :443 panel proxy is not dropped
    // out from under the request that triggered the change.
    sendJson(res, 200, { ok: true, ...result });
    scheduleXrayApply(kv, opts);
    return;
  }

  throw new HttpError(404, "not found");
}

// Provision a cert for `domain`, then flip the node to trusted-domain mode and
// reload xray. Runs detached from the request; status lives in KV.
async function runDomainJob(kv, opts, { domain, method, cert, key, email, certGroup }) {
  try {
    await provisionCert({ domain, method, cert, key, email, certGroup });
    await kvLock(kv).run(async () => {
      const s = await getSettings(kv);
      const merged = { ...s, host: domain, insecure: false };
      await putSettings(kv, merged);
      await applyUsers(merged.users, {
        forceReload: true,
        xrayOpts: await xrayOptsFor(kv, merged),
        ...(opts.managerOpts || {}),
      });
    });
    await kv.put("domain:status", JSON.stringify({ state: "active", domain }));
  } catch (err) {
    await kv.put(
      "domain:status",
      JSON.stringify({ state: "error", domain, error: String((err && err.message) || err) }),
    );
  }
}

// --- small http utilities --------------------------------------------------

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (c) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject(new HttpError(413, "body too large"));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

// Accept either JSON ({password:...}) or urlencoded (password=...) bodies.
function fieldFrom(body, name) {
  const t = (body || "").trim();
  if (t.startsWith("{")) {
    try {
      return JSON.parse(t)[name];
    } catch {
      return undefined;
    }
  }
  return new URLSearchParams(t).get(name) ?? undefined;
}

function parseJson(body) {
  try {
    return JSON.parse(body || "{}");
  } catch {
    throw new HttpError(400, "invalid JSON");
  }
}

// Derive the client IP from the trusted transport by default. X-Forwarded-For is
// client-spoofable, so honour it only when TRUST_PROXY is set (agent runs behind
// a known proxy). Otherwise a fresh spoofed header per request hands each attempt
// its own rate-limit bucket, defeating the brute-force limiter (H2).
function clientIp(req) {
  if (process.env.TRUST_PROXY) {
    const fwd = req.headers["x-forwarded-for"];
    if (fwd) return String(fwd).split(",")[0].trim();
  }
  return req.socket?.remoteAddress || "unknown";
}

function stripPort(host) {
  return String(host).replace(/:\d+$/, "");
}

// SSRF guard for the relay exit: http(s) to a public host only (no localhost,
// private ranges, link-local, CGNAT, or the cloud metadata IP).
function isPublicRelayTarget(u) {
  if (u.protocol !== "http:" && u.protocol !== "https:") return false;
  const h = u.hostname.toLowerCase();
  if (h === "localhost" || h.endsWith(".local") || h === "::1") return false;
  if (h.startsWith("fd") || h.startsWith("fe80")) return false;
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(h);
  if (m) {
    const a = +m[1], b = +m[2];
    if (a === 0 || a === 127 || a === 10) return false;
    if (a === 172 && b >= 16 && b <= 31) return false;
    if (a === 192 && b === 168) return false;
    if (a === 169 && b === 254) return false;
    if (a === 100 && b >= 64 && b <= 127) return false;
  }
  return true;
}

// Which subscription format to serve, from an explicit ?target= or the client's
// User-Agent. Defaults to the v2ray base64 list.
function subFormat(target, ua = "") {
  const t = String(target).toLowerCase();
  if (t === "clash" || t === "meta" || t === "clashmeta") return "clash";
  if (t === "singbox" || t === "sing-box") return "singbox";
  if (t === "base64" || t === "v2ray" || t === "auto") return "base64";
  const u = String(ua).toLowerCase();
  if (/clash|mihomo|stash|flclash|meta/.test(u)) return "clash";
  if (/sing-box|singbox/.test(u)) return "singbox";
  return "base64";
}

// True when the node serves more than VLESS, so a user change spans several
// inbounds and must trigger a full xray reload rather than a vless-ws hot-patch.
function isMultiProtocol(protocols) {
  return Boolean(
    protocols && (protocols.vmess === true || protocols.trojan === true),
  );
}

function constEq(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ba.length !== bb.length) return false;
  return timingSafeEqual(ba, bb);
}

// Fixed-window per-key rate limiter. Expired buckets are swept so a flood of
// distinct (e.g. spoofed) keys cannot grow the map without bound (H2).
class RateLimiter {
  constructor(limit, windowMs) {
    this.limit = limit;
    this.windowMs = windowMs;
    this.hits = new Map();
    this.lastSweep = Date.now();
  }
  sweep(now) {
    if (now - this.lastSweep < this.windowMs) return;
    this.lastSweep = now;
    for (const [k, e] of this.hits) {
      if (now > e.resetAt) this.hits.delete(k);
    }
  }
  allow(key) {
    const now = Date.now();
    this.sweep(now);
    const e = this.hits.get(key);
    if (!e || now > e.resetAt) {
      this.hits.set(key, { count: 1, resetAt: now + this.windowMs });
      return true;
    }
    if (e.count >= this.limit) return false;
    e.count++;
    return true;
  }
  reset(key) {
    this.hits.delete(key);
  }
}

export { HttpError };
