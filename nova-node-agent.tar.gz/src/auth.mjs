// Nova VPS agent: admin session model (mirrors the panel).
//
// Stateless auth: the admin password is stored (as a salted hash) at KV key
// "admin_pass". A logged-in admin carries a signed cookie
//
//   auth=<issuedAt>.<hex HMAC-SHA256(key, "UA|pass|issuedAt")>
//
// where:
//   issuedAt  ms epoch the token was minted
//   key       a per-install random secret at KV key "auto_key" (made on first use)
//   UA        the request User-Agent, so a stolen cookie is pinned to one client
//   pass      the stored password hash, so changing the password invalidates all
//             outstanding cookies
//
// Verification recomputes the HMAC (timing-safe) and enforces an idle timeout.
// Nothing about the session is stored server-side, so it survives restarts.

import {
  createHash,
  createHmac,
  randomBytes,
  scryptSync,
  timingSafeEqual,
} from "node:crypto";

const DEFAULT_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000; // 7 days idle timeout
const COOKIE_NAME = "auth";

// --- password storage -----------------------------------------------------
// Stored form: "scrypt$<saltHex>$<hashHex>". Timing-safe compare on verify.

function hashPassword(password, saltHex) {
  const salt = saltHex || randomBytes(16).toString("hex");
  const hash = scryptSync(String(password), salt, 32).toString("hex");
  return `scrypt$${salt}$${hash}`;
}

/** Hash a password in the stored "scrypt$salt$hash" form (for reseller admins). */
export function hashAdminPassword(password) {
  return hashPassword(password);
}

/** Store (hash) the admin password at KV "admin_pass". */
export async function setPassword(kv, password) {
  const stored = hashPassword(password);
  await kv.put("admin_pass", stored);
  return stored;
}

/** Timing-safe check of a candidate password against KV "admin_pass". */
export async function checkPassword(kv, password) {
  const stored = await kv.get("admin_pass");
  if (!stored) return false;
  const parts = stored.split("$");
  if (parts.length !== 3 || parts[0] !== "scrypt") return false;
  const [, salt] = parts;
  const candidate = hashPassword(password, salt);
  return safeEqualStr(candidate, stored);
}

// --- REST API tokens ------------------------------------------------------
// API tokens live in the settings doc as apiTokens[] = { id, name, hash, role,
// ownerId, ... }, storing only sha256(token) (never the plaintext). The plaintext
// is shown once at creation, exactly like the relay/tunnel keys.

/** sha256 hex of a bearer token, for at-rest storage and lookup. */
export function hashToken(token) {
  return createHash("sha256").update(String(token)).digest("hex");
}

// --- signing key ----------------------------------------------------------

/** Fetch the per-install HMAC key, creating a random one on first use. */
export async function getAuthKey(kv) {
  let key = await kv.get("auto_key");
  if (!key) {
    key = randomBytes(32).toString("hex");
    await kv.put("auto_key", key);
  }
  return key;
}

// --- session cookie -------------------------------------------------------

function sign(key, ua, adminId, passHash, issuedAt) {
  return createHmac("sha256", key)
    .update(`${ua}|${adminId}|${passHash}|${issuedAt}`)
    .digest("hex");
}

// --- multi-admin ----------------------------------------------------------
// The owner is implicit: adminId "owner", whose password hash is the top-level
// "admin_pass" key (so a single-admin install keeps working unchanged). Extra
// admins (resellers) live in the settings doc as admins[] = { id, name, passHash,
// role }, and a session cookie carries which admin it belongs to:
//
//   auth=<adminId>.<issuedAt>.<hmac(key, "UA|adminId|passHash|issuedAt")>
//
// Signing with the admin's own passHash means changing that admin's password (or
// deleting them) invalidates their cookies, and one admin's cookie can never be
// replayed as another.

async function readAdmins(kv) {
  try {
    const doc = JSON.parse((await kv.get("network-settings.json")) || "{}");
    return Array.isArray(doc.admins) ? doc.admins : [];
  } catch {
    return [];
  }
}

// The password hash to sign/verify a given admin's session with.
async function passHashFor(kv, adminId) {
  if (!adminId || adminId === "owner") return (await kv.get("admin_pass")) || "";
  const a = (await readAdmins(kv)).find((x) => x.id === adminId);
  return a ? String(a.passHash || "") : "";
}

// The role of an admin id, or null if it does not exist.
async function roleFor(kv, adminId) {
  if (!adminId || adminId === "owner") return "owner";
  const a = (await readAdmins(kv)).find((x) => x.id === adminId);
  return a ? a.role || "reseller" : null;
}

/**
 * Authenticate a password against the owner and every reseller.
 * @returns {Promise<{id:string, role:string}|null>}
 */
export async function authenticate(kv, password) {
  if (await checkPassword(kv, password)) return { id: "owner", role: "owner" };
  for (const a of await readAdmins(kv)) {
    const stored = String(a.passHash || "");
    const parts = stored.split("$");
    if (parts.length !== 3 || parts[0] !== "scrypt") continue;
    if (safeEqualStr(hashPassword(password, parts[1]), stored)) {
      return { id: a.id, role: a.role || "reseller" };
    }
  }
  return null;
}

/**
 * Mint a session cookie for a freshly authenticated admin.
 * @returns {{name:string, value:string, cookie:string}} cookie is the full
 *   Set-Cookie header value.
 */
export async function makeSession(kv, { userAgent = "", now = Date.now(), adminId = "owner" } = {}) {
  const key = await getAuthKey(kv);
  const passHash = await passHashFor(kv, adminId);
  const issuedAt = now;
  const mac = sign(key, userAgent, adminId, passHash, issuedAt);
  const value = `${adminId}.${issuedAt}.${mac}`;
  const cookie =
    `${COOKIE_NAME}=${value}; HttpOnly; Secure; SameSite=Lax; Path=/; ` +
    `Max-Age=${Math.floor(DEFAULT_MAX_AGE_MS / 1000)}`;
  return { name: COOKIE_NAME, value, cookie };
}

/**
 * Resolve a session cookie to its admin identity, or null if invalid.
 * @returns {Promise<{id:string, role:string}|null>}
 */
export async function resolveSession(
  kv,
  cookieValue,
  { userAgent = "", now = Date.now(), maxAgeMs = DEFAULT_MAX_AGE_MS } = {},
) {
  if (!cookieValue || typeof cookieValue !== "string") return null;
  const parts = cookieValue.split(".");
  let adminId, issuedAt, mac;
  if (parts.length === 3) {
    adminId = parts[0];
    issuedAt = Number(parts[1]);
    mac = parts[2];
  } else if (parts.length === 2) {
    // Legacy two-part cookie (pre multi-admin): always the owner.
    adminId = "owner";
    issuedAt = Number(parts[0]);
    mac = parts[1];
  } else {
    return null;
  }
  if (!adminId || !Number.isFinite(issuedAt)) return null;
  // Idle timeout (and reject clock-skewed future tokens beyond a small grace).
  if (now - issuedAt > maxAgeMs) return null;
  if (issuedAt - now > 60 * 1000) return null;

  const role = await roleFor(kv, adminId);
  if (!role) return null; // admin was deleted
  const passHash = await passHashFor(kv, adminId);
  if (!passHash) return null; // no password set
  const key = await getAuthKey(kv);
  const expected = sign(key, userAgent, adminId, passHash, issuedAt);
  if (!safeEqualStr(mac, expected)) return null;
  return { id: adminId, role };
}

/**
 * Verify a session cookie value. Boolean wrapper over resolveSession.
 * @returns {Promise<boolean>}
 */
export async function verifySession(kv, cookieValue, o = {}) {
  return !!(await resolveSession(kv, cookieValue, o));
}

/** Parse the auth cookie value out of a raw Cookie header. */
export function readAuthCookie(cookieHeader = "") {
  for (const part of String(cookieHeader).split(";")) {
    const eq = part.indexOf("=");
    if (eq < 0) continue;
    if (part.slice(0, eq).trim() === COOKIE_NAME) {
      return part.slice(eq + 1).trim();
    }
  }
  return null;
}

/** Set-Cookie value that clears the session. */
export function clearSessionCookie() {
  return `${COOKIE_NAME}=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0`;
}

// --- helpers --------------------------------------------------------------

function safeEqualStr(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ba.length !== bb.length) return false;
  return timingSafeEqual(ba, bb);
}

export { COOKIE_NAME };
