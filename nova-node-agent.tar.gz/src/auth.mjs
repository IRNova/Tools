// Nova VPS agent: admin session model (mirrors the panel).
//
// Stateless auth: the admin password is stored (as a salted hash) at KV key
// "admin_pass". A logged-in admin carries a signed cookie
//
//   auth=<issuedAt>.<hex HMAC-SHA256(key, "UA|pass|issuedAt")>
//
// where:
//   issuedAt  ms epoch the token was minted
//   key       a per-install random secret at KV key "auto_key" (made on first use)
//   UA        the request User-Agent, so a stolen cookie is pinned to one client
//   pass      the stored password hash, so changing the password invalidates all
//             outstanding cookies
//
// Verification recomputes the HMAC (timing-safe) and enforces an idle timeout.
// Nothing about the session is stored server-side, so it survives restarts.

import {
  createHmac,
  randomBytes,
  scryptSync,
  timingSafeEqual,
} from "node:crypto";

const DEFAULT_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000; // 7 days idle timeout
const COOKIE_NAME = "auth";

// --- password storage -----------------------------------------------------
// Stored form: "scrypt$<saltHex>$<hashHex>". Timing-safe compare on verify.

function hashPassword(password, saltHex) {
  const salt = saltHex || randomBytes(16).toString("hex");
  const hash = scryptSync(String(password), salt, 32).toString("hex");
  return `scrypt$${salt}$${hash}`;
}

/** Store (hash) the admin password at KV "admin_pass". */
export async function setPassword(kv, password) {
  const stored = hashPassword(password);
  await kv.put("admin_pass", stored);
  return stored;
}

/** Timing-safe check of a candidate password against KV "admin_pass". */
export async function checkPassword(kv, password) {
  const stored = await kv.get("admin_pass");
  if (!stored) return false;
  const parts = stored.split("$");
  if (parts.length !== 3 || parts[0] !== "scrypt") return false;
  const [, salt] = parts;
  const candidate = hashPassword(password, salt);
  return safeEqualStr(candidate, stored);
}

// --- signing key ----------------------------------------------------------

/** Fetch the per-install HMAC key, creating a random one on first use. */
export async function getAuthKey(kv) {
  let key = await kv.get("auto_key");
  if (!key) {
    key = randomBytes(32).toString("hex");
    await kv.put("auto_key", key);
  }
  return key;
}

// --- session cookie -------------------------------------------------------

function sign(key, ua, passHash, issuedAt) {
  return createHmac("sha256", key)
    .update(`${ua}|${passHash}|${issuedAt}`)
    .digest("hex");
}

/**
 * Mint a session cookie for a freshly authenticated admin.
 * @returns {{name:string, value:string, cookie:string}} cookie is the full
 *   Set-Cookie header value.
 */
export async function makeSession(kv, { userAgent = "", now = Date.now() } = {}) {
  const key = await getAuthKey(kv);
  const passHash = (await kv.get("admin_pass")) || "";
  const issuedAt = now;
  const mac = sign(key, userAgent, passHash, issuedAt);
  const value = `${issuedAt}.${mac}`;
  const cookie =
    `${COOKIE_NAME}=${value}; HttpOnly; Secure; SameSite=Lax; Path=/; ` +
    `Max-Age=${Math.floor(DEFAULT_MAX_AGE_MS / 1000)}`;
  return { name: COOKIE_NAME, value, cookie };
}

/**
 * Verify a session cookie value against the current UA, password and key.
 * @returns {Promise<boolean>}
 */
export async function verifySession(
  kv,
  cookieValue,
  { userAgent = "", now = Date.now(), maxAgeMs = DEFAULT_MAX_AGE_MS } = {},
) {
  if (!cookieValue || typeof cookieValue !== "string") return false;
  const dot = cookieValue.indexOf(".");
  if (dot <= 0) return false;
  const issuedAt = Number(cookieValue.slice(0, dot));
  const mac = cookieValue.slice(dot + 1);
  if (!Number.isFinite(issuedAt)) return false;
  // Idle timeout (and reject clock-skewed future tokens beyond a small grace).
  if (now - issuedAt > maxAgeMs) return false;
  if (issuedAt - now > 60 * 1000) return false;

  const key = await getAuthKey(kv);
  const passHash = (await kv.get("admin_pass")) || "";
  const expected = sign(key, userAgent, passHash, issuedAt);
  return safeEqualStr(mac, expected);
}

/** Parse the auth cookie value out of a raw Cookie header. */
export function readAuthCookie(cookieHeader = "") {
  for (const part of String(cookieHeader).split(";")) {
    const eq = part.indexOf("=");
    if (eq < 0) continue;
    if (part.slice(0, eq).trim() === COOKIE_NAME) {
      return part.slice(eq + 1).trim();
    }
  }
  return null;
}

/** Set-Cookie value that clears the session. */
export function clearSessionCookie() {
  return `${COOKIE_NAME}=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0`;
}

// --- helpers --------------------------------------------------------------

function safeEqualStr(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ba.length !== bb.length) return false;
  return timingSafeEqual(ba, bb);
}

export { COOKIE_NAME };
