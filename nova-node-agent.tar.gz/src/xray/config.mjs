// Nova VPS agent — xray config generator.
//
// Turns the panel's user registry (the `users[]` array stored inside
// network-settings.json) into an xray-core config.json: one VLESS client per
// enabled user on a single VLESS + WebSocket + TLS inbound, plus the stats/api
// plumbing the traffic bridge needs.
//
// TLS uses the Cloudflare Origin Certificate installed on the VPS, so Cloudflare
// can run Full (strict). Cloudflare fronts :443 -> origin :443 (WS upgrade).

/**
 * @param {Array<object>} users  Nova user objects. Recognised fields:
 *   uuid|id   -> VLESS client UUID (must be a real UUID)
 *   email|id  -> stable per-user label; xray reports traffic keyed by this
 *   enabled   -> false disables the client (defaults to enabled)
 * @param {object} opts
 */
// The WebSocket paths each protocol is served on, derived from the base wsPath.
// The TLS front on :443 dispatches to the right internal inbound by path, so
// every protocol shares one public port. Kept in one place so the config
// generator and the subscription builder always agree.
export function protocolPaths(wsPath = "/nova") {
  return {
    vless: wsPath,
    vmess: `${wsPath}-vm`,
    trojan: `${wsPath}-tj`,
  };
}

// Which protocols to serve, given the panel's `protocols` setting. VLESS is
// always on (it is the default and the panel's own control link).
export function enabledProtocols(protocols = {}) {
  return {
    vless: protocols.vless !== false,
    vmess: protocols.vmess === true,
    trojan: protocols.trojan === true,
  };
}

export function generateXrayConfig(users, opts = {}) {
  const {
    listen = "0.0.0.0",
    port = 443,
    wsPath = "/nova",
    certificateFile = "/etc/nova/origin.pem",
    keyFile = "/etc/nova/origin.key",
    apiAddr = "127.0.0.1",
    apiPort = 10085,
    logLevel = "warning",
    // The agent's local HTTP panel. xray terminates TLS on :443 and forwards
    // every non-tunnel request here, so the panel is reachable on the same
    // public 443 (works behind Cloudflare full-strict OR direct with a
    // self-signed cert for the no-domain case).
    panelPort = 8088,
    // Internal plaintext inbounds the TLS front falls back to. Loopback only.
    // vless: base, vmess: base+1, trojan: base+2.
    wsInternalPort = 2087,
    // Which protocols to serve. VLESS is always on.
    protocols = { vless: true },
  } = opts;

  const on = enabledProtocols(protocols);
  const paths = protocolPaths(wsPath);
  const active = users.filter((u) => u.enabled !== false);
  const idOf = (u) => u.uuid || u.id;
  const emailOf = (u) => String(u.email || u.id);

  // Per-protocol client lists (same users, protocol-specific credential shape).
  const vlessClients = active.map((u) => ({ id: idOf(u), email: emailOf(u), level: 0 }));
  const vmessClients = active.map((u) => ({ id: idOf(u), email: emailOf(u), level: 0 }));
  const trojanClients = active.map((u) => ({ password: idOf(u), email: emailOf(u), level: 0 }));

  const vmessPort = wsInternalPort + 1;
  const trojanPort = wsInternalPort + 2;

  // Build the front's path->inbound dispatch table and the internal inbounds.
  const fallbacks = [];
  const protoInbounds = [];

  if (on.vless) {
    fallbacks.push({ path: paths.vless, dest: `127.0.0.1:${wsInternalPort}`, xver: 0 });
    protoInbounds.push({
      // vless-ws stays the first user-bearing inbound (hot-patch targets it).
      tag: "vless-ws",
      listen: "127.0.0.1",
      port: wsInternalPort,
      protocol: "vless",
      settings: { clients: vlessClients, decryption: "none" },
      streamSettings: { network: "ws", security: "none", wsSettings: { path: paths.vless } },
      sniffing: { enabled: true, destOverride: ["http", "tls"] },
    });
  }
  if (on.vmess) {
    fallbacks.push({ path: paths.vmess, dest: `127.0.0.1:${vmessPort}`, xver: 0 });
    protoInbounds.push({
      tag: "vmess-ws",
      listen: "127.0.0.1",
      port: vmessPort,
      protocol: "vmess",
      settings: { clients: vmessClients },
      streamSettings: { network: "ws", security: "none", wsSettings: { path: paths.vmess } },
      sniffing: { enabled: true, destOverride: ["http", "tls"] },
    });
  }
  if (on.trojan) {
    fallbacks.push({ path: paths.trojan, dest: `127.0.0.1:${trojanPort}`, xver: 0 });
    protoInbounds.push({
      tag: "trojan-ws",
      listen: "127.0.0.1",
      port: trojanPort,
      protocol: "trojan",
      settings: { clients: trojanClients },
      streamSettings: { network: "ws", security: "none", wsSettings: { path: paths.trojan } },
      sniffing: { enabled: true, destOverride: ["http", "tls"] },
    });
  }
  // Everything else (the panel, plus any unmatched path) -> the agent.
  fallbacks.push({ dest: `127.0.0.1:${panelPort}`, xver: 0 });

  const front = {
    // Public TLS front on :443: carries no users, terminates TLS, dispatches by
    // path to the per-protocol internal inbounds, and falls back to the panel.
    tag: "front",
    listen,
    port,
    protocol: "vless",
    settings: { clients: [], decryption: "none", fallbacks },
    streamSettings: {
      network: "tcp",
      security: "tls",
      tlsSettings: {
        // Cloudflare Origin Cert (domain) or a self-signed cert (no-domain).
        certificates: [{ certificateFile, keyFile }],
        alpn: ["http/1.1"],
      },
    },
  };

  return {
    log: { loglevel: logLevel },
    stats: {},
    api: { tag: "api", services: ["StatsService", "HandlerService"] },
    policy: {
      levels: { "0": { statsUserUplink: true, statsUserDownlink: true } },
      system: { statsInboundUplink: true, statsInboundDownlink: true },
    },
    inbounds: [
      front,
      ...protoInbounds,
      {
        // Local-only control plane for `xray api ...`.
        tag: "api",
        listen: apiAddr,
        port: apiPort,
        protocol: "dokodemo-door",
        settings: { address: apiAddr },
      },
    ],
    outbounds: [
      { tag: "direct", protocol: "freedom" },
      { tag: "block", protocol: "blackhole" },
    ],
    routing: {
      rules: [{ type: "field", inboundTag: ["api"], outboundTag: "api" }],
    },
  };
}

// The email xray reports under, given a Nova user. Kept in one place so the
// stats bridge and the config generator always agree.
export const emailForUser = (u) => String(u.email || u.id);
