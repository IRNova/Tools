// Nova VPS agent: xray process/config manager.
//
// applyUsers(users, opts) takes the panel's user registry and makes xray serve
// exactly those users:
//   1. generateXrayConfig(users) -> write /usr/local/etc/xray/config.json atomically
//   2. ensure the Cloudflare origin cert is group-readable by xray (User=nobody)
//   3. reload xray, preferring hot HandlerService add/remove (no dropped conns)
//      and falling back to `systemctl restart xray`.
//
// Every external path and command is overridable via opts/env so this runs on a
// dev machine with no xray installed: set opts.exec = false (or NOVA_NO_EXEC=1)
// and it only writes the config, no-oping the shell-outs.

import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { writeFileSync, renameSync, mkdirSync, chmodSync, rmSync } from "node:fs";
import { dirname, join } from "node:path";
import { tmpdir } from "node:os";
import { randomBytes } from "node:crypto";
import { generateXrayConfig, emailForUser, enabledProtocols } from "./config.mjs";
import { generateSingboxConfig } from "../singbox/config.mjs";

const pExecFile = promisify(execFile);

// Cap every shell-out so a wedged xray/systemctl cannot hang the caller (L5).
const EXEC_TIMEOUT_MS = 10_000;

function envBool(name) {
  const v = process.env[name];
  return v === "1" || v === "true" || v === "yes";
}

/**
 * @param {Array<object>} users  Nova user registry (users[] from settings).
 * @param {object} opts
 *   configPath   where xray reads its config (default /usr/local/etc/xray/config.json)
 *   certPem/certKey  origin cert paths to fix perms on (default /etc/nova/origin.{pem,key})
 *   certGroup    group that must read the key (default "nogroup")
 *   xrayBin      xray binary (default "xray")
 *   apiAddr      stats/api gRPC address (default 127.0.0.1:10085)
 *   service      systemd unit name (default "xray")
 *   inboundTag   inbound to hot-patch (default "vless-ws")
 *   exec         false to no-op all shell-outs (dev). Default: !NOVA_NO_EXEC.
 *   prev         previous users[] to diff against for hot add/remove
 *   forceReload  true to force a full restart (config-only change, e.g. wsPath)
 *   runExec      execFile-like fn (bin, args, opts) => Promise; injectable for tests
 *   xrayOpts     forwarded to generateXrayConfig (wsPath, port, cert paths, ...)
 * @returns {Promise<{wrote:boolean, method:string, added:string[], removed:string[]}>}
 */
export async function applyUsers(users, opts = {}) {
  const {
    configPath = process.env.NOVA_XRAY_CONFIG ||
      "/usr/local/etc/xray/config.json",
    certPem = process.env.NOVA_CERT_PEM || "/etc/nova/origin.pem",
    certKey = process.env.NOVA_CERT_KEY || "/etc/nova/origin.key",
    certGroup = process.env.NOVA_CERT_GROUP || "nogroup",
    xrayBin = process.env.NOVA_XRAY_BIN || "xray",
    apiAddr = process.env.NOVA_XRAY_API || "127.0.0.1:10085",
    service = process.env.NOVA_XRAY_SERVICE || "xray",
    inboundTag = "vless-ws",
    exec = !envBool("NOVA_NO_EXEC"),
    prev = null,
    forceReload = false,
    runExec = pExecFile,
    xrayOpts = {},
    validateOnly = false,
  } = opts;

  // Cert paths in the generated config should match what we fix perms on.
  const cfgOpts = {
    certificateFile: certPem,
    keyFile: certKey,
    apiAddr: apiAddr.split(":")[0],
    apiPort: Number(apiAddr.split(":")[1] || 10085),
    ...xrayOpts,
  };
  const config = generateXrayConfig(users, cfgOpts);

  // Validate the new config with `xray -test` BEFORE committing it, so a bad
  // routing rule (e.g. a geosite code not in the .dat) or any other error can
  // never brick the node: the running config is left in place and the caller
  // gets an error instead of a dead xray.
  if (exec) {
    await validateXrayConfig(config, runExec, xrayBin);
  }

  // Validate-only: the caller just wants to know xray would accept this config
  // (used to reject a bad settings change before it is persisted). No write, no
  // reload, no sing-box bounce.
  if (validateOnly) {
    return { wrote: false, method: "validated", added: [], removed: [] };
  }

  writeJsonAtomic(configPath, config);

  if (!exec) {
    return { wrote: true, method: "noop", added: [], removed: [] };
  }

  await ensureCertPerms({ certPem, certKey, certGroup, runExec });
  ensureAccessLogDir(process.env.NOVA_ACCESS_LOG || "/var/log/nova/access.log");

  // A config-only change (wsPath/cert/port/...) is written to config.json but the
  // running xray still serves the old config, so it must be reloaded. Only a pure
  // add/remove of users can be hot-patched via HandlerService without dropping
  // live connections. (H3)
  //
  // Hot-patch adds the user to the front's vless-ws inbound only. When the node
  // also has standalone inbounds (Reality, gRPC, ...), a hot add would leave the
  // user missing from those, so fall back to a full reload to keep every inbound
  // consistent. Users appear everywhere at the cost of a brief reconnect.
  const hasStandalone = (cfgOpts.inbounds || []).some((i) => i && i.enabled !== false);
  const canHotPatch = !forceReload && prev && !hasStandalone;
  const diff = canHotPatch ? diffUsers(prev, users) : null;
  if (canHotPatch && !diff.added.length && !diff.removed.length) {
    // Nothing changed; leave xray AND sing-box running untouched (no-op).
    return { wrote: true, method: "unchanged", added: [], removed: [] };
  }

  // Something changed: bring the sing-box Hysteria2 path in line alongside xray
  // (it has no hot-patch, so it is always a config rewrite + bounce here).
  await applySingbox(users, {
    protocols: xrayOpts.protocols,
    hy2Port: xrayOpts.hy2Port,
    certPem,
    certKey,
    runExec,
  });

  if (canHotPatch) {
    try {
      for (const u of diff.removed) {
        await handlerRemoveUser(runExec, xrayBin, apiAddr, inboundTag, emailForUser(u));
      }
      for (const u of diff.added) {
        await handlerAddUser(runExec, xrayBin, apiAddr, inboundTag, u);
      }
      return {
        wrote: true,
        method: "hot",
        added: diff.added.map(emailForUser),
        removed: diff.removed.map(emailForUser),
      };
    } catch (err) {
      // Hot patch failed (old xray, API off, ...): fall through to restart.
    }
  }

  await restartService(runExec, service);
  return { wrote: true, method: "restart", added: [], removed: [] };
}

// --- config write ---------------------------------------------------------

// Run `xray -test` against a candidate config in a temp file. Throws a readable
// error (surfaced to the panel) if xray rejects it, so a bad rule never lands.
async function validateXrayConfig(config, runExec, xrayBin) {
  const tmp = `/tmp/nova-xray-test-${process.pid}-${randomBytes(6).toString("hex")}.json`;
  try {
    writeFileSync(tmp, JSON.stringify(config));
    await runExec(xrayBin, ["-test", "-c", tmp], { timeout: 15000 });
  } catch (err) {
    const detail = (err && (err.stderr || err.message) ? String(err.stderr || err.message) : "").trim();
    const reason = /(code not found in geosite|code not found in geoip|invalid field rule|failed to [^\n]+)/i.exec(detail);
    throw new Error("xray rejected the new config" + (reason ? `: ${reason[1]}` : ""));
  } finally {
    try { rmSync(tmp); } catch {}
  }
}

function writeJsonAtomic(path, obj) {
  mkdirSync(dirname(path), { recursive: true });
  // Unique temp name per write so two in-flight applies never share a file (M7).
  const tmp = `${path}.tmp-${process.pid}-${randomBytes(6).toString("hex")}`;
  try {
    writeFileSync(tmp, JSON.stringify(obj, null, 2) + "\n");
    renameSync(tmp, path); // atomic on the same filesystem
  } catch (err) {
    try {
      rmSync(tmp);
    } catch {}
    throw err;
  }
}

// --- cert perms (finding #1 from the first VPS validation) -----------------

// xray runs as `nobody`; it must be able to create + append the access log, so
// the directory has to be world-writable. Best-effort (non-fatal on failure).
function ensureAccessLogDir(accessLog) {
  try {
    const dir = dirname(accessLog);
    mkdirSync(dir, { recursive: true });
    chmodSync(dir, 0o777);
  } catch {}
}

async function ensureCertPerms({ certPem, certKey, certGroup, runExec = pExecFile }) {
  for (const f of [certPem, certKey]) {
    try {
      await runExec("chgrp", [certGroup, f], { timeout: EXEC_TIMEOUT_MS });
      chmodSync(f, 0o640);
    } catch (err) {
      // Non-fatal here: surfaced by xray failing to start if truly unreadable.
    }
  }
}

// --- hot reload via HandlerService ----------------------------------------

// Diff two user registries into the enabled-client add/remove sets that
// HandlerService can apply. Anything else that affects xray (wsPath, cert, port)
// is handled by the caller forcing a reload; see applyUsers.
function diffUsers(prev, next) {
  const key = (u) => emailForUser(u);
  const prevMap = new Map(prev.map((u) => [key(u), u]));
  const nextMap = new Map(next.map((u) => [key(u), u]));

  const enabled = (u) => u.enabled !== false;
  const added = [];
  const removed = [];

  for (const [k, u] of nextMap) {
    const before = prevMap.get(k);
    if (!before) {
      if (enabled(u)) added.push(u);
    } else if (enabled(u) && !enabled(before)) {
      added.push(u);
    } else if (!enabled(u) && enabled(before)) {
      removed.push(u);
    } else if (enabled(u) && (u.uuid || u.id) !== (before.uuid || before.id)) {
      // A UUID change means remove-then-add for that email.
      removed.push(before);
      added.push(u);
    }
  }
  for (const [k, u] of prevMap) {
    if (!nextMap.has(k) && enabled(u)) removed.push(u);
  }
  return { added, removed };
}

// xray-core v26.3.27: `adu` loads inbound config docs (positional file paths or
// `stdin:`) and reads the tag + clients from each; there are no -email/-uuid
// flags. We feed one client via a temp JSON file.
async function handlerAddUser(runExec, xrayBin, apiAddr, inboundTag, user) {
  const doc = {
    inbounds: [
      {
        tag: inboundTag,
        protocol: "vless",
        settings: {
          clients: [
            {
              id: String(user.uuid || user.id),
              email: emailForUser(user),
              level: 0,
            },
          ],
          decryption: "none",
        },
      },
    ],
  };
  const tmp = join(
    tmpdir(),
    `nova-adu-${process.pid}-${randomBytes(6).toString("hex")}.json`,
  );
  writeFileSync(tmp, JSON.stringify(doc));
  try {
    await runExec(xrayBin, ["api", "adu", `--server=${apiAddr}`, tmp], {
      timeout: EXEC_TIMEOUT_MS,
    });
  } finally {
    try {
      rmSync(tmp);
    } catch {}
  }
}

// xray-core v26.3.27: `rmu` takes `-tag=<tag>` plus one or more emails as
// positional args; there is no -email flag.
async function handlerRemoveUser(runExec, xrayBin, apiAddr, inboundTag, email) {
  await runExec(
    xrayBin,
    ["api", "rmu", `--server=${apiAddr}`, `-tag=${inboundTag}`, email],
    { timeout: EXEC_TIMEOUT_MS },
  );
}

// --- fallback restart ------------------------------------------------------

async function restartService(runExec, service) {
  await runExec("systemctl", ["restart", service], { timeout: EXEC_TIMEOUT_MS });
}

// Manage the co-located sing-box service (Hysteria2 on UDP :443). Writes its
// config and bounces the service when hysteria2 is on; stops it when off. A
// missing sing-box binary/service is swallowed so it never breaks the xray
// apply (a node without sing-box just has no Hysteria2 path).
async function applySingbox(users, { protocols, hy2Port, certPem, certKey, runExec }) {
  const on = enabledProtocols(protocols || {});
  const service = process.env.NOVA_SINGBOX_SERVICE || "sing-box";
  const configPath =
    process.env.NOVA_SINGBOX_CONFIG || "/etc/sing-box/config.json";
  if (!on.hysteria2) {
    try {
      await runExec("systemctl", ["stop", service], { timeout: EXEC_TIMEOUT_MS });
    } catch {}
    return;
  }
  try {
    const cfg = generateSingboxConfig(users, {
      port: Number(hy2Port) || 443,
      certificateFile: certPem,
      keyFile: certKey,
    });
    writeJsonAtomic(configPath, cfg);
    await runExec("systemctl", ["restart", service], { timeout: EXEC_TIMEOUT_MS });
  } catch {
    // sing-box not installed on this node; the Hysteria2 path is simply absent.
  }
}

export { writeJsonAtomic };
