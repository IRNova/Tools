// Nova VPS agent — Cloudflare WARP (WireGuard) account provisioning.
//
// Nova-Proxy's headline "make calls work" routes UDP through Cloudflare WARP. On
// a real xray node we register a free WARP account (a WireGuard keypair enrolled
// with Cloudflare), store it, and hand it to routing.mjs which builds the
// `wireguard` outbound. Selected traffic (all, or just UDP for calls) is then
// routed through WARP.

import { execFile } from "node:child_process";
import { promisify } from "node:util";

const pExecFile = promisify(execFile);

const REG_URL = "https://api.cloudflareclient.com/v0a2158/reg";
const CF_HEADERS = {
  "content-type": "application/json",
  "cf-client-version": "a-6.11-2158",
  "user-agent": "okhttp/3.12.1",
};

/** A WireGuard keypair via `xray wg`, with a Node X25519 fallback for tests. */
export async function genWireguardKeys(runExec = pExecFile, xrayBin = "xray") {
  try {
    const { stdout } = await runExec(xrayBin, ["wg"], { timeout: 10_000 });
    const priv = /Private ?Key:\s*(\S+)/i.exec(stdout);
    const pub = /(?:Public ?Key|Password \(PublicKey\)):\s*(\S+)/i.exec(stdout);
    if (priv && pub) return { privateKey: priv[1], publicKey: pub[1] };
  } catch {
    // fall through
  }
  const { generateKeyPairSync } = await import("node:crypto");
  const { privateKey, publicKey } = generateKeyPairSync("x25519");
  const b64 = (der) => Buffer.from(der).toString("base64");
  return {
    privateKey: b64(privateKey.export({ type: "pkcs8", format: "der" }).subarray(-32)),
    publicKey: b64(publicKey.export({ type: "spki", format: "der" }).subarray(-32)),
  };
}

// Cloudflare hands back a base64 client_id; WireGuard's "reserved" field is its
// first three bytes as integers.
export function reservedFromClientId(clientId) {
  try {
    const b = Buffer.from(String(clientId), "base64");
    if (b.length >= 3) return [b[0], b[1], b[2]];
  } catch {}
  return null;
}

/**
 * Register a free WARP account and return everything the WireGuard outbound
 * needs. Best-effort: throws on a failed enrollment so the caller can surface it
 * and leave WARP off rather than writing a broken outbound.
 *
 * @param {object} opts
 *   wgKeys     { privateKey, publicKey } (generated if omitted)
 *   nowIso     ISO timestamp for the tos field (injectable for tests)
 *   fetchImpl  fetch (injectable)
 *   runExec    execFile-like (for key generation)
 */
export async function registerWarp({ wgKeys = null, nowIso = null, fetchImpl = fetch, runExec = pExecFile } = {}) {
  const keys = wgKeys || (await genWireguardKeys(runExec));
  const body = {
    key: keys.publicKey,
    install_id: "",
    fcm_token: "",
    tos: nowIso || new Date().toISOString(),
    model: "PC",
    type: "Android",
    locale: "en_US",
  };
  const res = await fetchImpl(REG_URL, { method: "POST", headers: CF_HEADERS, body: JSON.stringify(body) });
  if (!res.ok) throw new Error(`WARP registration failed (${res.status})`);
  const data = await res.json();
  return accountFromRegistration(keys, data);
}

/** Shape a Cloudflare registration response into a stored WARP account. */
export function accountFromRegistration(keys, data) {
  const conf = data.config || {};
  const peer = (conf.peers && conf.peers[0]) || {};
  const iface = conf.interface || {};
  const addr = iface.addresses || {};
  const ep = peer.endpoint || {};
  const host = ep.host || `${ep.v4 || "engage.cloudflareclient.com"}`;
  return {
    privateKey: keys.privateKey,
    publicKey: keys.publicKey,
    peerPublicKey: peer.public_key || "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo=",
    reserved: reservedFromClientId(conf.client_id) || undefined,
    addressV4: (addr.v4 ? `${addr.v4}/32` : "172.16.0.2/32"),
    addressV6: addr.v6 ? `${addr.v6}/128` : undefined,
    endpoint: host && String(host).includes(":") ? host : "engage.cloudflareclient.com:2408",
    mtu: 1280,
    registeredAt: (data && data.created) || null,
  };
}
