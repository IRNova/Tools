// Nova VPS agent — data-driven inbound model (Phase 1).
//
// The legacy generator (config.mjs) hardcodes ONE topology: a TLS front on :443
// that dispatches WebSocket paths to VLESS/VMess/Trojan and falls back to the
// panel. That is a single protocol/transport/security shape. This module adds
// STANDALONE inbounds so a node can expose the rest of xray's surface, each on
// its own port:
//
//   - REALITY (+ XTLS-Vision flow) — no domain or certificate, DPI-resistant
//   - gRPC / XHTTP / HTTPUpgrade transports (over TLS or Reality)
//   - Shadowsocks-2022
//
// Inbounds are stored as plain data inside network-settings.json (`inbounds[]`).
// Users are assigned to them (by id, or `allUsers`). `buildInbound` turns one
// record into an xray inbound object that the config generator drops in next to
// the front, and the subscription builder emits matching share links.

import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { randomBytes, createHash } from "node:crypto";

const pExecFile = promisify(execFile);

export const PROTOCOLS = ["vless", "vmess", "trojan", "shadowsocks"];
export const NETWORKS = ["tcp", "ws", "grpc", "xhttp", "httpupgrade"];
export const SECURITIES = ["none", "tls", "reality"];
export const VISION_FLOW = "xtls-rprx-vision";
// Shadowsocks-2022 method we standardise on (16-byte key, AEAD, replay-safe).
export const SS_METHOD = "2022-blake3-aes-128-gcm";
const SS_KEY_BYTES = 16;

// A base64url encoder without padding, matching the shape xray uses for Reality
// keys and what SS-2022 keys are conventionally written as.
function b64url(buf) {
  return Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

// --- creation-time key material ---------------------------------------------

/**
 * Generate a Reality x25519 keypair. Prefers `xray x25519` (authoritative, byte
 * for byte what the running xray expects); falls back to Node's own X25519 if
 * the binary is unavailable (e.g. tests). Returns { privateKey, publicKey }
 * base64url-encoded.
 */
export async function genRealityKeys(runExec = pExecFile, xrayBin = "xray") {
  try {
    const { stdout } = await runExec(xrayBin, ["x25519"], { timeout: 10_000 });
    const priv = /Private ?Key:\s*(\S+)/i.exec(stdout);
    const pub = /(?:Password \(PublicKey\)|Public ?Key):\s*(\S+)/i.exec(stdout);
    if (priv && pub) return { privateKey: priv[1], publicKey: pub[1] };
  } catch {
    // fall through to the Node implementation
  }
  const { generateKeyPairSync } = await import("node:crypto");
  const { privateKey, publicKey } = generateKeyPairSync("x25519");
  // X25519 keys have a fixed DER structure; the raw 32-byte scalar / point are
  // the final 32 bytes of the pkcs8 / spki encodings.
  const rawPriv = privateKey.export({ type: "pkcs8", format: "der" }).subarray(-32);
  const rawPub = publicKey.export({ type: "spki", format: "der" }).subarray(-32);
  return { privateKey: b64url(rawPriv), publicKey: b64url(rawPub) };
}

/** A Reality shortId: 0 to 16 hex chars, even length. Default 8 (4 bytes). */
export function genShortId(bytes = 4) {
  return randomBytes(bytes).toString("hex");
}

/** A fresh Shadowsocks-2022 server pre-shared key (base64, method key length). */
export function genSSPassword() {
  return Buffer.from(randomBytes(SS_KEY_BYTES)).toString("base64");
}

// A user's SS-2022 pre-shared key. Derived deterministically from their id so it
// is stable across restarts without having to persist a separate secret.
function ssUserKey(seed) {
  return createHash("sha256").update(String(seed)).digest().subarray(0, SS_KEY_BYTES).toString("base64");
}

// --- record normalisation + validation --------------------------------------

let _tagSeq = 0;

/** Fill defaults + a stable tag on a raw inbound record from the panel. */
export function normalizeInbound(raw = {}) {
  const inb = {
    id: raw.id || `in-${randomBytes(4).toString("hex")}`,
    enabled: raw.enabled !== false,
    protocol: raw.protocol || "vless",
    network: raw.network || "tcp",
    security: raw.security || "reality",
    listen: raw.listen || "0.0.0.0",
    port: Number(raw.port) || 0,
    remark: raw.remark || "",
    // transport
    path: raw.path || "/",
    host: raw.host || "",
    serviceName: raw.serviceName || "",
    xhttpMode: raw.xhttpMode || "auto",
    // tls / reality
    sni: raw.sni || "",
    alpn: Array.isArray(raw.alpn) ? raw.alpn : undefined,
    fingerprint: raw.fingerprint || "chrome",
    flow: raw.flow || "",
    reality: raw.reality || null,
    // shadowsocks
    method: raw.method || SS_METHOD,
    ssPassword: raw.ssPassword || "",
    // who is served on this inbound
    allUsers: raw.allUsers !== false,
    userIds: Array.isArray(raw.userIds) ? raw.userIds : [],
  };
  inb.tag = raw.tag || `${inb.protocol}-${inb.network}-${(_tagSeq++).toString(36)}`;
  return inb;
}

/**
 * Reject combinations xray would refuse to load, so the panel can never push a
 * config that bricks the node. Returns { ok, error }.
 */
export function validateInbound(inb) {
  const bad = (m) => ({ ok: false, error: m });
  if (!PROTOCOLS.includes(inb.protocol)) return bad(`unknown protocol ${inb.protocol}`);
  if (!NETWORKS.includes(inb.network)) return bad(`unknown network ${inb.network}`);
  if (!SECURITIES.includes(inb.security)) return bad(`unknown security ${inb.security}`);
  if (!(inb.port >= 1 && inb.port <= 65535)) return bad("port out of range");

  if (inb.security === "reality") {
    if (!["vless", "trojan"].includes(inb.protocol)) return bad("reality needs vless or trojan");
    if (inb.network === "ws") return bad("reality does not pair with websocket");
    const r = inb.reality;
    if (!r || !r.privateKey || !Array.isArray(r.serverNames) || !r.serverNames.length || !r.dest) {
      return bad("reality needs dest, serverNames and a keypair");
    }
  }
  if (inb.security === "tls" && !inb.sni) return bad("tls needs a server name (sni)");

  if (inb.flow) {
    if (inb.flow !== VISION_FLOW) return bad(`unknown flow ${inb.flow}`);
    if (inb.protocol !== "vless" || inb.network !== "tcp") {
      return bad("xtls-rprx-vision only on vless over tcp");
    }
    if (inb.security === "none") return bad("vision needs tls or reality");
  }
  if (inb.protocol === "shadowsocks") {
    if (inb.security !== "none") return bad("shadowsocks brings its own encryption");
    if (inb.network !== "tcp") return bad("shadowsocks (phase 1) is tcp only");
  }
  return { ok: true };
}

// --- per-user client lists ---------------------------------------------------

const emailOf = (u) => String(u.email || u.id);
const uuidOf = (u) => u.uuid || u.id;

/** Is this (enabled) user served on this inbound? */
export function servesUser(inb, u) {
  if (u.enabled === false) return false;
  if (inb.allUsers) return true;
  return (inb.userIds || []).includes(u.id);
}

/**
 * The credential one user presents on one inbound, in the protocol's shape:
 * vless/vmess -> a UUID (`{ id }`), trojan -> `{ password }`, shadowsocks ->
 * `{ password }` (the per-user PSK). Per-protocol overrides live under
 * user.proxies.<protocol>, else the user's uuid is reused / derived. The config
 * generator and the subscription builder both call this so a link always
 * matches what xray accepts.
 */
export function userCredential(inb, u) {
  const px = (u.proxies && u.proxies[inb.protocol]) || {};
  if (inb.protocol === "trojan") return px.password || uuidOf(u);
  if (inb.protocol === "shadowsocks") return px.password || ssUserKey(uuidOf(u));
  return px.id || uuidOf(u); // vless, vmess
}

/**
 * The xray `clients` array for one inbound, in the credential shape its protocol
 * needs. Per-protocol overrides live under user.proxies.<protocol>, else the
 * user's uuid is reused (back-compat with the flat model).
 */
export function clientsForInbound(inb, users, { dedupe = true } = {}) {
  const seen = new Set();
  const out = [];
  for (const u of users) {
    if (!servesUser(inb, u)) continue;
    const email = emailOf(u);
    if (dedupe) {
      if (seen.has(email)) continue;
      seen.add(email);
    }
    const cred = userCredential(inb, u);
    if (inb.protocol === "vless") {
      const c = { id: cred, email, level: 0 };
      if (inb.flow) c.flow = inb.flow;
      out.push(c);
    } else if (inb.protocol === "vmess") {
      out.push({ id: cred, email, level: 0 });
    } else if (inb.protocol === "trojan") {
      out.push({ password: cred, email, level: 0 });
    } else if (inb.protocol === "shadowsocks") {
      // SS-2022 multi-user: the method lives only on the inbound; per-user
      // entries carry just their PSK (xray rejects a per-client method).
      out.push({ password: cred, email, level: 0 });
    }
  }
  return out;
}

// --- xray inbound object -----------------------------------------------------

function streamSettings(inb, defaults) {
  const ss = { network: inb.network === "tcp" ? "tcp" : inb.network };

  // transport
  if (inb.network === "ws") {
    ss.wsSettings = { path: inb.path || "/", ...(inb.host ? { host: inb.host } : {}) };
  } else if (inb.network === "grpc") {
    ss.grpcSettings = { serviceName: inb.serviceName || "nova" };
  } else if (inb.network === "xhttp") {
    ss.xhttpSettings = { path: inb.path || "/", mode: inb.xhttpMode || "auto", ...(inb.host ? { host: inb.host } : {}) };
  } else if (inb.network === "httpupgrade") {
    ss.httpupgradeSettings = { path: inb.path || "/", ...(inb.host ? { host: inb.host } : {}) };
  } else {
    ss.tcpSettings = { header: { type: "none" } };
  }

  // security
  if (inb.security === "tls") {
    ss.security = "tls";
    ss.tlsSettings = {
      serverName: inb.sni,
      alpn: inb.alpn || (inb.network === "grpc" ? ["h2"] : ["h2", "http/1.1"]),
      certificates: [{ certificateFile: defaults.certificateFile, keyFile: defaults.keyFile }],
    };
  } else if (inb.security === "reality") {
    ss.security = "reality";
    ss.realitySettings = {
      show: false,
      dest: inb.reality.dest,
      xver: 0,
      serverNames: inb.reality.serverNames,
      privateKey: inb.reality.privateKey,
      shortIds: (inb.reality.shortIds && inb.reality.shortIds.length) ? inb.reality.shortIds : [""],
    };
  } else {
    ss.security = "none";
  }
  return ss;
}

function protocolSettings(inb, clients) {
  if (inb.protocol === "vless") return { clients, decryption: "none" };
  if (inb.protocol === "vmess") return { clients };
  if (inb.protocol === "trojan") return { clients };
  // shadowsocks-2022: server-level PSK + per-user PSKs, tcp+udp
  return { method: inb.method, password: inb.ssPassword, network: "tcp,udp", clients };
}

/**
 * Turn a normalised inbound record + its client list into an xray inbound.
 * `defaults` supplies the fallback TLS cert paths for tls inbounds.
 */
export function buildInbound(inb, clients, defaults = {}) {
  return {
    tag: inb.tag,
    listen: inb.listen || "0.0.0.0",
    port: inb.port,
    protocol: inb.protocol,
    settings: protocolSettings(inb, clients),
    streamSettings: streamSettings(inb, defaults),
    sniffing: { enabled: true, destOverride: ["http", "tls", "quic"] },
  };
}

/**
 * Build every enabled, valid inbound from a records array, skipping ones whose
 * port collides with a reserved port (the front) or an earlier inbound. Returns
 * { inbounds, skipped } so the caller can surface what was dropped and why.
 */
export function buildInbounds(records, users, { reservedPorts = [], defaults = {} } = {}) {
  const used = new Set(reservedPorts);
  const inbounds = [];
  const skipped = [];
  for (const raw of records || []) {
    const inb = raw.tag ? raw : normalizeInbound(raw);
    if (!inb.enabled) continue;
    const v = validateInbound(inb);
    if (!v.ok) { skipped.push({ id: inb.id, reason: v.error }); continue; }
    if (used.has(inb.port)) { skipped.push({ id: inb.id, reason: `port ${inb.port} already in use` }); continue; }
    used.add(inb.port);
    inbounds.push(buildInbound(inb, clientsForInbound(inb, users), defaults));
  }
  return { inbounds, skipped };
}
