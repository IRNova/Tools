// Nova VPS agent — routing, outbounds and DNS from panel settings.
//
// Nova-Proxy exposes routing / WARP / DNS / fragment options but, being a
// Cloudflare Worker with no proxy core of its own, it mostly injects those into
// the CLIENT config (Clash/sing-box) rather than enforcing them. A self-hosted
// xray node runs a real core, so it can enforce the same options for real. This
// module turns the same network-settings keys into xray `outbounds[]`,
// `routing.rules[]` and a `dns` object.
//
// It reuses Nova-Proxy's setting keys (enableWarp, warpMode, bypassChina,
// enableMalwareBlock, blockQUIC, enableDoH/dohProvider, tlsFragment, ...) so the
// panel that drives it stays close to the Nova-Proxy panel.

// DoH endpoints the panel's dohProvider dropdown maps to.
const DOH = {
  cloudflare: "https://1.1.1.1/dns-query",
  google: "https://8.8.8.8/dns-query",
  quad9: "https://9.9.9.9/dns-query",
  adguard: "https://94.140.14.14/dns-query",
};
// Anti-sanction resolvers (reach Iran-blocked sites) for the antiSanction dropdown.
const ANTI_SANCTION = {
  shecan: "178.22.122.100",
  electro: "78.157.42.100",
  cloudflare: "1.1.1.1",
  google: "8.8.8.8",
  quad9: "9.9.9.9",
};

const truthy = (v) => v === true || v === 1 || v === "1" || v === "true";

/**
 * Outbounds for the generated config: always direct + block, plus a WireGuard
 * WARP outbound when enabled and an account is available, plus a chained
 * upstream (socks/http) when configured. `direct` carries TLS fragmentation
 * when the panel turns it on.
 */
export function buildOutbounds(net = {}, { warpAccount = null } = {}) {
  const direct = { tag: "direct", protocol: "freedom", settings: {} };
  if (net.tlsFragment && net.tlsFragment !== "off" && net.tlsFragment !== "Off") {
    const f = net.fragmentParams || {};
    direct.settings.fragment = {
      packets: f.packets || "tlshello",
      length: f.length || "100-200",
      interval: f.interval || "10-20",
    };
  }
  if (net.enableIPv6 === false) direct.settings.domainStrategy = "UseIPv4";

  const outs = [direct, { tag: "block", protocol: "blackhole", settings: { response: { type: "http" } } }];

  if ((truthy(net.enableWarp) || truthy(net.warpCalls)) && warpAccount && warpAccount.privateKey) {
    outs.push(warpOutbound(warpAccount, net));
  }

  // Chained upstream proxy (socks5://host:port or http://host:port). The real
  // egress dials through it via sockopt.dialerProxy on the direct outbound.
  const chain = firstChain(net.chainProxy);
  if (chain) {
    outs.push(chain.outbound);
    direct.streamSettings = { ...(direct.streamSettings || {}), sockopt: { dialerProxy: "chain" } };
  }
  return outs;
}

/** A WireGuard (Cloudflare WARP) outbound from a registered account. */
export function warpOutbound(acc, net = {}) {
  const peer = {
    publicKey: acc.peerPublicKey,
    endpoint: net.warpEndpoint || acc.endpoint || "engage.cloudflareclient.com:2408",
    allowedIPs: ["0.0.0.0/0", "::/0"],
  };
  const s = {
    secretKey: acc.privateKey,
    address: [acc.addressV4 || "172.16.0.2/32", acc.addressV6].filter(Boolean),
    peers: [peer],
    mtu: acc.mtu || 1280,
  };
  if (Array.isArray(acc.reserved) && acc.reserved.length === 3) s.reserved = acc.reserved;
  return { tag: "warp", protocol: "wireguard", settings: s };
}

function firstChain(chainProxy) {
  if (!chainProxy) return null;
  const line = String(chainProxy).split(/\r?\n/).map((s) => s.trim()).find(Boolean);
  if (!line) return null;
  let u;
  try {
    u = new URL(line);
  } catch {
    return null;
  }
  const proto = u.protocol.replace(":", "");
  if (proto !== "socks5" && proto !== "socks" && proto !== "http" && proto !== "https") return null;
  const server = { address: u.hostname, port: Number(u.port) || (proto.startsWith("http") ? 8080 : 1080) };
  if (u.username) server.users = [{ user: decodeURIComponent(u.username), pass: decodeURIComponent(u.password || "") }];
  const xproto = proto === "socks5" || proto === "socks" ? "socks" : "http";
  return { outbound: { tag: "chain", protocol: xproto, settings: { servers: [server] } } };
}

/**
 * routing.rules[] for the generated config. Always keeps the api rule; adds
 * block rules (ads/malware/phishing), country/domestic direct bypasses, block
 * QUIC, and WARP routing when enabled.
 */
export function buildRoutingRules(net = {}) {
  const rules = [{ type: "field", inboundTag: ["api"], outboundTag: "api" }];

  if (truthy(net.blockQUIC)) {
    rules.push({ type: "field", network: "udp", port: 443, outboundTag: "block" });
  }
  // Route voice/video (UDP) through WARP so calls work, when asked.
  if (truthy(net.warpCalls)) {
    rules.push({ type: "field", network: "udp", outboundTag: "warp" });
  }

  // Only reference geosite/geoip codes that reliably exist in the standard
  // geosite.dat/geoip.dat, otherwise a missing code makes xray refuse to start.
  // "category-ads-all" and "cn" are present in the common data sets; malware /
  // phishing / sanctioned categories are NOT in the common .dat files (Nova-Proxy
  // sources those from remote rule-sets in the CLIENT config, not the core), so
  // they are intentionally not emitted here. Iran uses the TLD matcher (no .dat).
  if (truthy(net.enableAdBlock)) {
    rules.push({ type: "field", domain: ["geosite:category-ads-all"], outboundTag: "block" });
  }

  const directDomains = [];
  const directIPs = [];
  if (truthy(net.enableDomesticBypass) || truthy(net.bypassIran)) {
    directDomains.push("domain:ir");
    directIPs.push("geoip:ir");
  }
  if (truthy(net.bypassChina)) { directDomains.push("geosite:cn"); directIPs.push("geoip:cn"); }
  if (truthy(net.bypassRussia)) { directIPs.push("geoip:ru"); }
  if (directDomains.length) rules.push({ type: "field", domain: directDomains, outboundTag: "direct" });
  if (directIPs.length) rules.push({ type: "field", ip: directIPs, outboundTag: "direct" });

  // Send everything else through WARP when the mode asks for it (warp / wow).
  if (truthy(net.enableWarp) && (net.warpMode === "warp" || net.warpMode === "wow") && truthy(net.warpAll)) {
    rules.push({ type: "field", network: "tcp,udp", outboundTag: "warp" });
  }
  return rules;
}

/** A `dns` object when the panel enables DoH or anti-sanction DNS; else undefined. */
export function buildDns(net = {}) {
  if (!truthy(net.enableDoH) && !truthy(net.enableAntiSanctionDNS)) return undefined;
  const servers = [];
  if (truthy(net.enableAntiSanctionDNS)) {
    const ip = net.antiSanctionDNSProvider === "custom"
      ? (net.antiSanctionCustomDNS || "178.22.122.100")
      : (ANTI_SANCTION[net.antiSanctionDNSProvider] || "178.22.122.100");
    servers.push({ address: ip, domains: ["geosite:category-ir", "domain:ir"] });
  }
  servers.push(truthy(net.enableDoH) ? (DOH[net.dohProvider] || DOH.cloudflare) : "1.1.1.1");
  return { servers, queryStrategy: net.enableIPv6 === false ? "UseIPv4" : "UseIP" };
}

/** Sniffing block for inbounds; routeOnly keeps the sniffed dest for routing only. */
export function sniffing() {
  return { enabled: true, destOverride: ["http", "tls", "quic"], routeOnly: true };
}
