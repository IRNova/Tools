// Nova VPS agent — routing, outbounds and DNS from panel settings.
//
// Nova-Proxy exposes routing / WARP / DNS / fragment options but, being a
// Cloudflare Worker with no proxy core of its own, it mostly injects those into
// the CLIENT config (Clash/sing-box) rather than enforcing them. A self-hosted
// xray node runs a real core, so it can enforce the same options for real. This
// module turns the same network-settings keys into xray `outbounds[]`,
// `routing.rules[]` and a `dns` object.
//
// It reuses Nova-Proxy's setting keys (enableWarp, warpMode, bypassChina,
// enableMalwareBlock, blockQUIC, enableDoH/dohProvider, tlsFragment, ...) so the
// panel that drives it stays close to the Nova-Proxy panel.

// DoH endpoints the panel's dohProvider dropdown maps to.
const DOH = {
  cloudflare: "https://1.1.1.1/dns-query",
  google: "https://8.8.8.8/dns-query",
  quad9: "https://9.9.9.9/dns-query",
  adguard: "https://94.140.14.14/dns-query",
};
// Anti-sanction resolvers (reach Iran-blocked sites) for the antiSanction dropdown.
const ANTI_SANCTION = {
  shecan: "178.22.122.100",
  electro: "78.157.42.100",
  cloudflare: "1.1.1.1",
  google: "8.8.8.8",
  quad9: "9.9.9.9",
};

const truthy = (v) => v === true || v === 1 || v === "1" || v === "true";

/**
 * Outbounds for the generated config: always direct + block, plus a WireGuard
 * WARP outbound when enabled and an account is available, plus a chained
 * upstream (socks/http) when configured. `direct` carries TLS fragmentation
 * when the panel turns it on.
 */
export function buildOutbounds(net = {}, { warpAccount = null } = {}) {
  const direct = { tag: "direct", protocol: "freedom", settings: {} };
  if (net.tlsFragment && net.tlsFragment !== "off" && net.tlsFragment !== "Off") {
    const f = net.fragmentParams || {};
    direct.settings.fragment = {
      packets: f.packets || "tlshello",
      length: f.length || "100-200",
      interval: f.interval || "10-20",
    };
  }
  if (net.enableIPv6 === false) direct.settings.domainStrategy = "UseIPv4";
  // Freedom egress strategy from the Xray Settings page (AsIs / UseIP / UseIPv4 /
  // UseIPv6 / ForceIP...). An explicit choice wins over the IPv6 default above.
  if (net.freedomStrategy && net.freedomStrategy !== "default") {
    direct.settings.domainStrategy = net.freedomStrategy;
  }

  const outs = [direct, { tag: "block", protocol: "blackhole", settings: { response: { type: "http" } } }];

  if ((truthy(net.enableWarp) || truthy(net.warpCalls)) && warpAccount && warpAccount.privateKey) {
    outs.push(warpOutbound(warpAccount, net));
  }

  // Extra egress paths a routing rule (or a per-inbound assignment) can target:
  //   tor      -> the node's local Tor SOCKS (apt install tor, 127.0.0.1:9050)
  //   psiphon  -> a local Psiphon tunnel's SOCKS (random IPs, DPI-resistant)
  // The outbound is just a socks dialer to the local service; the service itself
  // is installed/managed separately. xray accepts the config either way, so a
  // rule pointing here only carries traffic once the service is up.
  if (truthy(net.enableTor)) {
    const port = Number(net.torPort) >= 1 && Number(net.torPort) <= 65535 ? Number(net.torPort) : 9050;
    outs.push({ tag: "tor", protocol: "socks", settings: { servers: [{ address: "127.0.0.1", port }] } });
  }
  if (truthy(net.enablePsiphon)) {
    const port = Number(net.psiphonPort) >= 1 && Number(net.psiphonPort) <= 65535 ? Number(net.psiphonPort) : 1080;
    outs.push({ tag: "psiphon", protocol: "socks", settings: { servers: [{ address: "127.0.0.1", port }] } });
  }

  // Chained upstream proxy (socks5://host:port or http://host:port). The real
  // egress dials through it via sockopt.dialerProxy on the direct outbound.
  const chain = firstChain(net.chainProxy);
  if (chain) {
    outs.push(chain.outbound);
    direct.streamSettings = { ...(direct.streamSettings || {}), sockopt: { dialerProxy: "chain" } };
  }
  return outs;
}

// Clean-IP pool for WARP: Cloudflare edge ranges + ports Iran tends to leave
// open. WARP is anycast, so the registered keypair works on any of these, which
// lets us dodge the commonly-blocked default endpoint. Same pool as the Worker.
const WARP_CIDRS = ["162.159.192.0/24", "162.159.193.0/24", "162.159.195.0/24", "188.114.96.0/24", "188.114.97.0/24", "188.114.98.0/24", "188.114.99.0/24"];
const WARP_PORTS = [854, 894, 908, 928, 955, 987, 1002, 1070, 1387, 1701, 2408, 500, 4500];
function randWarpIpv4(cidr) {
  const [base, m] = cidr.split("/");
  const mask = parseInt(m, 10);
  const baseInt = base.split(".").reduce((a, v) => (a << 8) + parseInt(v, 10), 0) >>> 0;
  const off = Math.floor(Math.random() * Math.pow(2, 32 - mask));
  const ip = (baseInt + off) >>> 0;
  return [(ip >>> 24) & 255, (ip >>> 16) & 255, (ip >>> 8) & 255, ip & 255].join(".");
}
function randWarpEndpoint() {
  const c = WARP_CIDRS[Math.floor(Math.random() * WARP_CIDRS.length)];
  const p = WARP_PORTS[Math.floor(Math.random() * WARP_PORTS.length)];
  return `${randWarpIpv4(c)}:${p}`;
}
const warpValidEndpoint = (ep) => typeof ep === "string" && /^[A-Za-z0-9.\-\[\]:]+:\d{1,5}$/.test(ep.trim());
/** Endpoint priority: valid manual override -> random clean IP (when warpCleanIp) -> account -> default. */
export function pickWarpEndpoint(net = {}, acc = {}) {
  if (net.warpEndpoint && warpValidEndpoint(net.warpEndpoint)) return net.warpEndpoint.trim();
  if (truthy(net.warpCleanIp)) return randWarpEndpoint();
  return acc.endpoint || "engage.cloudflareclient.com:2408";
}

/** A WireGuard (Cloudflare WARP) outbound from a registered account. */
export function warpOutbound(acc, net = {}) {
  const peer = {
    publicKey: acc.peerPublicKey,
    endpoint: pickWarpEndpoint(net, acc),
    allowedIPs: ["0.0.0.0/0", "::/0"],
  };
  const s = {
    secretKey: acc.privateKey,
    address: [acc.addressV4 || "172.16.0.2/32", acc.addressV6].filter(Boolean),
    peers: [peer],
    mtu: acc.mtu || 1280,
  };
  if (Array.isArray(acc.reserved) && acc.reserved.length === 3) s.reserved = acc.reserved;
  return { tag: "warp", protocol: "wireguard", settings: s };
}

function firstChain(chainProxy) {
  if (!chainProxy) return null;
  const line = String(chainProxy).split(/\r?\n/).map((s) => s.trim()).find(Boolean);
  if (!line) return null;
  let u;
  try {
    u = new URL(line);
  } catch {
    return null;
  }
  const proto = u.protocol.replace(":", "");
  if (proto !== "socks5" && proto !== "socks" && proto !== "http" && proto !== "https") return null;
  const server = { address: u.hostname, port: Number(u.port) || (proto.startsWith("http") ? 8080 : 1080) };
  if (u.username) server.users = [{ user: decodeURIComponent(u.username), pass: decodeURIComponent(u.password || "") }];
  const xproto = proto === "socks5" || proto === "socks" ? "socks" : "http";
  return { outbound: { tag: "chain", protocol: xproto, settings: { servers: [server] } } };
}

/**
 * routing.rules[] for the generated config. Always keeps the api rule; adds
 * block rules (ads/malware/phishing), country/domestic direct bypasses, block
 * QUIC, and WARP routing when enabled.
 */
// Parse the admin's free-form routing rules: one per line, "<matcher> <outbound>"
// where outbound is direct | block | warp and matcher is a domain / geosite: /
// geoip: / ip / cidr / protocol: token. Invalid lines are skipped; the whole
// config is xray-tested before it is committed, so a bad matcher cannot brick
// the node (it surfaces as a save error instead).
export function parseCustomRules(text) {
  const out = [];
  const valid = new Set(["direct", "block", "warp", "tor", "psiphon"]);
  for (const raw of String(text || "").split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const parts = line.split(/\s+/);
    if (parts.length < 2) continue;
    const outbound = String(parts.pop()).toLowerCase();
    if (!valid.has(outbound)) continue;
    const m = parts.join(" ");
    if (/^geoip:/i.test(m) || /^\d{1,3}(\.\d{1,3}){3}(\/\d+)?$/.test(m) || (m.includes(":") && /^[0-9a-f:]+(\/\d+)?$/i.test(m))) {
      out.push({ type: "field", ip: [m], outboundTag: outbound });
    } else if (/^protocol:/i.test(m)) {
      out.push({ type: "field", protocol: [m.replace(/^protocol:/i, "")], outboundTag: outbound });
    } else {
      out.push({ type: "field", domain: [m], outboundTag: outbound });
    }
  }
  return out;
}

// Convert one structured routing rule (from the Routing page's rule builder) into
// an xray routing rule. Only non-empty fields are emitted, so a sparse rule stays
// sparse. Comma/space lists become arrays; outboundTag XOR balancerTag decides the
// target. The whole config is xray-tested before commit, so an odd rule is
// rejected at save, never bricking the node.
const _list = (v) => (Array.isArray(v) ? v : String(v || "").split(/[\s,]+/)).map((s) => String(s).trim()).filter(Boolean);
export function structuredRule(r = {}) {
  const rule = { type: "field" };
  if (r.ruleTag) rule.ruleTag = String(r.ruleTag);
  if (r.domainMatcher === "linear" || r.domainMatcher === "hybrid") rule.domainMatcher = r.domainMatcher;
  const domain = _list(r.domain);
  const ip = _list(r.ip);
  const source = _list(r.source);
  const user = _list(r.user);
  const inboundTag = _list(r.inboundTag);
  const protocol = _list(r.protocol);
  const attrs = String(r.attrs || "").trim();
  if (domain.length) rule.domain = domain;
  if (ip.length) rule.ip = ip;
  if (source.length) rule.source = source;
  if (user.length) rule.user = user;
  if (inboundTag.length) rule.inboundTag = inboundTag;
  if (protocol.length) rule.protocol = protocol;
  if (r.port !== undefined && r.port !== null && String(r.port).trim()) rule.port = String(r.port).trim();
  if (r.sourcePort !== undefined && r.sourcePort !== null && String(r.sourcePort).trim()) rule.sourcePort = String(r.sourcePort).trim();
  if (r.network === "tcp" || r.network === "udp" || r.network === "tcp,udp") rule.network = r.network;
  if (attrs) rule.attrs = attrs;
  // A rule needs a destination: an outbound tag or a balancer tag (mutually exclusive).
  if (r.balancerTag) rule.balancerTag = String(r.balancerTag);
  else if (r.outboundTag) rule.outboundTag = String(r.outboundTag);
  return rule;
}

// Only keep rules that actually match on something and route somewhere, so a
// half-filled row from the builder can't become a catch-all that breaks routing.
function usableStructuredRule(rule) {
  const matchers = ["domain", "ip", "source", "user", "inboundTag", "protocol", "port", "sourcePort", "network", "attrs"];
  const hasMatch = matchers.some((k) => rule[k] !== undefined);
  const hasTarget = rule.outboundTag || rule.balancerTag;
  return hasMatch && hasTarget;
}

export function buildRoutingRules(net = {}) {
  const rules = [{ type: "field", inboundTag: ["api"], outboundTag: "api" }];

  // Structured rules from the Routing page take top priority (after api).
  for (const raw of Array.isArray(net.routingRules) ? net.routingRules : []) {
    const rule = structuredRule(raw);
    if (usableStructuredRule(rule)) rules.push(rule);
  }

  // Admin free-form text rules come next.
  for (const r of parseCustomRules(net.customRules)) rules.push(r);

  // Route voice/video (UDP) through WARP so calls work, when asked. WARP is a
  // connectivity feature, independent of the anti-censorship master below.
  if (truthy(net.warpCalls)) {
    rules.push({ type: "field", network: "udp", outboundTag: "warp" });
  }

  // Anti-censorship bundle: block ads/porn/bittorrent/QUIC and route domestic
  // (Iran/China/Russia) geos direct. A single master toggle (default ON) gates
  // the whole group so the Routing page can offer one on/off; the granular
  // toggles below just refine it. Off = none of these built-in rules emit; the
  // admin's own structured + custom rules (above) still apply.
  // Only reference geosite/geoip codes that reliably exist in the standard
  // geosite.dat/geoip.dat (category-ads-all, category-porn, cn, ir, ru); malware /
  // phishing / sanctioned categories are absent from the common .dat and would
  // make xray refuse to start, so they are never emitted here.
  if (net.antiCensorship !== false) {
    if (truthy(net.blockQUIC)) {
      rules.push({ type: "field", network: "udp", port: 443, outboundTag: "block" });
    }
    if (truthy(net.enableAdBlock)) {
      rules.push({ type: "field", domain: ["geosite:category-ads-all"], outboundTag: "block" });
    }
    if (truthy(net.blockPorn)) {
      rules.push({ type: "field", domain: ["geosite:category-porn"], outboundTag: "block" });
    }
    if (truthy(net.blockBittorrent)) {
      rules.push({ type: "field", protocol: ["bittorrent"], outboundTag: "block" });
    }
    const directDomains = [];
    const directIPs = [];
    if (truthy(net.enableDomesticBypass) || truthy(net.bypassIran)) {
      directDomains.push("domain:ir");
      directIPs.push("geoip:ir");
    }
    if (truthy(net.bypassChina)) { directDomains.push("geosite:cn"); directIPs.push("geoip:cn"); }
    if (truthy(net.bypassRussia)) { directIPs.push("geoip:ru"); }
    if (directDomains.length) rules.push({ type: "field", domain: directDomains, outboundTag: "direct" });
    if (directIPs.length) rules.push({ type: "field", ip: directIPs, outboundTag: "direct" });
  }

  // Send everything else through WARP when the mode asks for it (warp / wow).
  if (truthy(net.enableWarp) && (net.warpMode === "warp" || net.warpMode === "wow") && truthy(net.warpAll)) {
    rules.push({ type: "field", network: "tcp,udp", outboundTag: "warp" });
  }
  return rules;
}

/** A `dns` object when the panel enables DoH or anti-sanction DNS; else undefined. */
export function buildDns(net = {}) {
  if (!truthy(net.enableDoH) && !truthy(net.enableAntiSanctionDNS)) return undefined;
  const servers = [];
  if (truthy(net.enableAntiSanctionDNS)) {
    const ip = net.antiSanctionDNSProvider === "custom"
      ? (net.antiSanctionCustomDNS || "178.22.122.100")
      : (ANTI_SANCTION[net.antiSanctionDNSProvider] || "178.22.122.100");
    servers.push({ address: ip, domains: ["geosite:category-ir", "domain:ir"] });
  }
  // Secure DNS = resolve on THIS server. "localhost" makes xray use the node's
  // own resolver, so DNS queries exit from the same IP the user connects to
  // instead of leaking to a public provider (Google/Cloudflare). Off falls back
  // to a plain 1.1.1.1 lookup.
  servers.push(truthy(net.enableDoH) ? "localhost" : "1.1.1.1");
  return { servers, queryStrategy: net.enableIPv6 === false ? "UseIPv4" : "UseIP" };
}

/** Sniffing block for inbounds; routeOnly keeps the sniffed dest for routing only. */
export function sniffing() {
  return { enabled: true, destOverride: ["http", "tls", "quic"], routeOnly: true };
}
