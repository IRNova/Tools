// Nova VPS agent: xray traffic -> panel accounting bridge.
//
// Polls xray's stats with `-reset`, so every poll returns only the bytes since
// the last poll (a delta). Those deltas are added into the SAME keys the panel
// already uses for quota / daily-limit / expiry enforcement:
//   uusage:<id>              total bytes for a user
//   uusage-d:<id>:<YYYY-MM-DD>  per-day bytes for a user
// so no panel logic changes. Uplink/downlink are ALSO kept split, for the
// dashboard's up-vs-down chart and per-user breakdown:
//   uusage-up:<id> / uusage-dn:<id>              total up / down for a user
//   uusage-d-up:<id>:<day> / uusage-d-dn:<id>:<day>  per-day up / down

import { execFile } from "node:child_process";
import { promisify } from "node:util";

const pExecFile = promisify(execFile);

// xray stat names look like:  user>>><email>>>>traffic>>>uplink   (or downlink)
const NAME_RE = /^user>>>(.+)>>>traffic>>>(uplink|downlink)$/;

/** Parse the JSON emitted by `xray api statsquery` into { email: {up, down} }. */
export function parseStats(statsQueryJson) {
  const out = {};
  const stats = (statsQueryJson && statsQueryJson.stat) || [];
  for (const s of stats) {
    const m = NAME_RE.exec(s.name || "");
    if (!m) continue;
    const [, email, dir] = m;
    (out[email] ||= { up: 0, down: 0 });
    const v = Number(s.value || 0);
    if (dir === "uplink") out[email].up += v;
    else out[email].down += v;
  }
  return out;
}

/** Read-and-reset xray user traffic. Returns { email: {up, down} } deltas. */
export async function pollXrayTraffic({
  apiAddr = "127.0.0.1:10085",
  xrayBin = "xray",
} = {}) {
  const { stdout } = await pExecFile(
    xrayBin,
    ["api", "statsquery", `--server=${apiAddr}`, "-pattern", "user>>>", "-reset"],
    { timeout: 10_000 }, // a wedged xray must not stall the poll loop forever (L5)
  );
  return parseStats(JSON.parse(stdout));
}

/**
 * Accrue deltas into the panel's KV keys.
 * @param {{get:(k)=>Promise<any>, put:(k,v)=>Promise<any>}} kv
 * @param {Record<string,{up:number,down:number}>} deltas
 * @param {object} opts
 *   emailToId  map an xray email back to the Nova user id (default: identity)
 *   now        Date used for the daily bucket (default: now)
 */
export async function accrue(kv, deltas, opts = {}) {
  const { emailToId = (e) => e, now = new Date() } = opts;
  const day = now.toISOString().slice(0, 10);
  let total = 0;
  for (const [email, d] of Object.entries(deltas)) {
    const up = d.up || 0;
    const down = d.down || 0;
    const bytes = up + down;
    if (!bytes) continue;
    const id = emailToId(email);
    // Total keys (quota / daily-limit / expiry read these; unchanged).
    await addTo(kv, `uusage:${id}`, bytes);
    await addTo(kv, `uusage-d:${id}:${day}`, bytes);
    // Split keys for charts + per-user up/down.
    if (up) {
      await addTo(kv, `uusage-up:${id}`, up);
      await addTo(kv, `uusage-d-up:${id}:${day}`, up);
    }
    if (down) {
      await addTo(kv, `uusage-dn:${id}`, down);
      await addTo(kv, `uusage-d-dn:${id}:${day}`, down);
    }
    total += bytes;
  }
  return total;
}

async function addTo(kv, key, n) {
  const cur = Number((await kv.get(key)) || 0);
  await kv.put(key, String(cur + n));
}
