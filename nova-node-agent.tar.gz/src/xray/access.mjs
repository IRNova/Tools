// Nova VPS agent: online-device tracking + per-user IP limit.
//
// xray writes an access log line per accepted connection, carrying the source IP
// and the client email. We tail that log (by byte offset, so each poll only
// reads new lines), record which IPs each user connected from and when, and keep
// a sliding window of "online" IPs. That drives the live device count and the
// per-user ipLimit (Marzban-style: a user connecting from more than ipLimit
// distinct IPs is briefly locked out so shared accounts get punished).

import { statSync, openSync, readSync, closeSync } from "node:fs";

// Access-log line, e.g.:
//   2026/07/19 21:00:00 from 1.2.3.4:5678 accepted tcp:host:443 [vless-ws -> direct] email: alice
const LINE_RE =
  /\bfrom (\d{1,3}(?:\.\d{1,3}){3}|\[[0-9a-fA-F:]+\]):\d+ accepted\b.*?\bemail:\s*(\S+)/;

export function parseAccessLines(lines) {
  const out = [];
  for (const line of lines) {
    const m = LINE_RE.exec(line);
    if (m) out.push({ ip: m[1].replace(/^\[|\]$/g, ""), email: m[2] });
  }
  return out;
}

/**
 * Read bytes appended to `path` since `prevOffset`. Handles rotation/truncation
 * (if the file shrank, read from 0). Returns { lines, offset }.
 */
export function readNewLines(path, prevOffset = 0, maxBytes = 1 << 20) {
  let size;
  try {
    size = statSync(path).size;
  } catch {
    return { lines: [], offset: 0 };
  }
  let start = prevOffset;
  if (size < prevOffset) start = 0; // rotated or truncated
  if (size - start > maxBytes) start = size - maxBytes; // cap catch-up reads
  if (size <= start) return { lines: [], offset: size };
  const fd = openSync(path, "r");
  try {
    const buf = Buffer.allocUnsafe(size - start);
    const n = readSync(fd, buf, 0, buf.length, start);
    const text = buf.subarray(0, n).toString("utf8");
    return { lines: text.split("\n").filter(Boolean), offset: size };
  } finally {
    closeSync(fd);
  }
}

/**
 * Fold new access entries into the per-user online maps `online:<id>` = { ip: ts }
 * and return the current online count per id (IPs seen within `windowMs`).
 * `emailToId` maps an xray email back to the Nova user id.
 */
export async function updateOnline(kv, entries, opts = {}) {
  const { emailToId = (e) => e, windowMs = 300_000, now = Date.now() } = opts;
  const touched = new Map(); // id -> map
  for (const { ip, email } of entries) {
    const id = emailToId(email);
    let m = touched.get(id);
    if (!m) {
      try {
        m = JSON.parse((await kv.get(`online:${id}`)) || "{}");
      } catch {
        m = {};
      }
      touched.set(id, m);
    }
    m[ip] = now;
  }
  const counts = {};
  for (const [id, m] of touched) {
    for (const ip of Object.keys(m)) if (now - m[ip] > windowMs) delete m[ip];
    await kv.put(`online:${id}`, JSON.stringify(m));
    counts[id] = Object.keys(m).length;
  }
  return counts;
}

/** Current online device counts for every tracked user (within `windowMs`). */
export async function onlineCounts(kv, { windowMs = 300_000, now = Date.now() } = {}) {
  const out = {};
  for (const { name } of await kv.list({ prefix: "online:" })) {
    const id = name.slice("online:".length);
    let m = {};
    try {
      m = JSON.parse((await kv.get(name)) || "{}");
    } catch {}
    out[id] = Object.values(m).filter((ts) => now - ts <= windowMs).length;
  }
  return out;
}

/**
 * Given the users and current online counts, return the set of user ids that are
 * over their ipLimit and should be locked out. ipLimit <= 0 means unlimited.
 */
export function overLimitIds(users, counts) {
  const over = new Set();
  for (const u of users || []) {
    const lim = Number(u.ipLimit || 0);
    if (lim > 0 && (counts[u.id] || 0) > lim) over.add(u.id);
  }
  return over;
}
